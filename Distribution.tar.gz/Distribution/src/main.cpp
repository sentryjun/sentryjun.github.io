
#include "Service/SynService.h"
#include "Service/IO/IOService.h"
#include "Service/IO/StrandService.h"
#include "Service/Logger/LogService.h"
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include "Service/Exception/ExceptionService.h"
#include "Service/ForwardService.h"
#include "Common/enum.h"
#include "Service/Timer/TimerService.h"
#include "SbdnObjectImpl/NMCDistProgram.h"
#include "SbdnObject/XML/tinyxml.h"
#include "config/Application.h"
#include <boost/program_options.hpp>
#include "SbdnObjectImpl/NMCEventMessage.h"
#include "Parser/NMCSbdnObjectParser.h"
#include "Service/MergeService.h"
using namespace asio;
using namespace PKU_SatLab_DBS_NMC::service;
using namespace PKU_SatLab_DBS_NMC;
using namespace property_tree;
using namespace Parser;
namespace po = boost::program_options;
int main(int argc, char *argv[]) {
#ifndef SYN_DEBUG
    PKU_SatLab_DBS_NMC::service::SynService *test = PKU_SatLab_DBS_NMC::service::SynService::getInstance();
    IOService * ioService = IOService::getInstance();
    StrandService * strandService = StrandService::getInstance();
    ioService->start();
    TimerService* m_timerService = TimerService::getInstance();
    ExceptionService* m_exceptionService = ExceptionService::getInstance();
    ptree m_propertyTree;
    xml_parser::read_xml("app.xml", m_propertyTree);
    LogService* m_logService = LogService::getInstance();
    ForwardService* fow = ForwardService::getInstance();
    m_logService->setName("NMCLog");
    m_logService->setLogLevel(NETIO);
    m_logService->setService(ioService->getService(1));
    /* set each level record type */
    property_tree::ptree& loggerTree = m_propertyTree.get_child(
            "Application.Log");
    LogLevel logLevel;
    LogRecordType recordType;
    /* find every node named LoggerName*/
    BOOST_FOREACH(property_tree::ptree::value_type &value, loggerTree.get_child("LoggerName"))
    {
        /* get log level name */
        string loggerName = value.second.data();
        logLevel = strToEnum<LogLevel> (loggerName);
        /* find log record type config node */
        BOOST_FOREACH(property_tree::ptree::value_type &record,
                      loggerTree.get_child(loggerName + ".Record"))
        {
            recordType = strToEnum<LogRecordType> (
                    record.first);
            m_logService->setEnableRecordType(logLevel,
                                              recordType);
        }
    }
    m_logService->start();

    m_timerService->setService(ioService->getService(1));
    m_timerService->start();


    m_exceptionService->setService(ioService->getService(1));
    m_exceptionService->start();
    NMCDistProgram a("DistProgram1",0, "127.0.0.1", 8888, 9999);
    a.initialize();
    test->setService(ioService->getService(0));
    test->setListenport(7000);

    test->start();


    fow->setService(ioService->getService(0));
    fow->setChannelIP(0, "127.0.0.1", 8888);
    fow->setBindport(9999);
    fow->start();

    ioService->run();
#endif
    string configfile = "";
    po::options_description desc("Allowed options");
    desc.add_options()
            ("help","help message")
            ("config", po::value<string>(), "set config file for the application")
            ("testmode", po::value<int>(), "set test mode for the application, 0 for nontest, 1 	for test");
    po::variables_map vm;
    po::store(po::parse_command_line(argc, argv, desc), vm);
    if(vm.count("help"))
    {
        cout << desc << endl;
        return 1;
    }
    if(vm.count("config"))
    {
        configfile = vm["config"].as<string>();
        cout << configfile << endl;
    }
    else
    {
        cout << "use default config app.xml" << endl;
        configfile = "app.xml";
    }


    Application::getInstance()->setConfigPath(configfile);
    Application::getInstance()->start();
//    TiXmlElement * test, *root;
//    m->parseEvent(test);
//    m2->getMessageNode(root);
//
//    TiXmlElement *event2 =
//    XmlParser::firstChildElement(root, "Action");
//    event2->LinkEndChild(test);
//    string ss;
////    XmlParser::xmlToStr(event2,ss);
////    cout << ss;
//    NMCEventMessage *m1, *m2;
//    m1 = new NMCEventMessage(configfile, true);
//    m2 = new NMCEventMessage(configfile, true);
//    XMLNodePtr root = m1->getRootPtr();
//    TiXmlElement * event = XmlParser::firstChildElementBySeperator(root.get()->ToElement(), "Action.AccessProgram.EventList.Event.Parameter");
//    XMLNodePtr eventNode = m2->getEventPtr();
//    TiXmlNode* nextHop = XmlParser::firstChildElementBySeperator(eventNode.get()->ToElement(), "Parameter.NextHop")->Clone();
//    event->LinkEndChild(nextHop);
//    XmlParser::xmlToStr(root->ToElement(), ss);
//    cout << ss;
    return 0;
}
