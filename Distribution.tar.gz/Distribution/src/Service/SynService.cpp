//
// Created by jun on 2021/3/31.
//

#include "SynService.h"
#include <boost/bind.hpp>
#include <boost/cast.hpp>
#include "Connection/TcpConnection.h"
#include "../Parser/NMCSbdnObjectParser.h"
#include "Logger/LogService.h"
#include <boost/foreach.hpp>
#include "ForwardService.h"
#include "../SbdnObjectImpl/NMCDistProgram.h"
#include "MergeService.h"

using namespace PKU_SatLab_DBS_NMC;
using namespace service;
using namespace Parser;

SynService* SynService::m_instance = NULL;

SynService::SynService() {
    m_ioService = NULL;
    m_port = 0;
    m_registeredReply = false;
}

SynService* SynService::getInstance() {
    if (m_instance == NULL)
        m_instance = new SynService();
    return m_instance;
}

void SynService::setService(io_service *ioService) {
    m_ioService = ioService;
}

void SynService::setListenport(int port) {
    m_port = port;
}

void SynService::start() {
    assert(m_ioService);
    assert(m_port);
    tcp::endpoint endpoint(tcp::v4(), m_port);

    m_acceptor.reset(new tcp::acceptor(*m_ioService, endpoint));
    m_acceptor->listen();
    m_connection.reset(new TcpConnection(m_ioService));
    m_endpoint.reset(new tcp::endpoint());
    m_acceptor->async_accept(*(m_connection->getSocket()), *m_endpoint, bind(&SynService::acceptConnectionHandler, this, placeholders::error));
    //ForwardService::getInstance()->synToAccess.connect(bind(&SynService::synToAccessHandler, this, _1, _2));
//    NMCDistProgram::synToAccessProgramRequest.connect(bind(&SynService::synToAccessHandler,
//                                                           this, _1, _2));
    MergeService::getInstance()->synToAccessRequest.connect(bind(&SynService::synToAccessHandler,
                                                           this, _1, "MergeService "));
    NMCDistProgram::changeChannelMsg.connect(bind(&SynService::synChannelMsgToAccess, this, _1, _2));
    LOG(INFO, "0004","Syn_Service Started");
}

void SynService::acceptConnectionHandler(const Error &error) {
    if (!error) {
        m_connection->getSocket()->set_option(tcp::socket::keep_alive());
        m_connection->messageReadSignal.connect(bind(
                &SynService::dispatchConnectionHandler, this, _1, m_connection,
                m_endpoint));
        m_connection->connectionErrorSignal.connect(bind(
                &SynService::connectionErrorHandler, this, _1, m_connection,
                m_endpoint));
        m_activeAccess = m_connection;
        m_connection->startReceive();
        m_connection.reset(new TcpConnection(m_ioService));
        m_endpoint.reset(new tcp::endpoint());
        LOG(INFO, "0000", "Connection active")
        //TODO: 当接入断开重连的时候会因为之前被关闭了软件导致出错
    } else {
        LOG(ERROR, "0000", "Accept error: " << error.value() << "message:" <<error.message())
    }
    m_acceptor->async_accept((*(m_connection->getSocket())), *m_endpoint, bind(
            &SynService::acceptConnectionHandler, this, placeholders::error));
}

void SynService::dispatchConnectionHandler(const string &message,
                                           ConnectionPtr &connection, EndpointPtr &endpoint) {
    try{
        LOG(NETIO, "0000", "Receive \"" <<message << "\" from " << endpoint->address().to_string() <<" " << endpoint->port() )
        int action = 0;
        ObjectInfo nodeInfo;

        NMCSbdnObjectParser::parseAction(message, action);
        if (action == 2) {
            //TODO： 修改一下接入断线重连的情况。
            NMCSbdnObjectParser::parseRegisterAction(message, action, nodeInfo);
            // registerAccessProgram(message);
            ForwardService::getInstance()->registerAccessHandler(message);
            LOG(INFO, "0000",  "Object Connected : " << nodeInfo.Type << " --> "
                                                     << nodeInfo.Name);
        } else if (action == 10022) {
            replyChannelMsg(message, 0);
        } else {
            synToDistributionSignal (message, " ");
        }

        //synToDistributionSignal (message, "nodeInfo.Name");
    } catch (const std::exception & error) {
        LOG(ERROR, "0000", "Exception: " << error.what());
    }

}

void SynService::connectionErrorHandler(const string &error,
                                        ConnectionPtr &connection, EndpointPtr &endpoint)
{
    LOG(ERROR, "0000", "connection from " + endpoint->address().to_string() + " error: " << error);

    m_registeredReply = false;
    m_connection->connectionErrorSignal.disconnect_all_slots();
    m_connection->messageReadSignal.disconnect_all_slots();
    connection->disconnect();
    connection->checkDelete();
    endpoint.reset();
    accessProgramDisconnectSignal();
}

void SynService::synToAccessHandler(const string & message, const string & s) {
    //FIXME
    LOG(NETIO, "0000", "message from " << s << " to Access:" << message)
    int action = 0;
    Parser::NMCSbdnObjectPtr actionPtr= Parser::NMCSbdnObjectParser::parseAction(message, action);
    if (action == 3) {
        if (m_registeredReply == false) {
            m_registeredReply = true;
        } else {
            return;
        }
    }
    LOG(INFO, "0000", "Syn action" << action << "from " <<s << " to Access" )
    if (m_activeAccess.use_count() != 0 && m_activeAccess->isConnected()){
        m_activeAccess->write(message);
    } else {
        LOG(ERROR, "0000", "Access not connected but it has registered")
    }
}

void SynService::synChannelMsgToAccess(const string & message, int32_t channel) {
    //FIXME need to change channel message
    if (channel == 0) {
//        LOG(NETIO, "0000", "SYN CHANNEL INFO TO  ACCESS")
        if (m_activeAccess.use_count() != 0 && m_activeAccess->isConnected()){
        m_activeAccess->write(message);
    } else {
        LOG(ERROR, "0000", "Access not connected but it need to receive")
    }
    } else {
        TiXmlDocument msgXml;
        msgXml.Parse(message.c_str());
        TiXmlElement * msgRoot = msgXml.RootElement();
        TiXmlElement * actionNode = msgRoot->FirstChildElement("Action");
        actionNode->SetAttribute("value", 10022);
        TiXmlPrinter printer;
        msgXml.Accept(&printer);
        string replyMsg = printer.Str();
        replyChannelMsg(replyMsg, channel);
    }
}

void SynService::stopConnection() {
    if (m_activeAccess.use_count() != 0 && m_activeAccess->isConnected()) {
        m_activeAccess->disconnect();
        m_activeAccess.reset();
    }
}