//
// Created by nmc on 2021/5/30.
//

#ifndef NMC_JSONSERVICE_H
#define NMC_JSONSERVICE_H

#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <rapidjson/document.h>
#include <boost/asio.hpp>
#include <boost/signals2.hpp>
#include <boost/function.hpp>
#include <boost/thread.hpp>
#include <boost/thread.hpp>
#include "Connection/TcpConnection.h"
#include "Timer/TimerService.h"
#include <boost/unordered_map.hpp>
using namespace std;
using namespace boost;
using namespace asio;
namespace PKU_SatLab_DBS_NMC {
    namespace service {
        enum JSONType {
            login = 0,
            getset = 1,
            config = 2,
            report = 3,
            masterSwitch=4
        };
        enum ConfigType {
            superMode = 0,
            channel = 1,
            channelRate = 2
        };

        class JSONService {
            typedef boost::system::error_code Error;
            typedef boost::shared_ptr<TcpConnection> ConnectionPtr;
            typedef boost::shared_ptr<tcp::endpoint> EndpointPtr;
            typedef boost::unordered_map<string, int> MessageTypeMap;
        private:
            JSONService();
            ~JSONService();
        public:
            static boost::signals2::signal<void(int)> switchMasterRequest;
            static boost::signals2::signal<void()> StopAllDistProgramRequest;
            static boost::signals2::signal<void(int, const string &, int)> InitialChannelProgram;
            static boost::signals2::signal<void()> StartProgram;
            static JSONService* getInstance();
            JSONType getMessageType(const string& message);
            void parseJsonMessage(const string &message);
            void parseMessageHander(JSONType type, rapidjson::Document & doc);
            void loginHandler();
            void loginResonseHandler(const string &);
            void generateJson(JSONType type, string & message);
            void setMaster(int master) {
                isMaster = master;
            }
            void setIP(const string & ip);
            void setPort(int port);
            void setIOService(io_service * ioservice);
            void setChannel(int c=-1);
            void setBMCIP(const string & ip);
            bool AnswerToNMC(const string & message);
            void start();
            void connectionErrorHandler(const string &message);
            void connectConnectedHandler();
            void messageComeHandler(const string & message);
            void parseLoginHandler(rapidjson::Document & doc);
            void messageReportHandler(int type, const string &);
            void ConfigRequest(const string & msg);
            void masterSwitchHandler(const string & msg);
        private:
            typedef shared_ptr<Timer> TimerPtr;
            io_service * ioService;
            EndpointPtr endpoint;
            ConnectionPtr connection;
            static JSONService* instance;
            string NMCip;
            int NMCport;
            int channel;
            string BMCIP;
            MessageTypeMap typeMap;
            TimerPtr AutoTimer;
            int isMaster;
        };
    }
}

#endif //NMC_JSONSERVICE_H
