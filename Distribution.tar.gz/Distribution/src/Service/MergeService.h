//
// Created by nmc on 2021/6/23.
//

#ifndef DISTRIBUTION_MERGESERVICE_H
#define DISTRIBUTION_MERGESERVICE_H

#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <boost/signals2.hpp>
#include "../SbdnObjectImpl/NMCDistProgram.h"
#include "../SbdnObjectImpl/NMCEventMessage.h"
#include <list>
using namespace std;
using namespace boost;
using namespace asio;
using namespace ip;
namespace PKU_SatLab_DBS_NMC {
    namespace service{
        typedef shared_ptr<NMCEventMessage> MessagePtr;
        typedef list<MessagePtr> MessagePool;
        typedef shared_ptr<MessagePool> MessagePoolPtr;
        typedef boost::mutex MutexType;
        enum {
            CHANNEL_NUM = 16,
        };
        struct ChannelInfo {
            bool send;
            bool active;
            int state;
            MessagePtr msg;
        };
        struct MessageInfo {
            //每一个RequestID
            //对应一个状态机
            //每个状态机包含了一个消息池子
            uint32_t requestSeq;
            MutexType mutex;
            uint32_t state;
            ChannelInfo  ChannelState[CHANNEL_NUM];
            int security; //安全级信息是用来找通道信息的
            uint16_t channelInfo; //channel info 是用来和通道安全信息比较的
            uint16_t channelNum; //channel Num 是用来表示要发几个通道的
            uint16_t send;
            uint16_t success;
            uint16_t reject;
            MessagePoolPtr pool;
        };
        class MergeService {
        public:
            boost::signals2::signal<void(const string &, int)> registerRequest;
            boost::signals2::signal<void(const string &)> synToAccessRequest;
            boost::signals2::signal<void(const string &, int)> distributionToBMC;

            static MergeService* getInstance();
            MergeService();
            ~MergeService();
            void Start();
            typedef shared_ptr<MessageInfo> MessageInfoPtr;
            typedef list<MessageInfoPtr> INFOList;
            typedef map<uint32_t, MessageInfoPtr> INFOMap;
            typedef shared_ptr<INFOList> INFOListPtr;
            void messageComeHandler(const string &, int Pipe);
            void setChannel(uint16_t channel);
            void setIOService(io_service* ioService);
            uint16_t getNumberofChannel(uint16_t channelInfo);
            bool mergeInfoHandler(MessageInfo* info, int action);
            void clearMsg(uint32_t request);
            void initializeChannel(NMCDistProgram * program);

            void setChannelChange(NMCDistProgram * prog, bool connect);
            void switchMasterHandler();
        private:
            INFOMap _infoMap;
            INFOList _infoList;
            io_service * _ioService;
            uint16_t _channel;
            static MergeService* _instance;
            MutexType _mutex;
            bool _activePipe[CHANNEL_NUM];
        };

    }
}


#endif //DISTRIBUTION_MERGESERVICE_H
