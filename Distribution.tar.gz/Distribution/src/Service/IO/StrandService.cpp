/*
 * StrandService.cpp
 *
 *  Created on: Apr 22, 2011
 *      Author: nmc
 */

#include "StrandService.h"
#include "IOService.h"

using namespace PKU_SatLab_DBS_NMC;
using namespace service;

StrandService *StrandService::m_instance = NULL;

StrandService::StrandService()
{
}

StrandService *StrandService::getInstance()
{
	if (m_instance == NULL)
	{
		m_instance = new StrandService();
	}
	return m_instance;
}

StrandService::StrandPtr StrandService::getStrand()
{
	return StrandPtr(new StrandType(*(IOService::getInstance()->getService(0))));
}

//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
