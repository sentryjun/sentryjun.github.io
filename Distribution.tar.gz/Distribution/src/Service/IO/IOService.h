#ifndef NMC_SERVICE_SRC_SERVICE_IO_IO_SERVICE_H_
#define NMC_SERVICE_SRC_SERVICE_IO_IO_SERVICE_H_

#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/smart_ptr.hpp>
#include <list>
using namespace std;
using namespace boost;
using namespace asio;

namespace PKU_SatLab_DBS_NMC
{
	namespace service
	{
		class IOService
		{
			typedef boost::shared_ptr<thread> ThreadPtr;
			typedef list<ThreadPtr> ThreadPool;
			typedef boost::shared_ptr<io_service::work> WorkPtr;
			typedef list<WorkPtr> WorkPool;

		public:
			static IOService* getInstance();

			void start ();
			void run();
			io_service *getService(unsigned int);

		private:
			IOService();
			void run(unsigned int);
			static IOService* m_instance;
			enum
			{
				ServiceNum = 3,
			};
			io_service m_ioServices[ServiceNum];
			WorkPool m_works;
			ThreadPool m_threadPool;
		};

	} // namespace service
} // namespace PKU_SatLab_DBS_NMC

#endif // NMC_SERVICE_SRC_SERVICE_IO_IO_SERVICE_H_
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
