/*
 * StrandService.h
 *
 *  Created on: Apr 22, 2011
 *      Author: nmc
 */

#ifndef STRANDSERVICE_H_
#define STRANDSERVICE_H_

#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>

namespace PKU_SatLab_DBS_NMC
{
	namespace service
	{
		class StrandService
		{
		public:
			typedef boost::asio::io_service::strand StrandType;
			typedef boost::shared_ptr<StrandType> StrandPtr;

			static StrandService* getInstance();

			void start();
			StrandPtr getStrand();

		private:
			StrandService();

			static StrandService *m_instance;
		};
	}

}

#endif /* STRANDSERVICE_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
