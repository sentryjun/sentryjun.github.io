#include "IOService.h"
#include "../Logger/LogService.h"
#include <boost/bind.hpp>

using namespace PKU_SatLab_DBS_NMC;
using namespace service;

IOService* IOService::m_instance = NULL;

IOService* IOService::getInstance()
{
	if (m_instance == NULL)
		m_instance = new IOService();
	return m_instance;
}

IOService::IOService()
{
	for (int i = 0; i < ServiceNum; i++)
	{
		m_works.push_back(WorkPtr(new io_service::work(m_ioServices[i])));
	}
}

void IOService::start()
{
//	int threadNum[ServiceNum] = {2, 2, 2};
	ThreadPtr threadPtr;
//	for (int i = 0; i < ServiceNum; i++)
	{
//		for (int j = 0; j < threadNum[i]; j++)
		for (int j = 0; j < 40; j++)
		{
			threadPtr = ThreadPtr(new thread(bind(&IOService::run, this, 0)));
			m_threadPool.push_back(threadPtr);
		}
	}
}

io_service *IOService::getService(unsigned int index)
{
//	return m_ioServices + (index % ServiceNum);
	return m_ioServices;
}

void IOService::run()
{
//	run(rand() % ServiceNum);
	run(0);
}

void IOService::run(unsigned int index)
{
	while (true)
	{
		try
		{
//			m_ioServices[index % ServiceNum].run();
			m_ioServices[0].run();
			break;
		}
		catch (const std::exception &error)
		{
			LogService::getInstance()->log(ERROR, "0000", error.what(), false);
		}
		catch(...)
		{
		}
	}
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
