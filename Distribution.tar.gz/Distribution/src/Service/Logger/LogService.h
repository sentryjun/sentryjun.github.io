/*
 * LogManager.h
 *
 *  Created on: 2010-5-30
 *      Author: lnl
 */

#ifndef NMC_SERVICE_SRC_SERVICE_LOGSERVICE_H_
#define NMC_SERVICE_SRC_SERVICE_LOGSERVICE_H_

#include <vector>
#include <stdexcept>
#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>
#include "Logger.h"
using namespace std;
using namespace boost;
using namespace asio;

#ifdef ERROR
#undef ERROR
#endif

namespace PKU_SatLab_DBS_NMC
{
	namespace service
	{
		enum LogLevel
		{
			UNKNOW = 0,
			CRITICAL = 1,
			ERROR = 2,
			WARNING = 3,
			NOTICE = 4,
			INFO = 5,
			DEBUG = 6,
			TRACE = 7,
			NETIO = 8,
		};

		class LogService
		{
			typedef boost::shared_ptr<Logger> LoggerPtr;
			typedef vector<LoggerPtr> LoggerContainer;

		public:
			static LogService* getInstance();

			void log(LogLevel, const string &, const string &, bool = true);
			void setName(const string &);
			void setLogLevel(LogLevel) throw (out_of_range);
			void setService(io_service *);
			void setEnableRecordType(LogLevel,  LogRecordType);
			void start();

		protected:
			LogService();

		private:
			bool levelOutOfRange(LogLevel level);

			static LogService* m_instance;
			string m_name;
			LogLevel m_level;
			io_service *m_ioService;
			LoggerContainer m_loggerContainer;
		};
	}
}

#undef LOG
#define LOG(logLevel, code, info) \
	{\
		ostringstream outs; \
		outs.str(""); \
		outs << info << " " << __FILE__ << ":" << __LINE__ ; \
		PKU_SatLab_DBS_NMC::service::LogService::getInstance()->log(logLevel, code, outs.str()); \
	}

#endif /* NMC_SERVICE_SRC_SERVICE_LOGSERVICE_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
