/*
 * LogService.cpp
 *
 *  Created on: 2010-5-30
 *      Author: lnl
 */
#include "LogService.h"
#include <boost/bind.hpp>
#include "../../Common/enum.h"

using namespace PKU_SatLab_DBS_NMC;
using namespace service;

template <>
const EnumNameType EnumName<LogLevel>::list[] =
{
		"UNKNOW",
		"CRITICAL",
		"ERROR",
		"WARNING",
		"NOTICE",
		"INFO",
		"DEBUG",
		"TRACE",
		"NETIO",
};
template <>
const int EnumName<LogLevel>::listNum = getListNum(EnumName<LogLevel>::list);

LogService* LogService::m_instance = NULL;

LogService* LogService::getInstance()
{
	if (m_instance == NULL)
	{
			m_instance = new LogService();
	}
	return m_instance;
}

LogService::LogService()
{
	m_ioService = NULL;
	m_level = NETIO;
	for (int i = UNKNOW; i <= NETIO; i++)
	{
		m_loggerContainer.push_back(LoggerPtr(new Logger(enumToStr<LogLevel>(i))));
	}
}

void LogService::setName(const string &name)
{
	m_name = name;
}

void LogService::setLogLevel(LogLevel logLevel) throw (out_of_range)
{
	if (levelOutOfRange(logLevel))
	{
		throw out_of_range("invalid log level");
	}
	m_level = logLevel;
}

void LogService::setService(io_service *ioService)
{
	m_ioService = ioService;
}

void LogService::setEnableRecordType(LogLevel logLevel,  LogRecordType recordType)
{
	if (levelOutOfRange(logLevel))
	{
		throw out_of_range("invalid log level");
	}
	try
	{
		m_loggerContainer[logLevel]->setEnableRecordType(recordType);
	}
	catch (const runtime_error & /* error */)
	{
		throw;
	}
}

void LogService::start()
{
	assert(m_ioService);
}

bool LogService::levelOutOfRange(LogLevel logLevel)
{
	if (logLevel < UNKNOW || logLevel > NETIO)
	{
		return true;
	}
	return false;
}

void LogService::log(LogLevel logLevel, const string &code, const string &info, bool asyn /* true */)
{
	if (levelOutOfRange(logLevel))
	{
		throw out_of_range("invalid log level");
	}
	if (logLevel > m_level)
	{
		return;
	}
	string codeStr = code + " " + m_name;
	if (asyn)
	{
		m_ioService->post(bind(&Logger::log, m_loggerContainer[logLevel], codeStr, info));
		return;
	}
	m_loggerContainer[logLevel]->log(codeStr, info);
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
