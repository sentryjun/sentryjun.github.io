/*
 * Logger.cpp
 *
 *  Created on: 2010-5-30
 *      Author: lnl
 */

#include "Logger.h"
#include <iostream>
#include <fstream>
#include <string>
#include <boost/foreach.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/time_facet.hpp>
#include <boost/bind.hpp>
#include "../../Common/enum.h"
#include <time.h>

using namespace PKU_SatLab_DBS_NMC;
using namespace service;

template <>
const EnumNameType EnumName<LogRecordType>::list[] =
{
		"StdOut",
		"StdError",
		"File",
};
template <>
const int EnumName<LogRecordType>::listNum = getListNum(EnumName<LogRecordType>::list);

Logger::Logger(const string &name)
{
	m_name = name;
	memset(m_recordTypeEnabeld, false, sizeof(m_recordTypeEnabeld));
}

void Logger::log(const string& code, const string& info)
{
	std::ostringstream outs;
	outs.str("");
	outs << m_name << " "<< code << " ";
	boost::posix_time::ptime now = boost::posix_time::second_clock::local_time(); //use the clock
	boost::posix_time::time_facet* output_facet = new boost::posix_time::time_facet();
	output_facet->format("%Y-%m-%d %H:%M:%S");
	outs.imbue(std::locale(outs.getloc(), output_facet));
	outs << now << " " << info;
	logHandler(outs.str());
}

void Logger::setEnableRecordType(LogRecordType logType) throw(runtime_error)
{
	if (m_recordTypeEnabeld[logType])
	{
		return;
	}
	m_recordTypeEnabeld[logType] = true;
	switch (logType)
	{
	case StdOut:
		m_recorderContainer.push_back(&cout);
		break;
	case StdError:
		m_recorderContainer.push_back(&cerr);
		break;
	case File:
	{
		ofstream *file = new ofstream;
		RecorderPtr recorderPtr = RecorderPtr(file);
		ostringstream ostr;
		struct tm *tmm;
		time_t tv_now;
		time(&tv_now);
		tmm = localtime(&tv_now);
		ostr << m_name << 1900+tmm->tm_year << tmm->tm_mon+1 << tmm->tm_mday << tmm->tm_hour << tmm->tm_min << tmm->tm_sec;
		file->open(ostr.str().c_str());
		//file->open(m_name.c_str());
		if (!file->is_open())
		{
			throw runtime_error("unable to create file: " + m_name);
		}
		m_recorderContainer.push_back(file);
		m_recorderPtrContainer.push_back(recorderPtr);
		break;
	}
	}
}

void Logger::logHandler(const string& log)
{
	if (log.size() == 0)
		return;
	BOOST_FOREACH(RecorderContainer::value_type &recorder, m_recorderContainer)
	{
			(*recorder) << log << endl;
	}
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
