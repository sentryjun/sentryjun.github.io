/*
 * Logger.h
 *
 *  Created on: 2010-5-30
 *      Author: lnl
 */

#ifndef NMC_SERVICE_SRC_SERVICE_LOGGER_H_
#define NMC_SERVICE_SRC_SERVICE_LOGGER_H_

#include <list>
#include <ostream>
#include <stdexcept>
#include <boost/smart_ptr.hpp>
using namespace std;
using namespace boost;

namespace PKU_SatLab_DBS_NMC
{
	namespace service
	{
		enum LogRecordType
		{
			StdOut = 0,
			StdError = 1,
			File = 2,
		};

		class Logger
		{
			typedef boost::shared_ptr<ostream> RecorderPtr;
			typedef list<RecorderPtr> RecorderPtrContainer;
			typedef list<ostream *> RecorderContainer;

			public:
				Logger(const string &);
				void log(const string &, const string &);
				void setEnableRecordType(LogRecordType) throw(runtime_error);

			private:
				void logHandler(const string &);

				string m_name;
				bool m_recordTypeEnabeld[3];
				RecorderPtrContainer m_recorderPtrContainer;
				RecorderContainer m_recorderContainer;
		};
	}
}

#endif /* NMC_SERVICE_SRC_SERVICE_LOGGER_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
