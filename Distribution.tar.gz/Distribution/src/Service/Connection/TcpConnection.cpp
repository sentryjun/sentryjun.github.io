#include "TcpConnection.h"
#include <boost/bind.hpp>
#include <iostream>
#include "UdpConnection.h"
#include "../Timer/TimerService.h"

using namespace PKU_SatLab_DBS_NMC;

TcpConnection::TcpConnection(io_service *ioService) :
	m_ioService(*ioService)
{
	m_strand.reset(new StrandType(m_ioService));
	m_socket.reset(new SocketType(m_ioService));
	m_readLen = 0;
	m_hasError = false;
	m_reconnect = false;
    m_timer.reset(service::TimerService::getInstance()->newTimer());
}

TcpConnection::~TcpConnection()
{
}

tcp::socket *TcpConnection::getSocket()
{
	return m_socket.get();
}

io_service *TcpConnection::getService()
{
	return &m_ioService;
}

void TcpConnection::connect(const string &ip, const int port)
{
	m_socket->async_connect(EndpointType(address::from_string(ip), port),
			m_strand->wrap(bind(&TcpConnection::connectHandler, this, _1,
					shared_from_this())));
}

void TcpConnection::connect(EndpointType & endpoint) {
    m_socket->async_connect(endpoint,
                            m_strand->wrap(bind(&TcpConnection::connectHandler, this, _1,
                                                shared_from_this())));
}

void TcpConnection::disconnect()
{
	m_strand->dispatch(bind(&TcpConnection::disconnectHandler, this,
			shared_from_this()));
}

void TcpConnection::checkDelete()
{
	m_strand->dispatch(bind(&TcpConnection::checkDeleteHandler, this,
			shared_from_this()));
}

void TcpConnection::checkDeleteHandler(ConnectionPtr &self)
{
	if (hasError())
	{
		messageReadSignal.disconnect_all_slots();
		messageReadSignal("");
		connectionErrorSignal.disconnect_all_slots();
		connectionErrorSignal("");
	}
}

void TcpConnection::startReceive()
{
	boost::asio::socket_base::keep_alive alive(true);
	m_socket->set_option(alive);
	this->asyncReadLen();
}

void TcpConnection::write(const string &message)
{
	m_strand->dispatch(bind(&TcpConnection::asyncWriteHandler, this, message,
			shared_from_this()));
}

void TcpConnection::blockWrite(const string &message)
{
	int len = message.length();
	Error error;
	asio::write(*m_socket, buffer(string(reinterpret_cast<const char *> (&len),
		4) + message), transfer_all(), error);
	ConnectionPtr conn = shared_from_this();
	writeCompleteHandler(error, conn);
}

void TcpConnection::asyncWriteHandler(const string &message,
		ConnectionPtr &connection)
{
	int len = message.length();
	//	async_write(*m_socket, buffer(string(reinterpret_cast<const char *> (&len),
	//			4) + message), bind(&TcpConnection::writeCompleteHandler, this, _1, connection));
	Error error;

	asio::write(*m_socket, buffer(string(reinterpret_cast<const char *> (&len),
			4) + message), transfer_all(), error);
	writeCompleteHandler(error, connection);
}

bool TcpConnection::isConnected() const
{
	return m_socket->is_open();
}

bool TcpConnection::hasError() const
{
	return m_hasError;
}

inline void TcpConnection::asyncReadLen()
{
	async_read(*m_socket, buffer(&m_readLen, 4), bind(
			&TcpConnection::asyncReadContent, this, _1, shared_from_this()));
}

void TcpConnection::disconnectHandler(ConnectionPtr &self)
{
	doDisconnect();
}

void TcpConnection::doDisconnect()
{
	if (isConnected())
	{
		Error error;
		m_socket->close(error);
	}
}

void TcpConnection::asyncReadContent(const Error &error,
		ConnectionPtr &connection)
{
	if (!error)
	{
		if (m_readLen <= 0 || m_readLen > MaxBufferSize)
		{
			errorHandler("invalid read length or exceeded max buffer length!");
			return;
		}
		m_buffer.reset(new char[m_readLen]);
		async_read(*m_socket, buffer(m_buffer.get(), m_readLen), bind(
				&TcpConnection::readCompleteHandler, this, _1,
				shared_from_this()));
	}
	else
	{
		errorHandler(error.message());
	}
}

void TcpConnection::readCompleteHandler(const Error &error,
		ConnectionPtr &self)
{
	if (!error)
	{
		string message(m_buffer.get(), m_readLen);
		m_buffer.reset();
		m_ioService.post(bind(&TcpConnection::emitReadyReadSignal, this, message, self));
		startReceive();
	}
	else
	{
		errorHandler(error.message());
	}
}

void TcpConnection::writeCompleteHandler(const Error &error,
		ConnectionPtr &connection)
{
	if (error)
	{
		errorHandler(error.message());
	}
}

void TcpConnection::connectHandler(const Error &error,
		ConnectionPtr &connection)
{
    if (m_reconnect = true) {
        m_reconnect = false;
    }
	if (error)
	{
		errorHandler(error.message());
		return;
	}
	emitConnectSignal();
}

void TcpConnection::errorHandler(const string &error)
{
	m_hasError = true;
	m_strand->dispatch(bind(&TcpConnection::disconnectHandler, this, shared_from_this()));
	connectionErrorSignal(error);
}

void TcpConnection::emitReadyReadSignal(const string &message, ConnectionPtr &self)
{
	messageReadSignal(message);
}

void TcpConnection::emitConnectSignal()
{
    if (m_reconnect == true) {
        m_reconnect = false;
    }
	connectionConnectedSignal();
}

void TcpConnection::reconnect(EndpointType &endpoint) {
    //bindLocalPort();
    if (m_reconnect == false) {
        m_reconnect = true;
    }
    connect(endpoint);
}

void TcpConnection::setTimer() {
    m_timer.reset(service::TimerService::getInstance()->newTimer());
    m_timer->setInterval(5000);
    m_timer->setSingleShot(true);
    m_timer->start();
}

void TcpConnection::reconnectHandler(EndpointType & endpoint) {
    if (m_reconnect == true) {
        return;
    }
    setTimer();
    m_timer->timeoutSignal.connect(bind(&TcpConnection::reconnect, this, endpoint));
}

void TcpConnection::setLocalPort(int port) {
    sendPort = port;
    bindLocalPort();
}

void TcpConnection::bindLocalPort() {
    if(!isConnected())
        m_socket->open(tcp::v4());

        m_socket->bind(EndpointType(tcp::v4(), sendPort));
}

//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
