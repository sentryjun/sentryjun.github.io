/*
 * udp_connection.cpp
 *
 *  Created on: 2010-10-13
 *      Author: nile
 */

#include "UdpConnection.h"
#include <boost/bind.hpp>

using namespace PKU_SatLab_DBS_NMC;

/* max number of network interfaces*/
#define MAX_IF 5

/* Path to the route entry in proc filesystem */
#define PROCROUTE "/proc/net/route"

/* file containing the hostname of the machine */
/* This is the name for slackware and redhat */

#define HOSTFILE "/etc/HOSTNAME"

/* and this is the name for debian */
/* #define HOSTFILE "/etc/HOSTNAME" */

#ifndef SIOCGIFCOUNT
#define SIOCGIFCOUNT 0x8935
#endif

char iface[16];
char ipaddr[17];
char *ifface = NULL;

void *xrealloc(void *oldp, size_t sz)
{
	void *p = realloc(oldp, sz);
	if (!p)	printf("out of virtual memory\n");
	return p;
}


/* This searches the proc routing entry for the interface the default gateway
  * is on, and returns the name of that interface.
  */

void set_netname(const char *netname)
{
	if (strlen(netname) < 16) {
		sprintf(iface, "%s", netname);
	}else {
		memcpy(iface, netname, 15);
		iface[15] = '\0';
	}
	ifface = iface;
}


char *getdefaultdev()
{
	FILE *fp;
	char buff[4096], gate_addr[128], net_addr[128];
	char mask_addr[128];
	int irtt, window, mss, hh, arp, num, metric, refcnt, use;
	unsigned int iflags;
	char i;
	if (ifface != NULL) return ifface;
	fp = fopen( PROCROUTE, "r");
	if( !fp ) {
		perror("fopen '/proc/net/route' error :");
		return NULL;
	}
	i=0;


// cruise through the list, and find the gateway interface
	while( fgets(buff, 1023, fp) ) {
		num = sscanf(buff, "%s %s %s %X %d %d %d %s %d %d %d %d %d\n",
			iface, net_addr, gate_addr, &iflags, &refcnt, &use, &metric,
			mask_addr, &mss, &window, &irtt, &hh, &arp);
		i++;
		if( i == 1) continue;
		if( iflags & 0x0002 ) {//RTF_GATEWAY
			ifface = iface;
			return ifface;
		}
	}
	fclose(fp);
/* didn't find a default gateway */
	return NULL;
}


char *findmyIp( void )
{
	int sock, err, if_count, i, j = 0;
	struct ifconf netconf;
	char buffer[32*MAX_IF];
	char if_name[10][21];
	char if_addr[10][21];
	char *default_ifName;
	netconf.ifc_len = 32 * MAX_IF;//sizeof(struct ifreq) = 32
	netconf.ifc_buf = buffer;
	sock=socket( PF_INET, SOCK_DGRAM, 0 );
	if (sock < 0) return NULL;
	err=ioctl( sock, SIOCGIFCONF, &netconf );
	close( sock );
	if ( err < 0 ) {
		printf( "Error in ioctl: %i.\n", errno );
		return NULL;
	}
	if_count = netconf.ifc_len / 32;
	if ( if_count == 1 ) {
		strncpy( if_name[j], netconf.ifc_req[0].ifr_name, 20 );
		strncpy( if_addr[j], inet_ntoa(((struct sockaddr_in*)(&netconf.ifc_req[0].ifr_addr))->sin_addr), 20 );
		j++;
	} else {
		for ( i = 0; i < if_count; i++ ) {
			if ( strcmp( netconf.ifc_req[i].ifr_name, "lo" ) != 0
					&& strncmp( netconf.ifc_req[i].ifr_name, "vmnet", 5) != 0) {
				strncpy( if_name[j], netconf.ifc_req[i].ifr_name, 20 );
				strncpy( if_addr[j], inet_ntoa(((struct sockaddr_in*)(&netconf.ifc_req[i].ifr_addr))->sin_addr), 20 );
				j++;
				if (j==10)	break;
			}
		}
	}
	if( j == 1 ) {
		sprintf(ipaddr, "%s", if_addr[0]);
	} else {
		default_ifName = getdefaultdev();
		printf("default_if_Name: %s\n",default_ifName);
		if( default_ifName != NULL) {
			for( i = 0; i < j; i++ ) {
				if( strcmp( if_name[i], default_ifName ) == 0 ) {
					sprintf(ipaddr, "%s", if_addr[i]);
				}
			}
		} else {
			default_ifName = "";
			for( i = 0; i < j; i++ ) {
				if( strcmp( if_name[i], default_ifName ) != 0 ) {
					if( i == j-1 ) {
						sprintf(ipaddr, "%s", if_addr[i]);
					} else {
						sprintf(ipaddr, "%s", if_addr[i]);
					}
				}
			}
		}
	}

	return ipaddr;
}



UdpConnection::UdpConnection(io_service *ioService, unsigned short port, bool setlocalip)
#ifdef USE_MYIPAND_161_162
: m_socket(*ioService, udp::endpoint(ip::address_v4::from_string(findmyIp()), port)),m_strand(*ioService)
#else
:m_socket(*ioService, udp::endpoint(udp::v4(), port)), m_strand(*ioService)
#endif
{
//	if (setlocalip)
//		m_socket = *(new udp::socket(*ioService, udp::endpoint(ip::address_v4::from_string(findmyIp()), port)));
//	else
//		m_socket = udp::socket(*ioService, udp::endpoint(udp::v4(), port));
//	m_strand = *(new strand(*ioService));
	m_ioService = ioService;
}

void UdpConnection::startReceive()
{
	m_socket.async_receive_from(buffer(m_readBuffer, BUFFER_LEN), m_endpoint,
			bind(&UdpConnection::readHandler, this, _1, _2, shared_from_this()));
}

void UdpConnection::readHandler(const Error &error, size_t bytesRead, ConnectionPtr &self)
{
	if (!error)
	{
		try
		{
			m_ioService->post(bind(&UdpConnection::readyRead, this, string(m_readBuffer, bytesRead), m_endpoint, self));
			startReceive();
		}
		catch (...)
		{
			startReceive();
			throw;
		}
	}
	else
	{
		errorHandler(error.message());
	}
}

void UdpConnection::write(const string &message, const Endpoint &endpoint)
{
	m_strand.dispatch(bind(&UdpConnection::asyncWrite, this, message, endpoint, shared_from_this()));
}

void UdpConnection::close()
{
	Error error;
	m_socket.close(error);
}

void UdpConnection::asyncWrite(const string &message, const Endpoint &endpoint, ConnectionPtr &self)
{
	Error error;
	m_socket.send_to(buffer(message), endpoint, 0, error);
	writeHandler(error);
}

void UdpConnection::writeHandler(const Error &error)
{
	if (error)
	{
		errorHandler(error.message());
	}
}

void UdpConnection::errorHandler(const string &message)
{
	connectionErrorHandler(message);
}

void UdpConnection::connectionErrorHandler(const string &message)
{
	connectionErrorSignal(message);
}

void UdpConnection::readyRead(const string &str, const  Endpoint &endpoint, ConnectionPtr &self)
{
	messageReadSignal(str, endpoint);
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
