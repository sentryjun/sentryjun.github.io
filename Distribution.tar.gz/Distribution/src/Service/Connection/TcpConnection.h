#ifndef TCPCONNECTION_H
#define TCPCONNECTION_H

#include <string>
#include <boost/asio.hpp>
#include <boost/shared_array.hpp>
#include <boost/signals2.hpp>
#include <boost/smart_ptr.hpp>

using namespace std;
using namespace boost;
using namespace asio;
using namespace ip;
using namespace signals2;

namespace PKU_SatLab_DBS_NMC
{
    class Timer;
	class TcpConnection: public enable_shared_from_this<TcpConnection>
	{
	public:
		typedef io_service ServiceType;
		typedef tcp::endpoint EndpointType;
		typedef tcp::socket SocketType;
		typedef boost::shared_ptr<SocketType> SocketPtr;
		typedef boost::shared_ptr<TcpConnection> ConnectionPtr;
		typedef boost::shared_ptr<Timer> TimerPtr;

	public:
		TcpConnection(ServiceType *);
		~TcpConnection();

		void connect(const string&, const int);
		void connect(EndpointType &);
		void startReceive();
		void write(const string &);
		void blockWrite(const string &);
		tcp::socket *getSocket();
		io_service *getService();
		void checkDelete();
		void disconnect();
		bool isConnected() const;
		bool hasError() const;
        void setTimer();
        void reconnectHandler(EndpointType &);
        void setLocalPort(int port);
        void resetConnect(EndpointType &);
        void resetConnectHandler(EndpointType &);
        boost::signals2::signal<void(const string &)> messageReadSignal;
		boost::signals2::signal<void(const string &)> connectionErrorSignal;
		boost::signals2::signal<void()> connectionConnectedSignal;
		boost::signals2::signal<void()>resetConnectionSignal;

	private:
	private:
		typedef boost::scoped_ptr<EndpointType> EndpointPtr;
		typedef boost::system::error_code Error;
		typedef boost::asio::strand StrandType;
		typedef boost::scoped_ptr<StrandType> StrandPtr;


		void disconnectHandler(ConnectionPtr &);
		void doDisconnect();
		void asyncReadLen();
		void asyncReadContent(const Error &, ConnectionPtr &);
		void readCompleteHandler(const Error &, ConnectionPtr &);
		void asyncWriteHandler(const string &, ConnectionPtr &);
		void writeCompleteHandler(const Error &, ConnectionPtr &);
		void connectHandler(const Error &, ConnectionPtr &);
		void newMessageHandler(const string &, ConnectionPtr &);
		void checkDeleteHandler(ConnectionPtr &);
		void errorHandler(const string &);
		void emitReadyReadSignal(const string &, ConnectionPtr &self);
		void emitConnectSignal();
		void emitErrorSignal(const string &);
		void setSocket();
        void bindLocalPort();
        void reconnect(EndpointType &endpoint);
		enum
		{
			MaxBufferSize = 10485760,
		/* 10M */
		};
		ServiceType &m_ioService;
		EndpointPtr m_endpoint;
		StrandPtr m_strand;
		SocketPtr m_socket;
		TimerPtr m_timer;
		int m_readLen;
		int sendPort;
		scoped_array<char> m_buffer;
		bool m_hasError;
		bool m_reconnect;
	};
} // namespace PKU_SatLab_DBS_NMC

#endif // TCPCONNECTION_H
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
