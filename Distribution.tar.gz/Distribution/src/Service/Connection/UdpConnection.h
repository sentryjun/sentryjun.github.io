/*
 * udp_connection.h
 *
 *  Created on: 2010-10-13
 *      Author: nile
 */

#ifndef UDPCONNECTION_H_
#define UDPCONNECTION_H_

#include <boost/asio.hpp>
#include <boost/signals2.hpp>
#include <boost/thread.hpp>
#include <boost/enable_shared_from_this.hpp>
using namespace std;
using namespace boost;
using namespace asio;
using namespace ip;
using namespace signals2;


//#define USE_MYIPAND_161_162


void set_netname(const char *netname);
char *findmyIp( void );

namespace PKU_SatLab_DBS_NMC
{
	class UdpConnection : public enable_shared_from_this<UdpConnection>
	{
	public:
		typedef udp::endpoint Endpoint;
		typedef boost::system::error_code Error;

	public:
		UdpConnection(io_service *, unsigned short, bool setlocalip = true);

		void startReceive();
		void write(const string &, const Endpoint &);
		void close();

		boost::signals2::signal<void(const string &, const Endpoint &)> messageReadSignal;
		boost::signals2::signal<void(const string &)> connectionErrorSignal;

	private:
		typedef boost::shared_ptr<UdpConnection> ConnectionPtr;

		void asyncWrite(const string &, const Endpoint &, ConnectionPtr &);
		void readHandler(const Error &, size_t, ConnectionPtr &);
		void writeHandler(const Error &);
		void errorHandler(const string &);
		/* async emit signal handler */
		void readyRead(const string &str, const  Endpoint &endpoint, ConnectionPtr &self);
		void connectionErrorHandler(const string &);

		enum
		{
			BUFFER_LEN = 65536,
		};

		io_service *m_ioService;
		udp::socket m_socket;
		Endpoint m_endpoint;
		strand m_strand;
		char m_readBuffer[BUFFER_LEN];
	};
} // namespace PKU_SatLab_DBS_NMC

#endif /* UDPCONNECTION_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
