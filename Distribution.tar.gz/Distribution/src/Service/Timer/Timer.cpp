/*
 * Timer.cpp
 *
 *  Created on: 2010-11-12
 *      Author: nile
 */

#include "Timer.h"
#include <boost/bind.hpp>

using namespace boost::asio;
using namespace PKU_SatLab_DBS_NMC;

Timer::Timer(boost::asio::io_service *ioService)
	: m_timer(*ioService), m_interval(1000), m_singleShot(true)
{
	m_ioService = ioService;
}

int Timer::interval() const
{
	return m_interval;
}

bool Timer::isSingleShot() const
{
	return m_singleShot;
}

void Timer::setInterval(int msec)
{
	m_interval = msec;
}

void Timer::setSingleShot(bool singleShot)
{
	m_singleShot = singleShot;
}

void Timer::start()
{
	m_stop = false;
	try
	{
		m_timer.expires_from_now(boost::posix_time::millisec(m_interval));
		m_timer.async_wait(boost::bind(&Timer::timeoutHandler, this, _1, shared_from_this()));
	}
	catch (const Error &error)
	{
		throw std::runtime_error(error.message());
	}
}

void Timer::start(int msec)
{
	m_stop = false;
	try
	{
		m_timer.expires_from_now(boost::posix_time::millisec(msec));
		m_timer.async_wait(boost::bind(&Timer::timeoutHandler, this, _1, shared_from_this()));
	}
	catch (const Error &error)
	{
		throw std::runtime_error(error.message());
	}
}

void Timer::stop()
{
	m_stop = true;
	try
	{
		m_timer.cancel();
		return;
	}
	catch (const Error &/* error */)
	{
	}
	handlerInvokedSignal();
}

io_service *Timer::getService()
{
	return m_ioService;
}

void Timer::timeoutHandler(const Error &error, TimerPtr self)
{
	if (m_stop)
	{
		return;
	}
	if (!m_singleShot)
	{
		start();
	}
	if (!error)
	{
		signalHandler();
		return;
	}
	if (error == error::operation_aborted)
	{
		return;
	}
	throw std::runtime_error(error.message());
}

void Timer::signalHandler()
{
	timeoutSignal();
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
