/*
 * TimerService.cpp
 *
 *  Created on: 2011-1-3
 *      Author: nile
 */

#include "TimerService.h"

using namespace PKU_SatLab_DBS_NMC;
using namespace service;

TimerService *TimerService::m_instance = NULL;

TimerService::TimerService()
{
	m_ioService = NULL;
}

TimerService *TimerService::getInstance()
{
	if (m_instance == NULL)
	{
		m_instance = new TimerService();
	}
	return m_instance;
}

void TimerService::setService(io_service *ioService)
{
	m_ioService = ioService;
}

void TimerService::start()
{
	assert(m_ioService);
}

Timer *TimerService::newTimer()
{
	return new Timer(m_ioService);
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
