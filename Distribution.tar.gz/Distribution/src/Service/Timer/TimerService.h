/*
 * TimerService.h
 *
 *  Created on: 2011-1-3
 *      Author: nile
 */

#ifndef TIMERSERVICE_H_
#define TIMERSERVICE_H_

#include <boost/asio.hpp>
#include "Timer.h"
using namespace boost;
using namespace asio;

namespace PKU_SatLab_DBS_NMC
{
	namespace service
	{
		class TimerService
		{
		public:
			static TimerService* getInstance();
			void setService(io_service *);
			void start();
			Timer *newTimer();

		private:
			TimerService();

			static TimerService* m_instance;
			io_service *m_ioService;
		};
	}
}

#endif /* TIMERSERVICE_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
