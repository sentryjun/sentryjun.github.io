/*
 * Timer.h
 *
 *  Created on: 2010-11-12
 *      Author: nile
 */

#ifndef TIMER_H_
#define TIMER_H_

#include <stdexcept>
#include <boost/asio.hpp>
#include <boost/signals2.hpp>
#include <boost/enable_shared_from_this.hpp>
using namespace std;
using namespace boost;
using namespace asio;

namespace PKU_SatLab_DBS_NMC
{
	class Timer : public enable_shared_from_this<Timer>
	{
	public:
		typedef boost::shared_ptr<Timer> TimerPtr;
		typedef boost::system::error_code Error;

	public:
		Timer(io_service *ioService);
		int interval() const;
		bool isSingleShot() const;
		void setInterval(int msec);
		void setSingleShot(bool singleShot);
		/* start or restart the timer */
		void start();
		void start(int msec);
		void stop();
		io_service *getService();

		boost::signals2::signal<void ()> timeoutSignal;
		/* this signal emit if stop called while handler already invoked */
		boost::signals2::signal<void ()> handlerInvokedSignal;

	private:
		void timeoutHandler(const Error &error, TimerPtr);
		void signalHandler();

		io_service *m_ioService;
		deadline_timer m_timer;
		int m_interval;
		bool m_singleShot;
		bool m_stop;
	};
}

#endif /* TIMER_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
