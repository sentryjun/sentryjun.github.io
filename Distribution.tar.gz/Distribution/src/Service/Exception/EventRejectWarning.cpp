///*
// * EventRejectWarning.cpp
// *
// *  Created on: 2011-1-26
// *      Author: nmc
// */
//
//#include "EventRejectWarning.h"
//
//using namespace PKU_SatLab_DBS_NMC::service;
//
//EventRejectWarning::EventRejectWarning(NMCSbdnObject* event, string description) : WarningMessage(4, 2, event->getObjectID().GetID()) {
//	// TODO Auto-generated constructor stub
//	this->AddDescription(description);
//}
//
//EventRejectWarning::~EventRejectWarning() {
//	// TODO Auto-generated destructor stub
//}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
