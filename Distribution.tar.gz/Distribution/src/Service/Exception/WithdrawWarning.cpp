///*
// * WithdrawWarning.cpp
// *
// *  Created on: 2011-1-26
// *      Author: nmc
// */
//
//#include "WithdrawWarning.h"
//#include "../../Parser/XmlParser.h"
//
//using namespace PKU_SatLab_DBS_NMC::service;
//using namespace PKU_SatLab_DBS_NMC::Parser;
//
//WithdrawWarning::WithdrawWarning(WarningMessage& msg, string description) : m_seq(msg.GetSeqNo()), m_objectid(msg.GetObjectID()),
//		m_objectVersion(msg.GetObjectVersion()) {
//	// TODO Auto-generated constructor stub
//	time_t now;
//	time(&now);
//	m_time = now;
//	m_description = description;
//}
//
//WithdrawWarning::~WithdrawWarning() {
//	// TODO Auto-generated destructor stub
//}
//
//int WithdrawWarning::GetContent(string& xml, int seq)
//{
//	TiXmlDocument doc;
//	TiXmlDeclaration* pDecl = new TiXmlDeclaration( "1.0", "UTF-8", "" );
//	doc.LinkEndChild(pDecl);
//
//	TiXmlElement *pControl = new TiXmlElement("Control");
//	doc.LinkEndChild(pControl);
//
//	TiXmlElement *pAction = XmlParser::addIntChild(pControl, "Action", 20023);
//	if(pAction == NULL)
//		return 0;
//
//	TiXmlElement *pSeq = XmlParser::addIntChild(pAction, "Seq", seq);
//	if(pSeq == NULL)
//		return 0;
//
//	TiXmlElement *pWarning = XmlParser::addIntChild(pAction, "CancelWarning", m_seq);
//	if(pWarning == NULL)
//		return 0;
//
//	TiXmlElement *pObjectid = XmlParser::addStringChild(pWarning, "Object", m_objectid);
//	if(pObjectid == NULL)
//		return 0;
//
//	TiXmlElement *pObjectVersion = XmlParser::addStringChild(pWarning, "ObjectVersion", m_objectVersion);
//	if(pObjectVersion == NULL)
//		return 0;
//
//	TiXmlElement *pTime = XmlParser::addInt64Child(pWarning, "Time", m_time);
//	if(pTime == NULL)
//		return 0;
//
//	TiXmlElement *pDescription = XmlParser::addStringChild(pWarning, "Description", m_description);
//	if(pDescription == NULL)
//		return 0;
//
//	TiXmlPrinter printer;
//	printer.SetIndent( "\t" );
//	doc.Accept( &printer );
//	xml = printer.CStr();
//	return xml.size();
//}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
