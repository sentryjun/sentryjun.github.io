/*
 * WarningMessage.h
 *
 *  Created on: 2011-1-26
 *      Author: nmc
 */

#ifndef WARNINGMESSAGE_H_
#define WARNINGMESSAGE_H_
#include <iostream>
#include <string>

using namespace std;
namespace PKU_SatLab_DBS_NMC
{
	class WarningMessage
	{
	public:
		WarningMessage();
		virtual ~WarningMessage();

		enum WarningLevel
		{
			Notice = 0,
			Warning,
			Critical,
		};
		enum WarningType
		{
			Event = 0,
			Device,
		};

		void setLevel(WarningLevel level);
		void setDescription(const string &description);
		void setObjectID(const string &objectid);
		void setType(WarningType type);
		void setUnitName(const string &name);
		void setSeq(int seq);

		string toStr() const;

	private:
		int m_seq;
		WarningLevel m_level;
		WarningType m_type;
		string m_objectid;
		string m_name;
		time_t m_time;
		string m_description;
	};

}
#endif /* WARNINGMESSAGE_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
