///*
// * WithdrawWarning.h
// *
// *  Created on: 2011-1-26
// *      Author: nmc
// */
//
//#ifndef WITHDRAWWARNING_H_
//#define WITHDRAWWARNING_H_
//
//#include "WarningMessage.h"
//
//namespace PKU_SatLab_DBS_NMC {
//namespace service {
//
//class WithdrawWarning {
//public:
//	WithdrawWarning(WarningMessage& msg, string description);
//	virtual ~WithdrawWarning();
//	virtual int GetContent(string& xml, int seq);
//
//private:
//	int m_seq;
//	string m_objectid;
//	string m_objectVersion;
//	time_t m_time;
//	string m_description;
//};
//
//}
//}
//#endif /* WITHDRAWWARNING_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
