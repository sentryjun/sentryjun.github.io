
#ifndef NMC_SERVICE_SRC_SERVICE_EXCEPTIONSERVICE_H_
#define NMC_SERVICE_SRC_SERVICE_EXCEPTIONSERVICE_H_

#include <string>
#include <vector>
#include <set>
#include <map>
#include <boost/asio.hpp>
#include <boost/signals2.hpp>
#include <boost/function.hpp>
#include <boost/thread.hpp>

#include "WarningMessage.h"
using namespace std;
using namespace boost;
using namespace asio;
using namespace signals2;

namespace PKU_SatLab_DBS_NMC
{
	namespace service
	{
		class ExceptionService
		{
		public:
			static ExceptionService *getInstance();

			void setService(io_service *);
			void start();
			void sendWarning(const WarningMessage &warning);


		private:
			ExceptionService();
			void doSendWarning(const WarningMessage &warning);
			typedef boost::shared_ptr<strand> StrandPtr;

			static ExceptionService *m_instance;
			io_service *m_ioService;
			StrandPtr m_strand;
		};

	} // namespace service
} // namespace PKU_SatLab_DBS_NMC

#endif // NMC_SERVICE_SRC_SERVICE_EXCEPTIONSERVICE_H_
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
