/*
 * WarningMessage.cpp
 *
 *  Created on: 2011-1-26
 *      Author: nmc
 */

#include "WarningMessage.h"
#include "../../Parser/XmlParser.h"
#include <boost/thread.hpp>

using namespace PKU_SatLab_DBS_NMC;
using namespace Parser;

boost::mutex threadMutex;
unsigned int seq = 0;

WarningMessage::WarningMessage()
{
	m_time = time(NULL);
	boost::mutex::scoped_lock lock(threadMutex);
	m_seq = seq ++;
}

WarningMessage::~WarningMessage()
{
}

void WarningMessage::setDescription(const string &description)
{
	m_description = description;
}

void WarningMessage::setLevel(WarningLevel level)
{
	m_level = level;
}

void WarningMessage::setObjectID(const string &objectid)
{
	m_objectid = objectid;
}

void WarningMessage::setType(WarningType type)
{
	m_type = type;
}

void WarningMessage::setUnitName(const string &name)
{
	m_name = name;
}

void WarningMessage::setSeq(int seq)
{
	m_seq = seq;
}

string WarningMessage::toStr() const
{
	TiXmlDocument doc;
	TiXmlDeclaration* pDecl = new TiXmlDeclaration("1.0", "UTF-8", "");
	doc.LinkEndChild(pDecl);

	TiXmlElement *pControl = new TiXmlElement("Control");
	doc.LinkEndChild(pControl);

	TiXmlElement *pAction = XmlParser::addIntChild(pControl, "Action", 20023);
	if (pAction == NULL)
		return 0;

	TiXmlElement *pSeq = XmlParser::addIntChild(pAction, "Seq", m_seq);
	if (pSeq == NULL)
		return 0;

	ostringstream ostr;
	ostr << m_time << "." << m_seq;

	TiXmlElement *pWarning = XmlParser::addStringChild(pAction, "Warning", ostr.str());
	if (pWarning == NULL)
		return 0;

	TiXmlElement *pLevel = XmlParser::addIntChild(pWarning, "Level", m_level);
	if (pLevel == NULL)
		return 0;

	TiXmlElement *pType = XmlParser::addIntChild(pWarning, "Type", m_type);
	if (pType == NULL)
		return 0;

	TiXmlElement *pObjectid = XmlParser::addStringChild(pWarning, "Object",
			m_objectid);
	if (pObjectid == NULL)
		return 0;

	TiXmlElement *pName = XmlParser::addStringChild(pWarning, "Name",
				m_name);
	if (pName == NULL)
			return 0;

//	TiXmlElement *pObjectVersion = XmlParser::addStringChild(pWarning,
//			"ObjectVersion", ostr.str());
//	if (pObjectVersion == NULL)
//		return 0;

	TiXmlElement *pTime = XmlParser::addInt64Child(pWarning, "Time", m_time);
	if (pTime == NULL)
		return 0;

	TiXmlElement *pDescription = XmlParser::addStringChild(pWarning,
			"Description", m_description);
	if (pDescription == NULL)
		return 0;

	TiXmlPrinter printer;
	printer.SetIndent("\t");
	doc.Accept(&printer);
	return printer.CStr();
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
