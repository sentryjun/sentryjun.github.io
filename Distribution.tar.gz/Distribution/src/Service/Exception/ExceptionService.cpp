#include "ExceptionService.h"
#include "WarningMessage.h"

#include <boost/bind.hpp>
#include <boost/foreach.hpp>

using namespace PKU_SatLab_DBS_NMC;
using namespace service;

ExceptionService* ExceptionService::m_instance = NULL;

ExceptionService* ExceptionService::getInstance()
{
	if (m_instance == NULL)
		m_instance = new ExceptionService();
	return m_instance;
}

ExceptionService::ExceptionService()
{
	m_ioService = NULL;
}

void ExceptionService::setService(io_service *ioService)
{
	m_ioService = ioService;
	m_strand = StrandPtr(new strand(*ioService));
}

void ExceptionService::start()
{
	assert(m_ioService);
}

void ExceptionService::sendWarning(const WarningMessage &warning)
{
	if (m_strand)
	{
		m_strand->dispatch(boost::bind(&ExceptionService::doSendWarning, this,
				warning));
	}
}

void ExceptionService::doSendWarning(const WarningMessage &warning)
{
    //UIService::getInstance()->sendWarning(warning.toStr());
}

//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
