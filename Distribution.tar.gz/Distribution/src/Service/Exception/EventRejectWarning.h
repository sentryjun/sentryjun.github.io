///*
// * EventRejectWarning.h
// *
// *  Created on: 2011-1-26
// *      Author: nmc
// */
//
//#ifndef EVENTREJECTWARNING_H_
//#define EVENTREJECTWARNING_H_
//
//#include "WarningMessage.h"
//#include "../../SbdnObjectImpl/NMCSbdnObject.h"
//
//namespace PKU_SatLab_DBS_NMC {
//namespace service {
//
//class EventRejectWarning: public WarningMessage {
//public:
//	EventRejectWarning(NMCSbdnObject* event, string description);
//	virtual ~EventRejectWarning();
//};
//
//}
//}
//#endif /* EVENTREJECTWARNING_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
