//
// Created by jun on 2021/4/1.
//

#ifndef DISTRIBUTION_FORWARDSERVICE_H
#define DISTRIBUTION_FORWARDSERVICE_H
#include <string>
#include <vector>
#include <map>
#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <boost/signals2.hpp>
#include "../SbdnObjectImpl/NMCDistProgram.h"

using namespace std;
using namespace boost;
using namespace asio;
using namespace ip;
namespace PKU_SatLab_DBS_NMC {
    class TcpConnection;
    namespace service{
        class ForwardService {
            typedef boost::shared_ptr<TcpConnection> ConnectionPtr;
            typedef map<string, ConnectionPtr> ConnectionPool;
            typedef ConnectionPool::value_type ConnectionPoolValue;
            typedef boost::shared_ptr<tcp::endpoint> EndpointPtr;
            typedef map<string, pair<string, int> > IPMap;
            typedef IPMap::value_type IPMapValue;
            typedef boost::system::error_code Error;
            typedef set<NMCDistProgram*> ProgramPool;

        public:
            static ForwardService* getInstance();
            void start();
            void setService(io_service *);
            void setBindport(int port);
            void setChannelIP(int i, const string & ipAddr, int port);
            void initProgram(NMCDistProgram *);
            void accessProgramDisconnectedHandler();
            void distChannelManage(const string &message, const string &distName);
            bool needAccessRegister();
            const string& getRegisterStr();
            const string& getChannelStr();
            bool getIsMaster(){return  isMaster;}
            void receiveChannelMsgHandler(const string &, int32_t);
            void switchMaster();
            void setMaster(bool master);
            void setNeedRegister();
//            boost::signals2::signal<void(const string&, const string &)> synToAccess;
            void setVirtualCard(const string &);
            void setVirtualIP(const string &);
            void stopAllDistProgram();
            void addNewDistProgram(int32_t channel, const string & ipAddr, int port);
            void registerAccessHandler(const string &);
        private:
            ForwardService();
            void onConnectionHandler();
            void connectionErrorHandler(const string&, ConnectionPtr&, EndpointPtr&);
            void dispatchConnectionHandler(const string &, ConnectionPtr&, EndpointPtr&);
            void forwardMessageHandler(const string &, const string &);
            void forwardMessage(const string &, int security);
            
            void switchMasterHandler();
            void initializeMaster();
            void initializeSlave();
            void reStart();

            static ForwardService* m_instance;
            bool isMaster;
            ConnectionPtr  m_connection;
            //ConnectionPool m_connectionMap;
            EndpointPtr m_endpoint;
            io_service * m_ioService;
            boost::mutex m_threadMutex;
            string m_registerMessage;
            string m_replyChannelMessage;
            bool m_registerFlag;
            ProgramPool m_progPool;
            enum {
                SENDPORT = 9999
            };
            string m_virtualIP;
            string m_virtualCard;
        };
    }

}


#endif //DISTRIBUTION_FORWARDSERVICE_H
