//
// Created by nmc on 2021/6/23.
//

#include "MergeService.h"
#include <boost/foreach.hpp>
#include "SynService.h"
#include "Logger/LogService.h"
#include "JSONService.h"
using namespace PKU_SatLab_DBS_NMC;
using namespace service;
using namespace boost;

#define setbit(x,y) x|=(1<<y)
#define clrbit(x,y) x&=~(1<<y)

MergeService* MergeService::_instance = NULL;
MergeService::MergeService() {
    _infoList = INFOList ();
    _infoMap = INFOMap ();
    for (int i = 0; i < CHANNEL_NUM; i++) {
        _activePipe[i] = false;
    }
}

MergeService::~MergeService() {}

MergeService * MergeService::getInstance() {
    if (_instance == NULL) {
        _instance = new MergeService();
    }
    return _instance;
}

void MergeService::messageComeHandler(const string &message, int pipe) {
    MessagePtr msg;
    msg.reset(new NMCEventMessage(message));
    uint32_t requestSeq = msg->getReqSeq();
    int action = msg->getAction();
    if (action == 10002) {
        if (requestSeq <= 1025) {
            distributionToBMC(message, msg->getReqSeq());
        }
        MessageInfoPtr info;
        info.reset(new MessageInfo());
        info->state = 0;
        info->security = 248; //FIXME
        XMLNodePtr action = msg->getActionPtr();
        TiXmlElement * RequestSeqNode = XmlParser::firstChildElementBySeperator(action->ToElement(),
                                                                                "TransactionRequest");
        int reqseq;
        XmlParser::getChildValue(RequestSeqNode, "RequestSeq", reqseq);
        info->requestSeq = reqseq;
        info->channelInfo = 0;
        info->channelNum = getNumberofChannel(_channel);
        info->send = _channel;
        info->success = 0;
        info->reject = _channel;
        info->pool.reset(new MessagePool());
        for (int i = 0; i < CHANNEL_NUM; i++) {
            info->ChannelState[i].active = _activePipe[i];
            info->ChannelState[i].send = _activePipe[i];
        }
        LOG(INFO, "0000", "Insert request seq = " << reqseq)
        {
            MutexType::scoped_lock lock(_mutex);
            _infoMap.insert(make_pair(reqseq, info));
        }
        LOG(DEBUG, "0000", "MergeService Syn Transaction with request seq=" << reqseq << " to Dissem")
        registerRequest(message, msg->getAction());
        return;
    }
    INFOMap ::iterator itor= _infoMap.find(requestSeq);
    MessageInfoPtr info;
    int msgID = msg->getID();
//    if (requestSeq <= 1025) {
//        if (action % 2 == 0) {
//            distributionToBMC(message, msgID % 4 - 1);
//            LOG(INFO,"0000", "Message trasaction request seq = " <<requestSeq << "to BMC")
//            return;
//        } else {
//            synToAccessRequest(message);
//            LOG(INFO,"0000", "MSG transaction request seq = " <<requestSeq << "to Access")
//            return;
//        }
//    }

    if (itor == _infoMap.end()) {
        LOG(INFO, "0000", "Cannot find transaction where request seq = " <<requestSeq)
        return;
    }
    info = itor->second;
    MessageInfo * infoptr = info.get();
    switch(action) {
        case 10001:
            if (infoptr->state == 0){
                {
                    MutexType::scoped_lock lock(infoptr->mutex);
                    //int channel = msg->getChannel();
                    infoptr->channelInfo |= (1 << (pipe));
                    //infoptr->ChannelState[channel].msg = msg;
                    //infoptr->ChannelState[channel].state = msg->getState();
                    infoptr->pool->push_back(msg);
                    if (msg->getState() == 9000) {
                        infoptr->reject &= ~(1<<(pipe));
                    }
                    if (mergeInfoHandler(infoptr, 10001)) {
                        infoptr->state = 1;
                        infoptr->channelInfo = 0;
                    }
                }
            }
            break;
        case 10007:
            if (infoptr->state == 2){
                {
                    MutexType::scoped_lock lock(infoptr->mutex);
                    //int channel = msg->getChannel();
                    int channel = pipe;
                    infoptr->channelInfo |= (1 << (channel));
                    infoptr->success |= (1 << (channel));
                    infoptr->pool->push_back(msg);
                    //synToAccessRequest(message);
                }

                if (infoptr->success !=(infoptr->send & infoptr->reject)) {
                    //synToAccessRequest(message);
                    }
                    mergeInfoHandler(infoptr, 10007);
                    if ((infoptr->send & infoptr->reject) == info->success) {
                        clearMsg(requestSeq);
                    }


            }
            break;
        case 10012:
            if (infoptr->state == 1) {
                {
                    MutexType::scoped_lock lock(infoptr->mutex);
                    infoptr->state = 2;
                    distributionToBMC(message, infoptr->security);
                }
            }
            break;
        case 10004:
            distributionToBMC(message, info->security);
            break;
        case 10003:
            infoptr->pool->push_front(msg);
            mergeInfoHandler(infoptr, 10003);
            break;
        case 10005:
        {
            MutexType ::scoped_lock lock(infoptr->mutex);
//            int channel = msg->getChannel();
            infoptr->send &= ~(1<<(pipe));
            infoptr->pool->push_front(msg);
            mergeInfoHandler(infoptr, 10005);
            if (infoptr->success == (infoptr->send & infoptr->reject)) {
                mergeInfoHandler(infoptr, 10001);
            }
            if (info->send == 0) {
                clearMsg(requestSeq);
            }
        }
        break;
        case 10006:
            distributionToBMC(message, infoptr->security);
            break;
        case 10018:
            distributionToBMC(message, infoptr->security);
            break;
        case 10016:
            distributionToBMC(message, infoptr->security);
            break;

    }
}

uint16_t MergeService::getNumberofChannel(uint16_t channelInfo) {
    uint16_t res = channelInfo;
    res = (res & 0x5555) + (res >> 1 & 0x5555);
    res = (res & 0x3333) + (res >> 2 & 0x3333);
    res = (res & 0x0f0f) + (res >> 4 & 0x0f0f);
    res = (res & 0x00ff) + (res >> 8 & 0x00ff);
    return res;
}

bool MergeService::mergeInfoHandler(MessageInfo* info, int action) {
    if (action == 10001) {
        int res = 0;
    }
    if (action == 10001 && info->channelInfo != info->send) {
        //FIXME 要修改成和安全计相关的

        return false;
    }
//    if (action == 10007 && info->success != info->send) {
//
//        return false;
//    }
    int n = info->pool->size();
    MessagePtr msg = info->pool->front();
    XMLNodePtr root = msg->getRootPtr();
    string ss;
//    info->pool->pop_front();

    if (action == 10001) {
        while (!info->pool->empty()) {
            msg = info->pool->front();
            root = msg->getRootPtr();
            info->pool->pop_front();
            if (msg->getState() != 9000) {
                break;
            }
        }
        if (msg->getState() != 9000) {


#ifndef SINGLEEVENT
        TiXmlElement *event = XmlParser::firstChildElementBySeperator(root.get()->ToElement(),
                                                                      "Action.AccessProgram.EventList.Event.Parameter");
        while (!info->pool->empty()) {
            MessagePtr nextMsg = info->pool->front();
            int state = nextMsg->getState();
            if (state == 9000) {
                info->pool->pop_front();
                continue;
            }
            XMLNodePtr eventNode = nextMsg->getEventPtr();
            TiXmlNode *nextHop = XmlParser::firstChildElementBySeperator(eventNode.get()->ToElement(),
                                                                         "Parameter.NextHop")->Clone();
            event->LinkEndChild(nextHop);
            info->pool->pop_front();
        }
#else
        TiXmlElement *event = XmlParser::firstChildElementBySeperator(root.get()->ToElement(),
                                                                      "Action.AccessProgram.EventList");
        while (!info->pool->empty()) {
            MessagePtr nextMsg = info->pool->front();
            XMLNodePtr eventNode = nextMsg->getEventPtr();
            TiXmlNode *nextHop = eventNode->Clone();
            event->LinkEndChild(nextHop);
            info->pool->pop_front();
        }
#endif
    }
    }
    if (action == 10007) {
        {
            MutexType::scoped_lock lock(info->mutex);
            while (!info->pool->empty()) {
                msg = info->pool->front();
                root = msg->getRootPtr();
                info->pool->pop_front();
                XmlParser::xmlToStr(root->ToElement(), ss);
                synToAccessRequest(ss);
            }
        }
    }
    else {
    XmlParser::xmlToStr(root->ToElement(), ss);
    synToAccessRequest(ss);}
    return true;
}


void MergeService::clearMsg(uint32_t request) {
    {
        MutexType::scoped_lock lock(_mutex);
        INFOMap::iterator itor = _infoMap.find(request);
        if (itor != _infoMap.end()) {
        _infoMap.erase(itor);
        }
        LOG(INFO, "0000", "Delete Transaction where requset id = " << request)
    }
}

void MergeService::Start() {
    SynService::getInstance()->synToDistributionSignal.connect(bind(&MergeService::messageComeHandler,this, _1, 0));
    JSONService::switchMasterRequest.connect(bind(&MergeService::switchMasterHandler, this));
    NMCDistProgram::synToAccessProgramRequest.connect(bind(&MergeService::messageComeHandler,
                                                           this, _1, _3));
    NMCDistProgram::ProgramConnect.connect(bind(&MergeService::setChannelChange, this, _1, true));
    NMCDistProgram::ProgramDisconnect.connect(bind(&MergeService::setChannelChange, this, _1, false));
}
void MergeService::setIOService(io_service* ioService) {
    _ioService = ioService;
}

void MergeService::setChannel(uint16_t channel) {
    _channel = channel;
}

void MergeService::initializeChannel(NMCDistProgram *program) {
    _activePipe[program->getChannel()] = true;
}

void MergeService::setChannelChange(NMCDistProgram *prog, bool connect) {
    if (connect) {
        setbit(_channel, prog->getChannel());
    } else {
        clrbit(_channel, prog->getChannel());
    }
}
void MergeService::switchMasterHandler() {
    {
        MutexType::scoped_lock lock(_mutex);
        _infoMap.clear();
    }
}