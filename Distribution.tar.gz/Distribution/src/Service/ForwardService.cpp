//
// Created by jun on 2021/4/1.
//

#include "ForwardService.h"
#include <boost/bind.hpp>
#include <boost/cast.hpp>
#include "Connection/TcpConnection.h"
#include "Logger/LogService.h"
#include <boost/foreach.hpp>
#include "IO/IOService.h"
#include "SynService.h"
#include "../SbdnObject/XML/tinyxml.h"
#include "MergeService.h"
#include "JSONService.h"
using namespace PKU_SatLab_DBS_NMC;
using namespace service;


ForwardService* ForwardService::m_instance = NULL;

ForwardService::ForwardService() {
    m_ioService = NULL;
//    m_port = 0;
    m_registerFlag = false;
    m_registerMessage = "<?xml version=\"1.0\" encoding=\"utf-8\"?><Control><Action type=\"int\" value=\"00002\"><Seq type=\"int\" value=\"0\" /><AccessProgram type=\"string\" value=\"AccessProgram1\" /></Action></Control>";
    m_replyChannelMessage = "";
    NMCDistProgram::ProgramConstruct.connect(bind(&ForwardService::initProgram,
                                                  this, _1));
}

ForwardService * ForwardService::getInstance() {
    if (m_instance == NULL)
        m_instance =  new ForwardService();
    return m_instance;
}

void ForwardService::setService(io_service * ioService) {
    m_ioService = ioService;
}

/*void ForwardService::setBindport(int port) {
    m_port = port;
}*/
void ForwardService::setChannelIP(int i, const string &ipAddr, int port) {
    string ChannelValue = "Channel";
    ChannelValue+= to_string(i);
   /* m_ipMap.insert(IPMapValue(ChannelValue, make_pair(ipAddr, port)));
    m_localMap.insert(IPMapValue(ChannelValue, make_pair("127.0.0.1", SENDPORT+i)));*/
}
void ForwardService::start() {
    assert(m_ioService);
//    assert(m_port);
    JSONService::switchMasterRequest.connect(bind(&ForwardService::switchMaster, this));
#ifdef DMC_CONFIG
    JSONService::StopAllDistProgramRequest.connect(bind(&ForwardService::stopAllDistProgram, this));
    JSONService::InitialChannelProgram.connect(bind(&ForwardService::addNewDistProgram, this, _1, _2, _3));
    JSONService::StartProgram.connect(bind(&ForwardService::reStart, this));
#endif
    if (isMaster) {
        initializeMaster();

        LOG(INFO, "0004", "ForwardService will start as master")
    } else {
        MergeService::getInstance()->distributionToBMC.disconnect_all_slots();
        MergeService::getInstance()->registerRequest.disconnect_all_slots();
        SynService::getInstance()->accessProgramDisconnectSignal.disconnect_all_slots();
        SynService::getInstance()->registerAccessProgram.disconnect_all_slots();
        SynService::getInstance()->replyChannelMsg.disconnect_all_slots();
        LOG(INFO, "0004", "ForwardService will start as slave")
    }
}



void ForwardService::connectionErrorHandler(const string &error,
                                        ConnectionPtr &connection, EndpointPtr &endpoint)
{

    LOG(ERROR, "0000", "connection to " + endpoint->address().to_string()
        << ":"<<to_string(endpoint->port())+ " error: " << error <<" try to reconnect");
    /*asio::deadline_timer t(*m_ioService, boost::posix_time::seconds(5));
    t.async_wait(bind(&TcpConnection::reconnect, connection, _1, *endpoint));*/
    connection->reconnectHandler(*endpoint);
//    connection->disconnect();
//    connection->checkDelete();
//    endpoint.reset();
}
void ForwardService::forwardMessage(const string & message, int security) {
    LOG(DEBUG, "0000", "Message with action = " <<security << " sent to DistMngProgram")
    BOOST_FOREACH(ProgramPool::value_type p, m_progPool) {

                    if (p->isActive()) {
                        LOG(INFO, "0000", "Message from Acccess to DistMngProgram" << p->getChannel() << "ip : " << p->getIpAddr())
                        LOG(NETIO, "0000", message)
                        p->synToProgram(message);
                    }
                    }


}
void ForwardService::forwardMessageHandler(const string & message, const string & s2) {

    TiXmlDocument doc;
    doc.Parse(message.c_str());
    TiXmlElement* msgRoot = doc.RootElement();
    TiXmlElement* actionNode = msgRoot->FirstChildElement("Action");
    int channel = -1;
    int action = atoi(actionNode->Attribute("value"));
    int eventID;
    if (action != 10002) {
        TiXmlElement* EventNode= actionNode->FirstChildElement("AccessProgram");
        if (EventNode!=NULL)
        EventNode= EventNode->FirstChildElement("EventList");
        if (EventNode!=NULL){
            EventNode = EventNode->FirstChildElement("Event");
        }
        if (EventNode != NULL) {
        EventNode = EventNode->FirstChildElement("Parameter");
        TiXmlElement* IDNode = EventNode->FirstChildElement("ID");
        eventID = atoi(IDNode->Attribute("value"));
        channel = (eventID>>28) & 0x0F;
        }
        
    }
    BOOST_FOREACH(ProgramPool::value_type p, m_progPool) {
        if (channel < 0) {
            if (p->isActive()) {
            //FIXME add contribution
            LOG(INFO, "0000", "Forward Action " << action  <<" EventID="<<eventID << " to " <<p->getName())
            p->synToProgram(message);
            }
        } else {
            if (p->getChannel() == channel && p->isActive()) {
                LOG(INFO, "0000", "Forward Action " << action  <<" EventID="<<eventID << " to " <<p->getName())
                p->synToProgram(message);
            }
        }
        
    }
}

void ForwardService::initProgram(NMCDistProgram * prog) {
    MutexType::scoped_lock(m_threadMutex);
    m_progPool.insert(prog);
}

void ForwardService::accessProgramDisconnectedHandler() {
    m_registerFlag = false;
    m_registerMessage = "";
#ifdef SYN_DEBUG
    LOG(INFO, "0000", "Access Programm disconnect ReConnect")
#endif
BOOST_FOREACH(ProgramPool::value_type p, m_progPool) {
         p->stopProgram();
    }
MergeService::getInstance()->distributionToBMC.disconnect_all_slots();
    MergeService::getInstance()->registerRequest.disconnect_all_slots();
    SynService::getInstance()->accessProgramDisconnectSignal.disconnect_all_slots();
    SynService::getInstance()->registerAccessProgram.disconnect_all_slots();
    SynService::getInstance()->replyChannelMsg.disconnect_all_slots();
    LOG(INFO, "0000", "Access unconnected! Disconnect all dist")
    BOOST_FOREACH(NMCDistProgram *prog, m_progPool) {
                    if (prog->isReset()){
                        prog->switchReset();
                    }
                    m_connection.reset(new TcpConnection(m_ioService));
                    m_endpoint.reset(new tcp::endpoint(address::from_string(prog->getIpAddr()),
                                                       prog->getProgPort()));
                    m_connection->connectionConnectedSignal.connect(
                            bind(&NMCDistProgram::connectionConnectedHandler,
                                 prog, m_connection, m_endpoint));
                    //prog->attachConnection(m_connection, m_endpoint);
                    m_connection->connectionErrorSignal.connect(bind(&NMCDistProgram::connectionErrorHandler,
                                                                     prog, _1, m_connection));
                    //m_connection->setLocalPort(prog->getLocalPort());
                    m_connection->connect(*m_endpoint);
                }

//    SynService::getInstance()->synToDistributionSignal.connect(bind(&ForwardService::forwardMessageHandler,this, _1, _2));
    MergeService::getInstance()->distributionToBMC.connect(bind(&ForwardService::forwardMessage, this, _1, _2));
    MergeService::getInstance()->registerRequest.connect(bind(&ForwardService::forwardMessage, this, _1, _2));
    SynService::getInstance()->accessProgramDisconnectSignal.connect(
            bind(&ForwardService::accessProgramDisconnectedHandler, this)
    );
    SynService::getInstance()->registerAccessProgram.connect(
            bind(&ForwardService::registerAccessHandler, this, _1));
    SynService::getInstance()->replyChannelMsg.connect(
            bind(&ForwardService::receiveChannelMsgHandler, this, _1, _2));
}

void ForwardService::registerAccessHandler(const string & message) {
    if (m_registerMessage == "") {
        m_registerMessage = message;
    }
    m_registerFlag = true;
    BOOST_FOREACH(ProgramPool::value_type p, m_progPool) {
                    p->registerHandler(message);
                }
}

bool ForwardService::needAccessRegister() {
    return m_registerFlag;
}

void ForwardService::setNeedRegister() {
    m_registerFlag = true;
}

const string& ForwardService::getChannelStr() {
    return m_replyChannelMessage;
}

const string& ForwardService::getRegisterStr() {
    return m_registerMessage;
}
void ForwardService::receiveChannelMsgHandler(const string & message, int32_t channel) {
    BOOST_FOREACH(ProgramPool::value_type p, m_progPool) {
        if (p->getChannel() != channel) {
            continue;
        }
        if (p -> isActive())
            p->synToProgram(message);
    }
}

void ForwardService::switchMaster() {
    m_ioService->dispatch(bind(&ForwardService::switchMasterHandler, this));
}

void ForwardService::setMaster(bool master) {
    isMaster=master;
}

void ForwardService::switchMasterHandler() {
    if (isMaster) {
        isMaster = !isMaster;
        
        LOG(INFO, "0000", "Distribution will switch to Slave.")
        m_ioService->dispatch(bind(&ForwardService::initializeSlave, this));
    } else {
        isMaster = !isMaster;
        
        LOG(INFO, "0000", "Distribution will switch to Master.")
        m_ioService->dispatch(bind(&ForwardService::initializeMaster, this));
    }
}

void ForwardService::initializeMaster() {
    stringstream ss;
    ss << "ifconfig " << m_virtualCard << ":1 " << m_virtualIP <<" netmask 255.224.0.0 up";
    std::system(ss.str().c_str());
    BOOST_FOREACH(NMCDistProgram *prog, m_progPool) {
                    if (prog->isReset()){
                        prog->switchReset();
                    }
                    m_connection.reset(new TcpConnection(m_ioService));
                    m_endpoint.reset(new tcp::endpoint(address::from_string(prog->getIpAddr()),
                                                       prog->getProgPort()));
                    m_connection->connectionConnectedSignal.connect(
                            bind(&NMCDistProgram::connectionConnectedHandler,
                                 prog, m_connection, m_endpoint));
                    //prog->attachConnection(m_connection, m_endpoint);
                    m_connection->connectionErrorSignal.connect(bind(&NMCDistProgram::connectionErrorHandler,
                                                                     prog, _1, m_connection));
                    //m_connection->setLocalPort(prog->getLocalPort());
                    m_connection->connect(*m_endpoint);
                }

//    SynService::getInstance()->synToDistributionSignal.connect(bind(&ForwardService::forwardMessageHandler,this, _1, _2));
    MergeService::getInstance()->distributionToBMC.connect(bind(&ForwardService::forwardMessage, this, _1, _2));
    MergeService::getInstance()->registerRequest.connect(bind(&ForwardService::forwardMessage, this, _1, _2));
    SynService::getInstance()->accessProgramDisconnectSignal.connect(
            bind(&ForwardService::accessProgramDisconnectedHandler, this)
    );
    SynService::getInstance()->registerAccessProgram.connect(
            bind(&ForwardService::registerAccessHandler, this, _1));
    SynService::getInstance()->replyChannelMsg.connect(
            bind(&ForwardService::receiveChannelMsgHandler, this, _1, _2));

}

void ForwardService::initializeSlave() {
    stringstream ss;
    ss << "ifconfig " << m_virtualCard << ":1 " << m_virtualIP <<" netmask 255.224.0.0 down";
    std::system(ss.str().c_str());
    BOOST_FOREACH(NMCDistProgram *prog, m_progPool) {
        prog->stopProgram();
    }
    MergeService::getInstance()->distributionToBMC.disconnect_all_slots();
    MergeService::getInstance()->registerRequest.disconnect_all_slots();
    SynService::getInstance()->accessProgramDisconnectSignal.disconnect_all_slots();
    SynService::getInstance()->registerAccessProgram.disconnect_all_slots();
    SynService::getInstance()->replyChannelMsg.disconnect_all_slots();
}


void ForwardService::setVirtualCard(const string & card) {
    m_virtualCard = card;
}

void ForwardService::setVirtualIP(const string & ipAddr) {
    m_virtualIP = ipAddr;
}

void ForwardService::stopAllDistProgram() {
    BOOST_FOREACH(NMCDistProgram *prog, m_progPool) {
                    prog->stopProgram();
                }
    MergeService::getInstance()->distributionToBMC.disconnect_all_slots();
    MergeService::getInstance()->registerRequest.disconnect_all_slots();
    SynService::getInstance()->accessProgramDisconnectSignal.disconnect_all_slots();
    SynService::getInstance()->registerAccessProgram.disconnect_all_slots();
    SynService::getInstance()->replyChannelMsg.disconnect_all_slots();
    {
        MutexType::scoped_lock (m_threadMutex);
        m_progPool.clear();
    }

}

void ForwardService::addNewDistProgram(int32_t channel, const string &ipAddr, int port) {
    NMCDistProgram* prog;
    stringstream ss;
    ss<<"DistProgram" << channel;
    prog = new NMCDistProgram(ss.str(),  channel, ipAddr, port, 9999);
    prog->initialize();
}

void ForwardService::reStart() {
    if (isMaster) {
         stringstream ss;
    ss << "ifconfig " << m_virtualCard << ":1 " << m_virtualIP <<" netmask 255.224.0.0 up";
    std::system(ss.str().c_str());
    LOG(INFO, "0000", "virtual Card start")
        BOOST_FOREACH(NMCDistProgram *prog, m_progPool) {
                        if (prog->isReset()){
                            prog->switchReset();
                        }
                        m_connection.reset(new TcpConnection(m_ioService));
                        m_endpoint.reset(new tcp::endpoint(address::from_string(prog->getIpAddr()),
                                                           prog->getProgPort()));
                        m_connection->connectionConnectedSignal.connect(
                                bind(&NMCDistProgram::connectionConnectedHandler,
                                     prog, m_connection, m_endpoint));
                        //prog->attachConnection(m_connection, m_endpoint);
                        m_connection->connectionErrorSignal.connect(bind(&NMCDistProgram::connectionErrorHandler,
                                                                         prog, _1, m_connection));
                        //m_connection->setLocalPort(prog->getLocalPort());
                        m_connection->connect(*m_endpoint);
                    }

//    SynService::getInstance()->synToDistributionSignal.connect(bind(&ForwardService::forwardMessageHandler,this, _1, _2));
        MergeService::getInstance()->distributionToBMC.connect(bind(&ForwardService::forwardMessage, this, _1, _2));
        MergeService::getInstance()->registerRequest.connect(bind(&ForwardService::forwardMessage, this, _1, _2));
        SynService::getInstance()->accessProgramDisconnectSignal.connect(
                bind(&ForwardService::accessProgramDisconnectedHandler, this)
        );
        SynService::getInstance()->registerAccessProgram.connect(
                bind(&ForwardService::registerAccessHandler, this, _1));
        SynService::getInstance()->replyChannelMsg.connect(
                bind(&ForwardService::receiveChannelMsgHandler, this, _1, _2));
    }
}