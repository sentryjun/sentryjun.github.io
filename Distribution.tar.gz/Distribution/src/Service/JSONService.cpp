//
// Created by nmc on 2021/5/30.
//

#include "JSONService.h"
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include "Logger/LogService.h"
#include "Timer/TimerService.h"
#include "ForwardService.h"
#include "SynService.h"
using namespace PKU_SatLab_DBS_NMC;
using namespace service;

using rapidjson::Document;
JSONService* JSONService::instance = NULL;
boost::signals2::signal<void(int)> JSONService::switchMasterRequest;
boost::signals2::signal<void()> JSONService::StopAllDistProgramRequest;
boost::signals2::signal<void(int, const string &, int)> JSONService::InitialChannelProgram;
boost::signals2::signal<void()> JSONService::StartProgram;
JSONService * JSONService::getInstance() {
    if (instance == NULL) {
        instance = new JSONService();
    }
    return instance;
}

JSONService::JSONService(){
    ioService = NULL;
    typeMap["login"] = login;
    typeMap["report"] = report;
    typeMap["get_set"] = getset;
    typeMap["config"] = config;
    typeMap["switch"] = masterSwitch;

}
JSONService::~JSONService() {
}

void JSONService::setIP(const string &ip) {
    NMCip = ip;
}

void JSONService::setIOService(io_service *ioservice) {
    ioService = ioservice;
}

void JSONService::setPort(int port) {
    NMCport = port;
}
void JSONService::setChannel(int c) {
    channel = c;
}
void JSONService::setBMCIP(const string &ip) {
    BMCIP = ip;
}
void JSONService::loginHandler() {
    rapidjson::StringBuffer strBuff;
    rapidjson::Writer<rapidjson::StringBuffer > writer(strBuff);
    writer.StartObject();
    writer.Key("cmd");
    writer.String("login");

    writer.Key("ip");
    writer.String(BMCIP.c_str());

    writer.Key("channel");
    writer.Int(channel);

    writer.Key("name");
    writer.String("DissemMngServer");
    writer.Key("status");
    writer.Int(isMaster);
    writer.EndObject();

    string message = strBuff.GetString();
    LOG(WARNING, "0000", message)
    AnswerToNMC(message);
}

bool JSONService::AnswerToNMC(const string &message) {
    if (connection->isConnected()) {
        connection->write(message);
    }
}
void JSONService::connectionErrorHandler(const string &message) {
    LOG(ERROR, "0000", "JSON Service: " << message)
//    AutoTimer->stop();
/*    if (!connection->isConnected()) {
        connection->reconnectHandler(*endpoint);
    }*/
//    if (message == "Connection refused" || message == "End of file" || message == "Connection reset by peer") {
//        connection->reconnectHandler(*endpoint);}
}
void JSONService::start() {
    connection.reset(new TcpConnection(ioService));
    endpoint.reset(new tcp::endpoint(address::from_string(NMCip), NMCport));
    connection->connectionConnectedSignal.connect(bind(&JSONService::connectConnectedHandler, this));
    connection->connectionErrorSignal.connect(bind(&JSONService::connectionErrorHandler, this, _1));
    connection->connect(*endpoint);
    AutoTimer.reset(service::TimerService::getInstance()->newTimer());
    AutoTimer->setInterval(5000);
    AutoTimer->setSingleShot(false);
    AutoTimer->timeoutSignal.connect(bind(&JSONService::messageReportHandler, this, 1, ""));
    AutoTimer->start();
}

void JSONService::connectConnectedHandler() {
    connection->getSocket()->set_option(tcp::socket::keep_alive());

    connection->messageReadSignal.disconnect_all_slots();
    connection->messageReadSignal.connect(bind(&JSONService::messageComeHandler, this, _1));
    connection->connectionErrorSignal.disconnect_all_slots();
    connection->connectionErrorSignal.connect(bind(&JSONService::connectionErrorHandler, this, _1));
    connection->startReceive();
    ioService->dispatch(bind(&JSONService::loginHandler, this));
}

void JSONService::messageComeHandler(const string & message){
    LOG(INFO, "0000", "Receive from net manager: >\n" << message)
    parseJsonMessage(message);
}

void JSONService::parseJsonMessage(const string &message) {
    rapidjson::Document doc;
    try {
        doc.Parse(message.c_str());
        rapidjson::Value & messageType = doc["cmd"];
        string cmdType = messageType.GetString();


    switch (typeMap.at(cmdType)) {
        case login:
            LOG(ERROR, "0000", message)
            loginResonseHandler(message);
            break;
        case report:
            break;
        case config:
            //ConfigRequest(message);
            loginResonseHandler(message);
            break;
        case getset:
            break;
        case masterSwitch:
            LOG(ERROR, "0000",message)
            masterSwitchHandler(message);
        default:
            break;
    }
    }catch (...) {
        LOG(INFO, "0000", "JSON PARSE ERROR")
    }
}
void JSONService::messageReportHandler(int type, const string & programName) {
    if (!connection->isConnected()) {
        connection->disconnect();
        connection.reset(new TcpConnection(ioService));
        connection->connectionConnectedSignal.connect(bind(&JSONService::connectConnectedHandler, this));
        connection->connectionErrorSignal.connect(bind(&JSONService::connectionErrorHandler, this, _1));
        connection->connect(*endpoint);
        LOG(DEBUG, "0000", "NMC not Connect,try to reconnect")
        return;
    }
}

void JSONService::loginResonseHandler(const string & msg) {
    //rapidjson::Document doc;
    try {
        //ConfigRequest(msg);
//        ioService->dispatch(bind(&JSONService::ConfigRequest, this, msg));
        //doc.Parse(msg.c_str());
//        if (doc.HasMember("config")) {
//            rapidjson::Value &param = doc["config"];
//            if (param.HasMember("backward_server")) {
//                rapidjson::Value &backIP = param["backward_server"];
//                backwardIPChange(backIP.GetString());
//            }
//        }
#ifdef DMC_CONFIG
    rapidjson::Document doc;
    doc.Parse(msg.c_str());
    if (doc.HasMember("channel")) {
        rapidjson::Value & channel = doc["channel"];
        assert(channel == -1);
    }
    rapidjson::Value::ConstMemberIterator itor = doc.FindMember("parameters");
    if (itor != doc.MemberEnd()) {

        rapidjson::Value::ConstMemberIterator serverItors = itor->value.FindMember("servers");
        if (serverItors != itor->value.MemberEnd()) {
            //SynService::getInstance()->stopConnection();
            const rapidjson::Value & serverArrays = serverItors->value;
            bool flag = 1;
            for (rapidjson::Value::ConstValueIterator itr = serverArrays.Begin(); itr != serverArrays.End(); itr++) {
                const rapidjson::Value & v = *itr;
                if (v["servername"] == "disman_server") {
                    flag = 0;
                    break;
                }
            }
            if (flag) {
                return;
            }
            isMaster = true;
            StopAllDistProgramRequest();
            for (rapidjson::Value::ConstValueIterator itr = serverArrays.Begin(); itr != serverArrays.End(); itr++) {
                const rapidjson::Value & v = *itr;
                if (v["servername"] == "disman_server") {
                    int distChannel = v["channel"].GetInt();
                    string ipAddress = v["ip"].GetString();
                    int distPort = v["port"].GetInt();
                    if (distChannel >= 0) {
                        InitialChannelProgram(distChannel, ipAddress, distPort);
                    }
                }

            }
            isMaster = true;
            ForwardService::getInstance()->setMaster(true);
//            switchMasterRequest(isMaster);
            StartProgram();
        } else {
            isMaster = false;
            ForwardService::getInstance()->setMaster(false);
        }
    }
    else {
        isMaster = false;
    }
#endif
    }
    catch (...) {
        LOG(INFO, "0000", "JSON PARSE ERROR")
    }
}

void JSONService::masterSwitchHandler(const string & msg) {
    rapidjson::Document doc;
    try {
        doc.Parse(msg.c_str());
        if (doc.HasMember("config")) {
            rapidjson::Value &param = doc["config"];
            rapidjson::Value::ConstMemberIterator serverItors = param.FindMember("servers");
            if (serverItors != param.MemberEnd()) {
                StopAllDistProgramRequest();
                ForwardService::getInstance()->setNeedRegister();

                const rapidjson::Value &serverArrays = serverItors->value;
                for (rapidjson::Value::ConstValueIterator itr = serverArrays.Begin();
                     itr != serverArrays.End(); itr++) {
                    const rapidjson::Value &v = *itr;
                    if (v["servername"] == "disman_server") {
                        int distChannel = v["channel"].GetInt();
                        string ipAddress = v["ip"].GetString();
                        int distPort = v["port"].GetInt();
                        if (distChannel >= 0) {
                            InitialChannelProgram(distChannel, ipAddress, distPort);
                        }
                    }
                }
                isMaster = true;
                switchMasterRequest(isMaster);
            } else {
                StopAllDistProgramRequest();
                LOG(INFO, "0000", "I will change to slave")
                if (ForwardService::getInstance()->getIsMaster() == true) {
                    isMaster = false;
                    switchMasterRequest(isMaster);
                }
            }

        }
//        if (doc.HasMember("status")) {
//            rapidjson::Value & status = doc["status"];
//            if (status.GetInt() == isMaster) {
//                isMaster = (isMaster)?0:1;
//                switchMasterRequest(isMaster);
//            }
//        }
    } catch (...){
        LOG(INFO, "0000", "JSON PARSE ERROR")
    }
}