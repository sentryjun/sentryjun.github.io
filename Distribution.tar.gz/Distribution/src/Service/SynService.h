//
// Created by jun on 2021/3/31.
//

#ifndef DISTRIBUTION_SYNSERVICE_H
#define DISTRIBUTION_SYNSERVICE_H

#include <string>
#include <vector>
#include <map>
#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <boost/signals2.hpp>
using namespace std;
using namespace boost;
using namespace asio;
using namespace ip;
using namespace signals2;

namespace PKU_SatLab_DBS_NMC {
    namespace Parser {
        struct ObjectInfo;
    }
    class TcpConnection;
    namespace service {
        class SynService {
            typedef boost::shared_ptr<tcp::acceptor> TcpAcceptorPtr;
            typedef boost::shared_ptr<TcpConnection> ConnectionPtr;
            typedef boost::shared_ptr<tcp::endpoint > EndpointPtr;
            typedef boost::system::error_code Error;
        public:
            static SynService* getInstance();
            void start();
            void setService(io_service *);
            void setMaster(int master){isMaster=master;};
            void setListenport(int port);
            void stopConnection();
            boost::signals2::signal<void(const string &, const string &)>  synToDistributionSignal;
            boost::signals2::signal<void()> accessProgramDisconnectSignal;
            boost::signals2::signal<void(const string &)> registerAccessProgram;
            boost::signals2::signal<void(const string&, int32_t)> replyChannelMsg;
        private:
            enum RegisterType {
                E_InvalidRegisterType = 0,
                E_ServerRegister = 1,
                E_ProgramRegister,
                E_OtherDeviceRegister
            };

            SynService();
            void acceptConnectionHandler(const Error &);
            void dispatchConnectionHandler(const string &, ConnectionPtr &, EndpointPtr &);
            void connectionErrorHandler(const string &, ConnectionPtr&, EndpointPtr &);
            void checkRegisterType(Parser::ObjectInfo &);
            void synToAccessHandler(const string &, const string &);
            void synChannelMsgToAccess(const string &, int32_t channel);

            static SynService* m_instance;
            string channelMsg;//FIXME need to Use
            TcpAcceptorPtr m_acceptor;
            int m_port;
            ConnectionPtr m_connection;
            ConnectionPtr m_activeAccess;
            EndpointPtr m_endpoint;
            io_service *m_ioService;
            boost::mutex m_threadMutex;
            bool m_registeredReply;
            int isMaster;

        };
    }

}



#endif //DISTRIBUTION_SYNSERVICE_H
