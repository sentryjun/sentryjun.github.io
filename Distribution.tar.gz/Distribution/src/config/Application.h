//
// Created by jun on 2021/4/8.
//

#ifndef DISTRIBUTION_APPLICATION_H
#define DISTRIBUTION_APPLICATION_H
#include "../Service/JSONService.h"
#include "../Service/SynService.h"
#include "../Service/IO/IOService.h"
#include "../Service/IO/StrandService.h"
#include "../Service/Logger/LogService.h"
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include "../Service/Exception/ExceptionService.h"
#include "../Service/ForwardService.h"
#include "../Common/enum.h"
#include "../Service/Timer/TimerService.h"
#include "../SbdnObjectImpl/NMCDistProgram.h"
#include "../SbdnObject/XML/tinyxml.h"
#include "../Service/MergeService.h"
using namespace std;
using namespace boost;
using namespace property_tree;

using namespace PKU_SatLab_DBS_NMC;
using namespace service;

class Application {
public:
    static Application* getInstance();
    void setConfigPath(const string &);
    void start();

private:
    Application();
    ~Application();
    void startBasicService();

    void startIOService();
    void startTimerService();
    void startLogService();
    void startSynService();
    void startExceptionService();
    void startForwardService();
    void configProgram();
    void startMergeService();
    void startJSONService();

    static Application* m_instance;

    JSONService *m_JSONService;
    IOService *m_ioService;
    LogService *m_logService;
    TimerService *m_timerService;
    SynService *m_synService;
    ForwardService *m_forwardService;
    ExceptionService *m_exceptionService;
    MergeService *m_mergeService;

    string m_configPath;
    ptree m_propertyTree;
};


#endif //DISTRIBUTION_APPLICATION_H
