//
// Created by jun on 2021/4/8.
//

#include "Application.h"
#include <iostream>

Application* Application::m_instance = NULL;

Application::Application() {
    m_ioService = IOService::getInstance();
    m_JSONService = JSONService::getInstance();
    m_logService = LogService::getInstance();
    m_timerService = TimerService::getInstance();
    m_exceptionService = ExceptionService::getInstance();
    m_synService = SynService::getInstance();
    m_forwardService = ForwardService::getInstance();
    m_mergeService = MergeService::getInstance();
}

Application* Application::getInstance()
{
    if (m_instance == NULL)
        m_instance = new Application();
    return m_instance;
}

Application::~Application(){}

void Application::setConfigPath(const string & configFile) {
    m_configPath = configFile;
}

void Application::start() {
    assert(!m_configPath.empty());
    xml_parser::read_xml(m_configPath, m_propertyTree);
    startBasicService();
    m_ioService->run();
}

void Application::startBasicService() {
    startIOService();
    startLogService();
    startTimerService();
    startExceptionService();
    startJSONService();
#ifndef  DMC_CONFIG
    configProgram();
#endif
    startMergeService();
    startSynService();
    startForwardService();
}

void Application::startIOService() {
    m_ioService->start();
}

void Application::startLogService() {
    m_logService->setName("NMCLog");
    m_logService->setLogLevel(NETIO);
    m_logService->setService(m_ioService->getService(1));
    /* set each level record type */
    property_tree::ptree& loggerTree = m_propertyTree.get_child(
            "Application.Log");
    LogLevel logLevel;
    LogRecordType recordType;
    /* find every node named LoggerName*/
    BOOST_FOREACH(property_tree::ptree::value_type &value, loggerTree.get_child("LoggerName"))
                {
                    /* get log level name */
                    string loggerName = value.second.data();
                    logLevel = strToEnum<LogLevel> (loggerName);
                    /* find log record type config node */
                    BOOST_FOREACH(property_tree::ptree::value_type &record,
                                  loggerTree.get_child(loggerName + ".Record"))
                                {
                                    recordType = strToEnum<LogRecordType> (
                                            record.first);
                                    m_logService->setEnableRecordType(logLevel,
                                                                      recordType);
                                }
                }
    m_logService->start();
}

void Application::startTimerService() {
    m_timerService->setService(m_ioService->getService(1));
    m_timerService->start();
}

void Application::startExceptionService() {
    m_exceptionService->setService(m_ioService->getService(1));
    m_exceptionService->start();
}

void Application::configProgram() {
    TiXmlDocument xmlDoc;
    xmlDoc.LoadFile(m_configPath);
    TiXmlElement* pRoot = xmlDoc.RootElement();
    TiXmlElement* pProgram = pRoot->FirstChildElement("Program");
    TiXmlElement* pDist = pProgram->FirstChildElement("DistributionManageProgram");
    NMCDistProgram* prog;
    while(pDist) {
        string name = pDist->Attribute("name");
        string IPaddr = pDist->Attribute("IP");
        int localPort = atoi(pDist->Attribute("localPort"));
        int progPort = atoi(pDist->Attribute("programPort"));
        int channel = atoi(pDist->Attribute("channel"));
        pDist = pDist->NextSiblingElement("DistributionManageProgram");
        prog = new NMCDistProgram(name,  channel, IPaddr, progPort,localPort);
        prog->initialize();
    }

}

void Application::startJSONService() {
    m_JSONService->setIOService(m_ioService->getService(2));
    uint32_t port = m_propertyTree.get("Application.NMCServer.Port", 10086);
    string  IP = m_propertyTree.get("Application.NMCServer.IP", "127.0.0.1");
    string BMCIP = m_propertyTree.get<string> (
            "Application.Server.IP");
    int isMaster = 0;
    m_JSONService->setMaster(isMaster);
    //m_JSONService = JSONService::getInstance();
    m_JSONService->setBMCIP(BMCIP);
    m_JSONService->setChannel(-1);
    m_JSONService->setIP(IP);
    m_JSONService->setPort(port);
    //m_JSONService->setIOService(m_ioService->getService(0));
    m_JSONService->start();
}
void Application::startSynService() {
    m_synService->setService(m_ioService->getService(0));
    int listenPort = m_propertyTree.get<int>("Application.Server.SynListenPort");
    int isMaster = 0;
    m_synService->setMaster(isMaster);
    m_synService->setListenport(listenPort);
    m_synService->start();
}

void Application::startForwardService() {
    m_forwardService->setService(m_ioService->getService(0));
    int isMaster = 0;
    m_forwardService->setMaster((bool)isMaster);
    string virtualIP = m_propertyTree.get("Application.VirtualIP", "99.1.0.5");
    string virtualCard = m_propertyTree.get("Application.VirtualNetcard", "eno3");
    m_forwardService->setVirtualCard(virtualCard);
    m_forwardService->setVirtualIP(virtualIP);
    m_forwardService->start();

}

void Application::startMergeService() {
    //m_mergeService->setChannel(0b1001);
    m_mergeService->setIOService(m_ioService->getService(0));
    m_mergeService->Start();
}