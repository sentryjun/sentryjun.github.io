#ifndef NMCSBDNOBJECTPARSER_H
#define NMCSBDNOBJECTPARSER_H

#include <string>
#include <stdexcept>
#include <boost/shared_ptr.hpp>
#include "../SbdnObject/XML/tinyxml.h"
#include "../SbdnObjectImpl/NMCSbdnObject.h"
using namespace std;
using namespace boost;

namespace PKU_SatLab_DBS_NMC
{
	class NMCSbdnObject;

	namespace Parser
	{
		struct ObjectInfo
		{
			string Type;
			string Name;
		};

		typedef boost::shared_ptr<NMCSbdnObject> NMCSbdnObjectPtr;

		class NMCSbdnObjectParser
		{
		public:
			static int parseRegisterAction(const string &, int &,
					ObjectInfo &);
			static NMCSbdnObjectPtr loadSbdnObjectFromXml(TiXmlElement *);
			static void saveSbdnObjectToXml(NMCSbdnObject *, TiXmlElement *&);
			static void saveSystreeToNMXml(NMCSbdnObject *, TiXmlElement *&);
			static void saveSbdnObjectToStr(NMCSbdnObject *, string &);
			static void saveSbdnObjectToAction(NMCSbdnObject *, string &, int, int = 0);
			static void saveSystreeToNMAction(NMCSbdnObject *, string &, int, int = 0);
			static void saveSingleSbdnObjectToAction(NMCSbdnObject *, string &, int, int = 0);
			static void saveSingalSbdnObjectToXml(NMCSbdnObject *, TiXmlElement *);
			static void saveVoiceSbdnObjectToAction(NMCSbdnObject *, string &, int, int = 0); //lamin add 201801
			static NMCSbdnObjectPtr parseAction(const string &, int &);
			static NMCSbdnObjectPtr parseAction(const string &, int &, int &);
			struct UIActionUnit
			{
				UIActionUnit()
				{
				}
				NMCSbdnObjectPtr node;
				NMCSbdnObjectPtr parent;
			};
			static UIActionUnit parseUIAction(const string &, int &, int &);
			static void synEventToXml(NMCSbdnObject *, NMCSbdnObject *, string &, int, int = 0, bool = true);
			static bool synSbdnObjectTree(NMCSbdnObject *, const NMCSbdnObject *);
			static void SbdnObjectToStr(NMCSbdnObject *, string &);
			static void xmlToAction(TiXmlElement *, string &, int, int);

		private:
			NMCSbdnObjectParser();
		};
	}
}
#endif // NMCSBDNOBJECTPARSER_H
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
