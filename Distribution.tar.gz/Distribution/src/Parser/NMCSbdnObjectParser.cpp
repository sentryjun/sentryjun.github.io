#include "NMCSbdnObjectParser.h"
#include "XmlParser.h"

#include "../SbdnObjectImpl/NMCSbdnObjectTreeBuilder.h"


#include <boost/foreach.hpp>
#include <boost/cast.hpp>

using namespace PKU_SatLab_DBS_NMC;
using namespace Parser;

int NMCSbdnObjectParser::parseRegisterAction(const string &message,
		int &action, ObjectInfo &nodeInfo)
{
	TiXmlDocument doc;
	istringstream xmlMessage(message);
	xmlMessage >> doc;
	TiXmlElement *root = doc.FirstChildElement();
	try
	{
		TiXmlElement *actionNode = XmlParser::firstChildElement(root, "Action");
		actionNode->Attribute("value", &action);
		// FIXME gateway register has no seq node
		TiXmlElement *seqNode = actionNode->FirstChildElement("Seq");
		TiXmlElement *node;
		if (seqNode)
		{
			node = XmlParser::nextSiblingElement(seqNode);
		}
		else
		{
			node = XmlParser::firstChildElement(actionNode);
		}
		nodeInfo.Type = node->ValueStr();
		XmlParser::attributeStr(node, "value", nodeInfo.Name);
	}
	catch (const runtime_error & /* error */)
	{
		throw;
	}
	return action;
}

NMCSbdnObjectPtr NMCSbdnObjectParser::parseAction(const string &message,
		int &action, int &seq)
{
	TiXmlDocument doc;
	doc.Parse(message.c_str());
	if (doc.Error())
	{
		throw runtime_error("invalid xml message: " + string(doc.ErrorDesc()));
	}
	TiXmlElement *control = doc.FirstChildElement("Control");
	try
	{
		TiXmlElement *actionNode = XmlParser::firstChildElement(control,
				"Action");
		XmlParser::attribute(actionNode, "value", action);
		seq = 0;
		TiXmlElement *seqNode = actionNode->FirstChildElement("Seq");
		if (seqNode)
		{
			seqNode->Attribute("value", &seq);
		}
		TiXmlElement *program = actionNode->FirstChildElement();
		for (; program; program = program->NextSiblingElement())
		{
			if (program->ValueStr().find("Seq") == string::npos)
			{
				break;
			}
		}
		if (program == NULL)
		{
			throw runtime_error("can't find program node");
		}
		NMCSbdnObject *root =
		NMCSbdnObjectTreeBuilder::getInstance()->loadBaseSbdnObjectFromXml(
				program);
		return NMCSbdnObjectPtr(root);
	}
	catch (const runtime_error &)
	{
		throw;
	}
	return NMCSbdnObjectPtr();
}



NMCSbdnObjectPtr NMCSbdnObjectParser::parseAction(const string &message,
		int &action)
{
	int seq = 0;
	return parseAction(message, action, seq);
}


bool NMCSbdnObjectParser::synSbdnObjectTree(NMCSbdnObject *pDest,
		const NMCSbdnObject *pSrc)
{
	if ((pDest == NULL) || (pSrc == NULL) || !(pDest->getObjectID()
			== pSrc->getObjectID()))
		return false;
	pDest->setValue(pSrc->getValue());
	list<NMCSbdnObject *> destChilds = pDest->getChildSbdnObjects();
	NMCSbdnObject* srcChild = NULL;
	BOOST_FOREACH(NMCSbdnObject *destChild, destChilds)
				{
					srcChild = pSrc->getChildSbdnObjectByObjectID(
							destChild->getObjectID().GetID());
					if (srcChild == NULL)
					{
						continue;
					}
					if (!synSbdnObjectTree(destChild, srcChild))
					{
						return false;
					}
				}
	return true;
}

NMCSbdnObjectPtr NMCSbdnObjectParser::loadSbdnObjectFromXml(
		TiXmlElement *xmlRoot)
{
	NMCSbdnObject *root;
	NMCSbdnObjectTreeBuilder::getInstance()->loadSbdnObjectFromXml(xmlRoot,
			root, true);
	return NMCSbdnObjectPtr(root);
}



void NMCSbdnObjectParser::saveSystreeToNMAction(NMCSbdnObject *root,
		string &message, int action, int seq /* = 0 */)
{
	TiXmlElement *xmlRoot = NULL;
	saveSystreeToNMXml(root, xmlRoot);
	xmlToAction(xmlRoot, message, action, seq);
}
void NMCSbdnObjectParser::saveSystreeToNMXml(NMCSbdnObject *root,
                                             TiXmlElement *&xmlRoot)
{
    NMCSbdnObjectTreeBuilder::getInstance()->saveSystreeToNMXml(root, xmlRoot);
}
void NMCSbdnObjectParser::saveSingleSbdnObjectToAction(NMCSbdnObject *root,
		string &message, int action, int seq /* = 0 */)
{
	TiXmlElement *xmlRoot = new TiXmlElement(root->getName().c_str());
	saveSingalSbdnObjectToXml(root, xmlRoot);
	xmlToAction(xmlRoot, message, action, seq);
}

void NMCSbdnObjectParser::saveSingalSbdnObjectToXml(NMCSbdnObject *root,
		TiXmlElement *xmlRoot)
{
	try
	{
		XmlParser::checkPointerValid(root);
		XmlParser::checkPointerValid(xmlRoot);
		xmlRoot->SetValue(root->getName());
		// Set attributes
		xmlRoot->SetAttribute("treeid", root->getTreeID().GetID());
		xmlRoot->SetAttribute("classid", root->getClassID().GetID());
		xmlRoot->SetAttribute("objectid", root->getObjectID().GetID());
		if (root->getValue().GetType() != E_InvalidValueType)
		{
			xmlRoot->SetAttribute("type", root->getValue().GetTypeName());
			xmlRoot->SetAttribute("value", root->getValue().GetValueString());
		}
	}
	catch (const runtime_error &)
	{
		throw;
	}
}


void NMCSbdnObjectParser::xmlToAction(TiXmlElement *event, string &message,
		int action, int seq)
{
	TiXmlDocument doc;
	TiXmlDeclaration* declNode = new TiXmlDeclaration("1.0", "UTF-8", "");
	doc.LinkEndChild(declNode);
	TiXmlElement *controlNode = new TiXmlElement("Control");
	doc.LinkEndChild(controlNode);
	TiXmlElement *actionNode = new TiXmlElement("Action");
	XmlParser::setValue(actionNode, action);
	controlNode->LinkEndChild(actionNode);
	TiXmlElement *seqNode = new TiXmlElement("Seq");
	XmlParser::setValue(seqNode, seq);
	actionNode->LinkEndChild(seqNode);
	TiXmlElement *evenNode = static_cast<TiXmlElement *> (event);
	actionNode->LinkEndChild(evenNode);
	XmlParser::xmlToStr(&doc, message);
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
