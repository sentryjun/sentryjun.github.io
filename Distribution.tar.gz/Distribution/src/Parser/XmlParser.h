/*
  *XmlParser.h
 *
  * Created on: 2009-11-15
  *     Author: xzhang
 */

#ifndef XMLPARSER_H_
#define XMLPARSER_H_
#include <stdexcept>
#include "../SbdnObject/XML/tinyxml.h"
using namespace std;

namespace PKU_SatLab_DBS_NMC
{
	class NMCSbdnObject;
	namespace Parser
	{
		class XmlParser
		{
		public:
			static TiXmlElement *firstChildElement(TiXmlElement *, const string &);
			static TiXmlElement *firstChildElement(TiXmlElement *);
			static TiXmlElement *firstChildElementBySeperator(TiXmlElement *, const string &, char = '.');
			static TiXmlElement *nextSiblingElement(TiXmlElement *);
			static void clearChild(TiXmlElement *);
			typedef bool (*ClearStrategy)(const TiXmlElement *);
			static void clearChildByStrategy(TiXmlElement *, ClearStrategy);

			template <typename ValueType>
			static void attribute(TiXmlElement *parent, const string &attributename, ValueType &value)
			{
				try
				{
					checkPointerValid(parent);
					parent->Attribute(attributename, &value);
				}
				catch (const runtime_error &)
				{
					throw;
				}
			}
			static void attributeStr(TiXmlElement *, const string &, string &);

			static void setValue(TiXmlElement *, int);

			static TiXmlElement* addObjectChild(TiXmlElement*, const string&);
			static TiXmlElement* addStringChild(TiXmlElement*, const string&, const string&);
			static TiXmlElement* addIntChild(TiXmlElement*, const string&, const int&);
			static TiXmlElement* addInt64Child(TiXmlElement*, const string&, const int64_t&);

			static void getChildValue(TiXmlElement *, const string &, string &);
			static void getChildValue(TiXmlElement *, const string &, int &);
			static void getChildValue(TiXmlElement *, const string &, int64_t &);
			static void xmlToStr(TiXmlElement *, string &);
			static void xmlToStr(TiXmlDocument *, string &, size_t prealloc = 0);
			template <typename PointerType>
			static void checkPointerValid(PointerType *root)
			{
				if (root == NULL)
				{
					ostringstream ostr;
					ostr << "empty pointer " << __FILE__ << __LINE__;
					throw runtime_error(ostr.str());
				}
			}

			static void setIntValueToObjectFromXml(TiXmlElement *, const string &,
					NMCSbdnObject *, const string &);
			static void setInt64ValueToObjectFromXml(TiXmlElement *, const string &,
					NMCSbdnObject *, const string &);
			static void setTimeValueToObjectFromXml(TiXmlElement *, const string &,
					NMCSbdnObject *, const string &);
			static void setStringValueToObjectFromXml(TiXmlElement *, const string &,
					NMCSbdnObject *, const string &);

		private:
			XmlParser();
		};
	}
}

#endif /* XMLPARSER_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
