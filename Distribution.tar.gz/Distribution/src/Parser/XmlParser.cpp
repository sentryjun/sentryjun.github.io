/*
 * XmlParser.cpp
 *
 *  Created on: 2009-11-15
 *      Author: xzhang
 */

#include "XmlParser.h"
#include "../SbdnObjectImpl/NMCSbdnObject.h"

using namespace PKU_SatLab_DBS_NMC;
using namespace Parser;

TiXmlElement *XmlParser::firstChildElement(TiXmlElement *parent,
		const string &childName)
{
	try
	{
		checkPointerValid(parent);
		TiXmlElement *child = parent->FirstChildElement(childName);
		checkPointerValid(child);
		return child;
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

TiXmlElement *XmlParser::firstChildElement(TiXmlElement *parent)
{
	try
	{
		checkPointerValid(parent);
		TiXmlElement *child = parent->FirstChildElement();
		checkPointerValid(child);
		return child;
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

TiXmlElement *XmlParser::firstChildElementBySeperator(TiXmlElement *root,
		const string &path, char seperator)
{
	string firstPart;
	string leftPart = path;
	TiXmlElement *result = root;
	while (!leftPart.empty())
	{
		string::size_type index = leftPart.find(seperator);
		firstPart = leftPart.substr(0, index);
		if (index == string::npos)
		{
			leftPart.clear();
		}
		else
		{
			leftPart = leftPart.substr(index + 1);
		}
		result = firstChildElement(result, firstPart);
	}
	return result;
}

TiXmlElement *XmlParser::nextSiblingElement(TiXmlElement *node)
{
	try
	{
		checkPointerValid(node);
		TiXmlElement *nextNode = node->NextSiblingElement();
		checkPointerValid(nextNode);
		return nextNode;
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::clearChild(TiXmlElement *node)
{
	try
	{
		checkPointerValid(node);
		TiXmlElement *child = node->FirstChildElement();
		while (child)
		{
			TiXmlElement *remove = child;
			child = child->NextSiblingElement();
			node->RemoveChild(remove);
			continue;
		}
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::clearChildByStrategy(TiXmlElement *node, ClearStrategy strategy)
{
	try
	{
		checkPointerValid(node);
		TiXmlElement *child = node->FirstChildElement();
		while (child)
		{
			if (strategy(child))
			{
				TiXmlElement *remove = child;
				child = child->NextSiblingElement();
				node->RemoveChild(remove);
				continue;
			}
			clearChildByStrategy(child, strategy);
			child = child->NextSiblingElement();
		}
	}
	catch (const runtime_error &)
	{
		throw;
	}
}
/*
namespace PKU_SatLab_DBS_NMC
{
	namespace Parser
	{
		template<>
		*/
		void XmlParser::attributeStr(TiXmlElement *parent,
				const string &attributename, string &value)
		{
			try
			{
				checkPointerValid(parent);
				const string *data = parent->Attribute(attributename);
				checkPointerValid(data);
				value = *data;
			}
			catch (const runtime_error &)
			{
				throw;
			}
		}
/*
//	}
//}

template<typename ValueType>
void XmlParser::attribute(TiXmlElement *parent, const string &attributename,
		ValueType &value)
{
	try
	{
		checkPointerValid(parent);
		parent->Attribute(attributename, &value);
	}
	catch (const runtime_error &)
	{
		throw;
	}
}
*/

void XmlParser::setValue(TiXmlElement *root, int value)
{
	try
	{
		checkPointerValid(root);
		root->SetAttribute("type", "int");
		root->SetAttribute("value", value);
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::getChildValue(TiXmlElement *root, const string &name, int &res)
{
	try
	{
		TiXmlElement *child = firstChildElement(root, name);
//		if (strcmp(child->Attribute("type"), "int") == 0)
		{
			attribute(child, "value", res);
		}
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::getChildValue(TiXmlElement *root, const string &name,
		int64_t &res)
{
	try
	{
		TiXmlElement *child = firstChildElement(root, name);
		string value;
		XmlParser::attributeStr(child, "type", value);
		if (value == "long")
		{
			const char *data = child->Attribute("value");
			if (data == NULL)
			{
				throw runtime_error("child has no attibute: value");
			}
			res = atoll(data);
		}
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::getChildValue(TiXmlElement *root, const string &name,
		string &res)
{
	try
	{
		TiXmlElement *child = firstChildElement(root, name);
		string value;
		XmlParser::attributeStr(child, "type", value);
		if (value == "string")
		{
			const char *data = child->Attribute("value");
			if (data == NULL)
			{
				throw runtime_error("child has no attibute: value");
			}
			res = string(data);
		}
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::xmlToStr(TiXmlElement *root, string &message)
{
	try
	{
		checkPointerValid(root);
		TiXmlPrinter printer;
		printer.SetIndent("\t");
		root->Accept(&printer);
		message = printer.CStr();
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::xmlToStr(TiXmlDocument *root, string &message, size_t prealloc)
{
	try
	{
		checkPointerValid(root);
		TiXmlPrinter printer;
		if (prealloc)
		{
			const_cast<string &>(printer.Str()).resize(prealloc);
			const_cast<string &>(printer.Str()).clear();
		}
		printer.SetStreamPrinting();
		root->Accept(&printer);
		message = printer.Str();
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

/*
template<typename PointerType>
void XmlParser::checkPointerValid(PointerType *root)
{
	if (root == NULL)
	{
		ostringstream ostr;
		ostr << "empty pointer " << __FILE__ << __LINE__;
		throw runtime_error(ostr.str());
	}
}*/

void XmlParser::setIntValueToObjectFromXml(TiXmlElement *rootXml,
		const string &elementName, NMCSbdnObject* rootObj,
		const string &objName)
{
	try
	{
		XmlParser::checkPointerValid(rootObj);
		NMCSbdnObject* res = rootObj->getChildSbdnObject(objName);
		int val = 0;
		XmlParser::getChildValue(rootXml, elementName, val);
		res->setValue(Value(val));
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::setInt64ValueToObjectFromXml(TiXmlElement *rootXml,
		const string &elementName, NMCSbdnObject* rootObj,
		const string &objName)
{
	try
	{
		XmlParser::checkPointerValid(rootObj);
		NMCSbdnObject* res = rootObj->getChildSbdnObject(objName);

		int64_t val = 0;
		XmlParser::getChildValue(rootXml, elementName, val);
		res->setValue(Value(val));
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

void XmlParser::setTimeValueToObjectFromXml(TiXmlElement *rootXml,
		const string &elementName, NMCSbdnObject* rootObj,
		const string &objName)
{
	list<NMCSbdnObject*> resTime;
	TiXmlElement *xmlTime = firstChildElement(rootXml, elementName);
	NMCSbdnObject *object = rootObj->getChildSbdnObject(objName);
	setIntValueToObjectFromXml(xmlTime, "Sec", object, "Sec");
	setIntValueToObjectFromXml(xmlTime, "Millisec", object, "Millisec");
}

void XmlParser::setStringValueToObjectFromXml(TiXmlElement *rootXml,
		const string &elementName, NMCSbdnObject* rootObj,
		const string &objName)
{
	try
	{
		XmlParser::checkPointerValid(rootObj);
		NMCSbdnObject* res = rootObj->getChildSbdnObject(objName);

		string val;
		XmlParser::getChildValue(rootXml, elementName, val);
		res->setValue(Value(val));
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

TiXmlElement* XmlParser::addObjectChild(TiXmlElement* root, const string& name)
{
	try
	{
		if (root == NULL)
		{
			return NULL;
		}
		TiXmlElement *ele = new TiXmlElement(name);
		if (ele == NULL)
		{
			return NULL;
		}
		root->LinkEndChild(ele);
		return ele;
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

TiXmlElement* XmlParser::addIntChild(TiXmlElement* root, const string& name,
		const int& val)
{
	try
	{
		TiXmlElement *ele = XmlParser::addObjectChild(root, name);
		if (ele == NULL)
		{
			return NULL;
		}
		ele->SetAttribute("type", "int");
		ele->SetAttribute("value", val);
		return ele;
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

TiXmlElement* XmlParser::addInt64Child(TiXmlElement* root, const string& name,
		const int64_t& val)
{
	try
	{
		TiXmlElement *ele = XmlParser::addObjectChild(root, name);
		if (ele == NULL)
		{
			return NULL;
		}
		ele->SetAttribute("type", "long");
		ele->SetAttribute("value", val);
		return ele;
	}
	catch (const runtime_error &)
	{
		throw;
	}
}

TiXmlElement* XmlParser::addStringChild(TiXmlElement* root, const string& name,
		const string& val)
{
	try
	{
		TiXmlElement *ele = XmlParser::addObjectChild(root, name);
		if (ele == NULL)
		{
			return NULL;
		}
		ele->SetAttribute("type", "string");
		ele->SetAttribute("value", val);
		return ele;
	}
	catch (const runtime_error &)
	{
		throw;
	}
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
