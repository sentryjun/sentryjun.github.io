//
// Created by jun on 2021/4/6.
//

#ifndef DISTRIBUTION_NMCDISTPROGRAM_H
#define DISTRIBUTION_NMCDISTPROGRAM_H

#include <string>
#include <boost/asio.hpp>
#include <boost/signals2.hpp>
#include <boost/thread.hpp>
#include <boost/shared_ptr.hpp>

#include "../Service/Connection/TcpConnection.h"
#include "../Service/Timer/TimerService.h"

using namespace std;
using namespace boost;
using namespace signals2;
namespace PKU_SatLab_DBS_NMC {
    class NMCDistProgram {
    public:
        typedef boost::shared_ptr<strand> StrandPtr;
        typedef boost::shared_ptr<TcpConnection> ConnectionPtr;
        typedef ip::address Address;
        typedef tcp::endpoint Endpoint;
        typedef boost::shared_ptr<tcp::endpoint> EndpointPtr;
        typedef shared_ptr<Timer> TimerPtr;

    public:
        NMCDistProgram(const string& name, int32_t channel);
        NMCDistProgram(const string& name, int32_t channel, const string & ipAddr,
                       int32_t progtamPort, int32_t localPort);
        ~NMCDistProgram();
        void initialize();

        static boost::signals2::signal<void (const string &, const string &, int pipe)> synToAccessProgramRequest;

        static boost::signals2::signal<void (NMCDistProgram *)> ProgramConstruct;

        static boost::signals2::signal<void (const string&, int32_t channel)> changeChannelMsg;

        static boost::signals2::signal<void (NMCDistProgram *)> ProgramConnect;
        static boost::signals2::signal<void (NMCDistProgram *)> ProgramDisconnect;

        void attachConnection(ConnectionPtr &connection, EndpointPtr & endpoint);
        bool isAttached();
        bool isActive();
        void setEndpoint(EndpointPtr &endpoint);
        void setConnection(ConnectionPtr & connection);

        void synToProgram(const string & message);
        void synToProgramHandler(const string & message);
        void messageComeHandler(const string & message);
        void connectionErrorHandler(const string &message, ConnectionPtr & connection);
        void resetConnectionHandler();
        void connectionConnectedHandler(ConnectionPtr & connection,
                                        EndpointPtr & endpoint);
        // Add for stop connection;
        void stopProgram();
        void reconfigProgram(int32_t channel, const string& ipAddr, int32_t programPort, int32_t localPort);
        void registerHandler(const string & message);
        string getName();
        string getIpAddr();
        int32_t getLocalPort();
        int32_t getProgPort();
        int32_t getChannel();
        bool isReset();
        void switchReset(){m_reset = !m_reset;}
    private:
        ConnectionPtr m_connection;
        EndpointPtr m_endpoint;
        int32_t m_channel;
        string m_name;
        StrandPtr m_strand;
        string m_ipAddr;
        int32_t m_programPort;
        int32_t m_localPort;
        bool m_reset;
//        TimerPtr reconnectTimer;
    };
}



#endif //DISTRIBUTION_NMCDISTPROGRAM_H
