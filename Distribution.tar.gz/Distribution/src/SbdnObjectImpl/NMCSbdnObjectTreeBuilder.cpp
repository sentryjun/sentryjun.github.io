#include "NMCSbdnObjectTreeBuilder.h"
#include "NMCSbdnObjectBuilder.h"
#include "NMCSbdnObject.h"
#include "NMCSbdnReference.h"
#include "NMCSbdnObjectType.h"

#include "../Common/enum.h"
#include "../Service/Logger/LogService.h"
#include <map>
#include <boost/cast.hpp>
#include <boost/foreach.hpp>

using namespace boost;
using namespace PKU_SatLab_DBS_NMC;
using namespace service;

NMCSbdnObjectTreeBuilder* NMCSbdnObjectTreeBuilder::m_instance = NULL;

NMCSbdnObjectTreeBuilder::NMCSbdnObjectTreeBuilder()
{
	m_objectBuilder = NMCSbdnObjectBuilder::getInstance();
}

NMCSbdnObjectTreeBuilder* NMCSbdnObjectTreeBuilder::getInstance()
{
	if (m_instance == NULL)
		m_instance = new NMCSbdnObjectTreeBuilder();
	return m_instance;
}

NMCSbdnObject *NMCSbdnObjectTreeBuilder::loadSbdnObjectFromContent(
		const char *pContent, bool initRef)
{
	TiXmlDocument doc;
	doc.Parse(pContent);
	TiXmlElement *xmlRoot = doc.FirstChildElement();
	return loadSbdnObjectFromXml(xmlRoot, initRef);
}

NMCSbdnObject *NMCSbdnObjectTreeBuilder::loadBaseSbdnObjectFromContent(
		const char *pContent)
{
	TiXmlDocument doc;
	doc.Parse(pContent);
	TiXmlElement *xmlRoot = doc.FirstChildElement();
	return loadBaseSbdnObjectFromXml(xmlRoot);
}

NMCSbdnObject *NMCSbdnObjectTreeBuilder::loadSbdnObjectFromXml(
		TiXmlElement *xmlRoot, bool initRef)
{
	NMCSbdnObject *result = NULL;
	loadSbdnObjectFromXml(xmlRoot, result, initRef);
	return result;
}

NMCSbdnObject *NMCSbdnObjectTreeBuilder::loadBaseSbdnObjectFromXml(
		const TiXmlElement *xmlRoot)
{
	NMCSbdnObject *result = NULL;
	loadBaseSbdnObjectFromXml(xmlRoot, result);
	return result;
}

struct ObjectMapKey
{
	const string &m_name;
	const string m_value;
	ObjectMapKey(const string &name, const string &value) :
		m_name(name), m_value(value)
	{
	}

	bool operator<(const ObjectMapKey &rhs) const
	{
		if (m_name != rhs.m_name)
		{
			return m_name < rhs.m_name;
		}
		return m_value < rhs.m_value;
	}
};

void NMCSbdnObjectTreeBuilder::loadSbdnObjectFromXml(
		TiXmlElement *xmlRoot, NMCSbdnObject *&root, bool initRef)
{
	ObjectList references;
	loadSbdnObjectFromXml(xmlRoot, root, references);

	if (!initRef)
	{
		return;
	}
	/* deal with the reference */

	/* create object buffer to speed search reference */

	typedef set<NMCSbdnObject *> Parents;
	typedef map<ObjectMapKey, Parents> ObjectMap;
	ObjectMap objectBuffer;

	BOOST_FOREACH(NMCSbdnObject *ref, references)
				{
					NMCSbdnObject *realObject = NULL;
					ObjectList objects;
					const string &name = ref->getName();
					const string value = ref->getValue().GetValueString();
					ObjectMap::const_iterator itor = objectBuffer.find(
							ObjectMapKey(name, value));
					if (itor != objectBuffer.end())
					{
						NMCSbdnReference::downcast(ref)->setObject(*(itor->second.begin()));
						continue;
					}
					itor = objectBuffer.find(ObjectMapKey(name, ""));
					if (itor != objectBuffer.end())
					{
						BOOST_FOREACH(NMCSbdnObject *parent, itor->second)
									{
										realObject
												= parent->getChildSbdnObjectByValue(
														name, value);
										if (realObject != NULL
												&& realObject->getClassID().GetID()
														!= SBDNREFERENCEID)
										{
											objectBuffer[ObjectMapKey(name,
													value)].insert(realObject);
											NMCSbdnReference::downcast(ref)->setObject(
													realObject);
											break;
										}
									}
					}
					if (realObject)
					{
						continue;
					}
					//		cout << "reference: " << ref->getName() <<" value: " << ref->getValue().GetValueString() << endl;
					root->getSbdnObjectItemsByNameValue(name, value, objects);
					BOOST_FOREACH(NMCSbdnObject *&object, objects)
								{
									if (object->getClassID().GetID()
											!= SBDNREFERENCEID)
									{
										realObject = object;
										objectBuffer[ObjectMapKey(name, value)].insert(realObject);
										objectBuffer[ObjectMapKey(name, "")].insert(realObject->getParent());
										break;
									}
								}
					if (realObject == NULL)
					{
						LOG(TRACE, "", "can't find reference: " + name + ", " + value + " treeid:"+ref->getTreeID().GetID());
						continue;
					}
					NMCSbdnReference::downcast(ref)->setObject(realObject);
				}
}

void NMCSbdnObjectTreeBuilder::loadBaseSbdnObjectFromXml(
		const TiXmlElement *xmlRoot, NMCSbdnObject *&root)
{
	ObjectList references;
	loadBaseSbdnObjectFromXml(xmlRoot, root, references);
}

void NMCSbdnObjectTreeBuilder::loadSbdnObjectFromXml(
		TiXmlElement *xmlRoot, NMCSbdnObject *&root,
		ObjectList &references)
{
	if (xmlRoot == NULL)
	{
		return;
	}

	// validate node type
	if (xmlRoot->Type() != TiXmlNode::ELEMENT)
		return;

	NMCSbdnAttr attr;
	loadObjectAttr(xmlRoot, attr);
	// Create Root SbdnObject
	NMCSbdnObject *pNewObject = m_objectBuilder->newObject(attr.m_name,
			attr.m_treeID, attr.m_classID, attr.m_objectID);
	setObjectValue(*pNewObject, attr);
	setObjectUpdate(*pNewObject, attr);
	setObjectNode(*pNewObject, attr);

	if (root == NULL)
	{
		root = pNewObject;
	}
	else
	{
		root->addChildSbdnObject(NMCSbdnObject::ObjectPtr(pNewObject));
	}

	// If the root node is a reference node, delete the child node which was created just now
	string strObjectClassID = pNewObject->getClassID().GetID();
	if (strObjectClassID == SBDNREFERENCEID)
	{
		references.push_back(pNewObject);
		return;
	}

	// Load sub node
	TiXmlElement *pChildElement = xmlRoot->FirstChildElement();
	while (pChildElement != NULL)
	{
		TiXmlElement *next = pChildElement->NextSiblingElement();
		loadSbdnObjectFromXml(pChildElement, pNewObject, references);
		pChildElement = next;
	}
	pNewObject->initialize();
	xmlRoot->Parent()->RemoveChild(xmlRoot);
}

void NMCSbdnObjectTreeBuilder::loadBaseSbdnObjectFromXml(
		const TiXmlElement *xmlRoot, NMCSbdnObject *&root,
		ObjectList &references)
{
	if (xmlRoot == NULL)
	{
		return;
	}

	// validate node type
	if (xmlRoot->Type() != TiXmlNode::ELEMENT)
		return;

	NMCSbdnAttr attr;
	loadObjectAttr(xmlRoot, attr);
	// Create Root SbdnObject
	NMCSbdnObject *pNewObject = m_objectBuilder->newBaseObject(attr.m_name,
			attr.m_treeID, attr.m_classID, attr.m_objectID);
	setObjectValue(*pNewObject, attr);
	setObjectUpdate(*pNewObject, attr);

	if (root == NULL)
	{
		root = pNewObject;
	}
	else
	{
		root->addChildSbdnObject(NMCSbdnObject::ObjectPtr(pNewObject));
	}

	// If the root node is a reference node, delete the child node which was created just now
	string strObjectClassID = pNewObject->getClassID().GetID();
	if (strObjectClassID == SBDNREFERENCEID)
	{
		references.push_back(pNewObject);
		return;
	}

	// Load sub node
	const TiXmlElement *pChildElement = xmlRoot->FirstChildElement();
	while (pChildElement != NULL)
	{
		loadBaseSbdnObjectFromXml(pChildElement, pNewObject, references);
		pChildElement = pChildElement->NextSiblingElement();
	}
	pNewObject->initialize();
}

void NMCSbdnObjectTreeBuilder::loadObjectAttr(const TiXmlElement *xmlNode,
		NMCSbdnAttr &attr)
{
	const TiXmlAttribute *pAttr = xmlNode->FirstAttribute();
	string attrValue;
	attr.m_name = xmlNode->ValueStr();
	for (; pAttr; pAttr = pAttr->Next())
	{
		attrValue = pAttr->ValueStr();
		SbdnAttrType attrType = strToEnum<SbdnAttrType> (pAttr->Name());
		switch (attrType)
		{
			case TreeID:
			{
				attr.m_treeID = attrValue;
				break;
			}
			case ClassID:
			{
				attr.m_classID = attrValue;
				break;
			}
			case ObjectID:
			{
				attr.m_objectID = attrValue;
				break;
			}
			case Type:
			{
				attr.m_type = attrValue;
				break;
			}
			case Value:
			{
				attr.m_value = attrValue;
				break;
			}
			case Update:
			{
				attr.m_update = attrValue;
				break;
			}
			case Node:
			{
				attr.m_node = attrValue;
			}
		}
	}
}

void NMCSbdnObjectTreeBuilder::setObjectValue(NMCSbdnObject &object,
		const NMCSbdnAttr &attr)
{
	const string &strType = attr.m_type;
	const string &strValue = attr.m_value;
	SbdnValueType valueType;
	if (strType == "")
	{
		valueType = String;
	}
	else
	{
		valueType = strToEnum<SbdnValueType> (strType);
	}
	switch (valueType)
	{
		case Bool:
		{
			if (strValue != "")
			{
				BoolValue boolValue = strToEnum<BoolValue> (strValue);
				bool value;
				switch (boolValue)
				{
					case True:
					{
						value = true;
						break;
					}
					case False:
					{
						value = false;
						break;
					}
				}
				object.setValue(PKU_SatLab_DBS_Common::Value(value));
			}
			break;
		}
		case Byte:
		{
			if (strValue != "")
			{
				byte value = (byte) atoi(strValue.c_str());
				object.setValue(PKU_SatLab_DBS_Common::Value(value));
			}
			break;
		}
		case Int32:
		{
			if (strValue != "")
			{
				int value = atoi(strValue.c_str());
				object.setValue(PKU_SatLab_DBS_Common::Value(value));
			}
			break;
		}
		case Int64:
		{
			if (strValue != "")
			{
				int64_t value = atoll(strValue.c_str());
				object.setValue(PKU_SatLab_DBS_Common::Value(value));
			}
			break;
		}
		case Double:
		{
			if (strValue != "")
			{
				double value = atof(strValue.c_str());
				object.setValue(PKU_SatLab_DBS_Common::Value(value));
			}
			break;
		}
		case String:
		{
			object.setValue(PKU_SatLab_DBS_Common::Value(strValue));
			break;
		}
	}
}

void NMCSbdnObjectTreeBuilder::setObjectUpdate(NMCSbdnObject &object,
		const NMCSbdnAttr &attr)
{
	const string &updateValue = attr.m_update;
	if (updateValue.empty())
	{
		return;
	}
	BoolValue boolValue = strToEnum<BoolValue> (updateValue);
	bool update;
	switch (boolValue)
	{
		case True:
		{
			update = true;
			break;
		}
		case False:
		{
			update = false;
			break;
		}
	}
	object.setUpdate(update);
}

void NMCSbdnObjectTreeBuilder::setObjectNode(NMCSbdnObject &object,
		const NMCSbdnAttr &attr)
{
	const string &nodeValue = attr.m_node;
	if (nodeValue.empty())
	{
		return;
	}
	BoolValue boolValue = strToEnum<BoolValue> (nodeValue);
	bool isNode;
	switch (boolValue)
	{
		case True:
		{
			isNode = true;
			break;
		}
		case False:
		{
			isNode = false;
			break;
		}
	}
	object.setNode(isNode);
}

void NMCSbdnObjectTreeBuilder::saveSbdnObjectToXml(const NMCSbdnObject *root,
		TiXmlElement *&xmlRoot)
{
	// Create the current element
	xmlRoot = new TiXmlElement(root->getName());

	// Set attributes
	xmlRoot->SetAttribute(m_scStrTreeID, root->getTreeID().GetID());
	xmlRoot->SetAttribute(m_scStrClassID, root->getClassID().GetID());
	xmlRoot->SetAttribute(m_scStrObjectID, root->getObjectID().GetID());
	string nodeStr = (root->isNode())?"true":"false";
	xmlRoot->SetAttribute("node", nodeStr);
	if(root->getValue().GetType() != E_InvalidValueType)
	{
		xmlRoot->SetAttribute(m_scStrType, root->getValue().GetTypeName());
		xmlRoot->SetAttribute(m_scStrValue, root->getValue().GetValueString());
	}
	/*if (root->getName() == "ReceiverStation" && root->getClassID() == string(SBDNNODEID))
	{
		// load station from db
		NMCSbdnObject *node = const_cast<NMCSbdnObject *>(root);
		NMCStation *station = NMCStation::downcast(node);
		NMCStation::ScopeLoad load(station);

		// Add sub SbdnObjects
		NMCSbdnObject::ObjectList childObjects = root->getChildSbdnObjectPtrs();
		NMCSbdnObject::ObjectList::const_iterator itor = childObjects.begin();

		while(itor != childObjects.end())
		{
			// save data to child node
			TiXmlElement *pChildNode = NULL;
			saveSbdnObjectToXml(itor->get(), pChildNode);

			// add to child element
			xmlRoot->LinkEndChild(pChildNode);

			itor ++;
		}
		return;
	}*/

	// Add sub SbdnObjects
	NMCSbdnObject::ObjectList childObjects = root->getChildSbdnObjectPtrs();
	NMCSbdnObject::ObjectList::const_iterator itor = childObjects.begin();

	while(itor != childObjects.end())
	{
		// save data to child node
		TiXmlElement *pChildNode = NULL;
		saveSbdnObjectToXml(itor->get(), pChildNode);

		// add to child element
		xmlRoot->LinkEndChild(pChildNode);

		itor ++;
	}
}

void NMCSbdnObjectTreeBuilder::saveVoiceSbdnObjectToXml(const NMCSbdnObject *root,
		TiXmlElement *&xmlRoot)
{
	// Create the current element
	string nodeName = root->getName();
	if ((nodeName != "PhysicalDevice")
				&& (nodeName != "ReceiverStation")
				&& (nodeName != "Alias")
				&& (nodeName != "IP")
				&& (nodeName != "PhoneNum")
				&& (nodeName != "Channel")
				//&& (nodeName != "Workstate")
				&& (nodeName != "Active")
				&& (nodeName != "CenterDeviceSystem")
				&& (nodeName != "VoiceSignalServer")
				&& (nodeName != "Alias")
				&& (nodeName != "NetWorkCard")
				&& (nodeName != "DeviceID")
				//&& (nodeName != "ReceiverSystem")
				//&& (nodeName != "ReceiverSystem")
				&& (nodeName != "ReceiverSystem"))
		return;
	/*if (nodeName == "ReceiverStation") {
			NMCSbdnObject *node = const_cast<NMCSbdnObject *>(root);
			NMCStation *station = NMCStation::downcast(node);
			if(station->getChildSbdnObject("Type")->getValue().GetValueString()	!= "duplex")
				return;
	}*/
	xmlRoot = new TiXmlElement(root->getName());

	// Set attributes
	xmlRoot->SetAttribute(m_scStrTreeID, root->getTreeID().GetID());
	xmlRoot->SetAttribute(m_scStrClassID, root->getClassID().GetID());
	xmlRoot->SetAttribute(m_scStrObjectID, root->getObjectID().GetID());
	string nodeStr = (root->isNode())?"true":"false";
	xmlRoot->SetAttribute("node", nodeStr);
	if(root->getValue().GetType() != E_InvalidValueType)
	{
		xmlRoot->SetAttribute(m_scStrType, root->getValue().GetTypeName());
		xmlRoot->SetAttribute(m_scStrValue, root->getValue().GetValueString());
	}
	/*if (root->getName() == "ReceiverStation" && root->getClassID() == string(SBDNNODEID))
	{
		// load station from db
		NMCSbdnObject *node = const_cast<NMCSbdnObject *>(root);
		NMCStation *station = NMCStation::downcast(node);
		NMCStation::ScopeLoad load(station);

		// Add sub SbdnObjects
		NMCSbdnObject::ObjectList childObjects = root->getChildSbdnObjectPtrs();
		NMCSbdnObject::ObjectList::const_iterator itor = childObjects.begin();

		while(itor != childObjects.end())
		{
			// save data to child node
			TiXmlElement *pChildNode = NULL;
			saveVoiceSbdnObjectToXml(itor->get(), pChildNode);

			// add to child element
			if (pChildNode != NULL)
				xmlRoot->LinkEndChild(pChildNode);

			itor ++;
		}
		return;
	}*/

	// Add sub SbdnObjects
	NMCSbdnObject::ObjectList childObjects = root->getChildSbdnObjectPtrs();
	NMCSbdnObject::ObjectList::const_iterator itor = childObjects.begin();

	while(itor != childObjects.end())
	{
		// save data to child node
		TiXmlElement *pChildNode = NULL;
		saveVoiceSbdnObjectToXml(itor->get(), pChildNode);

		// add to child element
		if (pChildNode != NULL)
			xmlRoot->LinkEndChild(pChildNode);

		itor ++;
	}
}



void NMCSbdnObjectTreeBuilder::saveSystreeToNMXml(const NMCSbdnObject *root,
		TiXmlElement *&xmlRoot)
{
	// Create the current element
	xmlRoot = new TiXmlElement(root->getName());

	// Set attributes
	xmlRoot->SetAttribute(m_scStrTreeID, root->getTreeID().GetID());
	xmlRoot->SetAttribute(m_scStrClassID, root->getClassID().GetID());
	xmlRoot->SetAttribute(m_scStrObjectID, root->getObjectID().GetID());
	string nodeStr = (root->isNode())?"true":"false";
	xmlRoot->SetAttribute("node", nodeStr);
	if(root->getValue().GetType() != E_InvalidValueType)
	{
		xmlRoot->SetAttribute(m_scStrType, root->getValue().GetTypeName());
		xmlRoot->SetAttribute(m_scStrValue, root->getValue().GetValueString());
	}

	// Add sub SbdnObjects
	NMCSbdnObject::ObjectList childObjects = root->getChildSbdnObjectPtrs();
	NMCSbdnObject::ObjectList::const_iterator itor = childObjects.begin();

	if (root->getName() == "ReceiverSystem")
	{
		return;
	}

	while(itor != childObjects.end())
	{
		// save data to child node
		TiXmlElement *pChildNode = NULL;
		saveSystreeToNMXml(itor->get(), pChildNode);

		// add to child element
		xmlRoot->LinkEndChild(pChildNode);

		itor ++;
	}
}

//void NMCSbdnObjectTreeBuilder::saveSbdnObjectToXml(const NMCSbdnObject *root,
//		const string &content)
//{
//	SaveSbdnObjectToXml(root->upcast(), content);
//}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
