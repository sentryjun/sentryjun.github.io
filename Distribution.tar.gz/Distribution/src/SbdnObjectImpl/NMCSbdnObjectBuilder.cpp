/*
 * ObjectManager.cpp
 *
 *  Created on: 2009-11-17
 *      Author: xzhang
 */

#include "NMCSbdnObjectBuilder.h"
#include "NMCSbdnObject.h"
#include "NMCSbdnReference.h"
/*#include "../Snmp/NMCSnmpServer.h"
#include "../Snmp/NMCSnmpProgram.h"
#include "../Snmp/NMCBackwardGateway.h"
#include "../Snmp/NMCKeyServer.h"
#include "../Snmp/NMCInfoStation.h"
#include "../Snmp/NMCMngServer.h"
#include "../Snmp/NMCSecServer.h"
#include "../Snmp/NMCVoiceProgram.h"
#include "../Snmp/NMCSecurityServer.h"
#include "../Snmp/DemodulationCard.h"
#include "../Snmp/ChannelAllocatorProgram.h"
#include "../SBT/NMCStation.h"
#include "Server/NMCServer.h"
#include "Event/NMCEvent.h"
#include "Program/NMCProgram.h"
#include "Program/NMCFileProgram.h"
#include "Program/NMCAccessProgram.h"
#include "Program/NMCMessageProgram.h"
#include "Program/NMCStorageProgram.h"
#include "Program/NMCGatewayProgram.h"
#include "Program/NMCUIProgram.h"
#include "Program/NMCDisplayProgram.h"
#include "Program/NMCSecurityProgram.h"
#include "Program/NMCRTStreamProgram.h"
#include "Program/NMCNetManager.h"
#include "ATDMServer.h"
#include "../IPort/IPortServer.h"
#include "../IPort/NMCIPortProgram.h"
#include "../ACU/ACUServer.h"
#include "../PA/PAServer.h"
#include "../PA/NMCPAProgram.h"
#include "../ACU/NMCACUProgram.h"
#include "../LNA/LNAServer.h"
#include "../LNA/NMCLNAProgram.h"
#include "../LKURotate/LKuServer.h"
#include "../LKURotate/NMCLKuProgram.h"
#include "../LoopDetect/NMCLoopDetectProgram.h"
#include "../LoopDetect/LoopDetectServer.h"
#include "Program/DissemMngProgram.h"
#include "../Service/UI/UIService.h"
#include "../Service/Database/DatabaseService.h"
#include "../Service/Scheduler/SchedulerService.h"
#include "../Snmp/DemodulationCardService.h"
#include "../Snmp/StationService.h"
#include "../NetManager/CallbackService.h"
#include "../Snmp/DeviceService.h"*/
#include <sstream>

using namespace std;
using namespace PKU_SatLab_DBS_NMC;
//using namespace service;

NMCSbdnObjectBuilder* NMCSbdnObjectBuilder::m_instance = NULL;

NMCSbdnObjectBuilder* NMCSbdnObjectBuilder::getInstance()
{
	if (m_instance == NULL)
		m_instance = new NMCSbdnObjectBuilder();
	return m_instance;
}

NMCSbdnObjectBuilder::NMCSbdnObjectBuilder()
{
	currentObjectID = 1;
//	NMCSbdnObject::nodeAddSignal.connect(bind(&DatabaseService::addNode,
//			DatabaseService::getInstance(), _1));
//	NMCSbdnObject::nodeAddSignal.connect(bind(&UIService::addNode,
//			UIService::getInstance(), _1));

	NMCSbdnObject::getNewObjectID.connect(bind(
			&NMCSbdnObjectBuilder::generateObjectID, this, _1));
	NMCSbdnObject::initObject.connect(bind(
			&NMCSbdnObjectBuilder::connectSignal, this, _1));

/*	NMCInfoStation::getDuplexStationRequest.connect(bind(
			&StationService::getStationsByType, StationService::getInstance(), NMCStation::Duplex));

	NMCSecurityServer::getStationFromXML.connect(bind(
			&SchedulerService::getReceiverSystem,
				SchedulerService::getInstance()));
	NMCSecurityServer::getStationRequest.connect(bind(
			&StationService::getStations,
			StationService::getInstance()));

//	NMCSecServer::getStationRequest.connect(bind(
//			&SchedulerService::getReceiverSystem,
//				SchedulerService::getInstance()));

	NMCSecServer::getStationRequest.connect(bind(
			&StationService::getStations,
				StationService::getInstance()));

//	NMCKeyServer::getStationRequest.connect(bind(
//			&SchedulerService::getReceiverSystem,
//			 SchedulerService::getInstance()));

		NMCKeyServer::getStationRequest.connect(bind(
				&StationService::getStations,
				StationService::getInstance()));

	NMCKeyServer::getSecRequest.connect(bind(&DeviceService::getSecs,
			DeviceService::getInstance()));
	NMCKeyServer::getStationByID.connect(bind(&StationService::getStationByID,
			StationService::getInstance(), _1));

	NMCSnmpProgram::getSeq.connect(bind(&CallbackService::getSeq,
			CallbackService::getInstance()));
	NMCSnmpProgram::releaseSeq.connect(bind(&CallbackService::releaseSeq,
			CallbackService::getInstance(), _1));
	NMCSnmpProgram::addRequest.connect(bind(&CallbackService::addRequest,
			CallbackService::getInstance(), _1, _2, _3));
	NMCSnmpProgram::waitForTimeout.connect(bind(
			&CallbackService::waitForTimeout, CallbackService::getInstance(),
			_1));

	ChannelAllocatorProgram::getDemodulationCardRequest.connect(bind(
			&DemodulationCardService::getDemodulationCards,
			DemodulationCardService::getInstance()));
	ChannelAllocatorProgram::getDuplexStationRequest.connect(bind(
			&StationService::getStationsByType, StationService::getInstance(),
			NMCStation::Duplex));*/
}

static const string SBDNBaseNodeID = "1.3";
static const string SBDNMYNODEID = "1.1.6";
static const string SBDNMYSERVERID = "1.1.9";

NMCSbdnObject* NMCSbdnObjectBuilder::buildNMCObject(const string &strName,
		const string &strTreeID, const string &strClassID,
		const string &strObjectID)
{
	NMCSbdnObject* object = NULL;
	if (strClassID == SBDNOBJECTID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	else if (strClassID == SBDNSERVICEID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	/*else if (strClassID == NMCSnmpServer::getTypeClassID())
	{
		object = new NMCSnmpServer(strName, strTreeID, strClassID, strObjectID);
	}
	else if (strClassID == NMCSnmpProgram::getTypeClassID())
	{
		if (strName == "KeyProgram")
		{
			object = new NMCKeyServer(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "BackwardGatewayProgram")
		{
			object = new NMCBackwardGateway(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "VoiceProgram")
		{
			object = new NMCVoiceProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "SecMachineProgram")
		{
			object = new NMCSecServer(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "InfoProgram")
		{
			NMCInfoStation *infoStation = new NMCInfoStation(strName,
					strTreeID, strClassID, strObjectID);
			object = infoStation;
		}
		else if (strName == "SecurityProgram")
		{
			NMCSecurityServer * tempObject  = new NMCSecurityServer(strName, strTreeID, strClassID,
					strObjectID);
			object = polymorphic_cast<NMCSnmpProgram *>(tempObject);
		}
		//		else if(strName == "EncryptionServer")
		//		{
		//			object = new NMCEncryptionServer(strName, strTreeID, strClassID, strObjectID);
		//		}
		else if (strName == "NetworkManager")
		{
			object = new NMCMngServer(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "DemodulationCardProgram")
		{
			object = new DemodulationCard(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "ChannelAllocationProgram")
		{
			object = new ChannelAllocatorProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		//		else if(strName == "ReceiverSystem")
		//		{
		//			object = new NMCStationServer(strName, strTreeID, strClassID, strObjectID);
		//		}
		else
		{
			object = new NMCSnmpProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
	}*/
	else if (strClassID == SBDNMYNODEID)
	{
		/*if(strName.find("ACU")!=string::npos)
		{
			object = new NMCACUProgram(strName,strTreeID,strClassID,
					strObjectID);
		}
		else
		{
			if(strName.find("LNA")!=string::npos)
			{
				object = new NMCLNAProgram(strName,strTreeID,strClassID,
						strObjectID);
			}
			else if(strName.find("LKu")!=string::npos||strName.find("KuL")!=string::npos)
			{
				object = new NMCLKuProgram(strName,strTreeID,strClassID,
						strObjectID);
			}
			else if(strName.find("LoopDetect")!=string::npos)
			{
				object = new NMCLoopDetectProgram(strName, strTreeID, strClassID,
						strObjectID);
			}
			else if (strName.find("PA") != string::npos)
			{
			  object = new NMCPAProgram(strName, strTreeID, strClassID,
				  strObjectID);
			}
			else
			{
				object = new NMCIPortProgram(strName, strTreeID, strClassID,
						strObjectID);
			}
		}*/
	}
	else if (strClassID == SBDNTHREADID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	else if (strClassID == SBDNSYSTEMID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	else if (strClassID == SBDNACTORID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	else if (strClassID == SBDNUSERID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	else if (strClassID == SBDNSUBMITTERID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	else if (strClassID == SBDNPARAMETERID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	else if (strClassID == SBDNINFOID)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	/*else if (strClassID == SBDNEVENTID)
	{
		object = new NMCEvent("Event", strTreeID, strClassID, strObjectID);
	}*/
	/*else if (strClassID == SBDNNODEID)
	{
		if (strName == "DistributionServer" || strName == "StorageServer"
				|| strName == "GatewayServer" || strName == "AccessServer" || strName == "VoiceSignalServer")
		{
			object = new NMCServer(strName, strTreeID, strClassID, strObjectID);
		}
//		else if (strName == "ReceiverStation" || strName == "LoopDetectServer")
		else if (strName == "ReceiverStation")
		{
			object
					= new NMCStation(strName, strTreeID, strClassID,
							strObjectID);
		}
		else if (strName == "ATDMServer")
		{
			object = new ATDMServer(strName, strTreeID, strClassID,
					strObjectID);
		}
		else
		{
			object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
		}
	}*/
	/*else if(strClassID==SBDNMYSERVERID)
	{
	    if (strName=="LUplinkFrequencyConverterServer"||strName=="LDownlinkFrequencyConverterServer"||strName=="SwitchMachineConverterServer")
		{
			object
				    = new IPortServer(strName,strTreeID,strClassID,strObjectID);
		}
	    if(strName=="LoopDetectServer")
	    {
	    	object
					= new LoopDetectServer(strName,strTreeID,strClassID,strObjectID);
	    }
	    if (strName == "ACUServer")
	          {
	            object = new ACUServer(strName, strTreeID, strClassID, strObjectID);
	          }
	        if (strName == "LNAServer")
	          {
	            object = new LNAServer(strName, strTreeID, strClassID, strObjectID);
	          }
	        if (strName == "PAServer")
	           {
	             object = new PAServer(strName, strTreeID, strClassID, strObjectID);
	           }
	        if (strName == "LKuUplinkFrequencyConverterServer" || strName
	            == "KuLDownlinkFrequencyConverterServer" || strName
	            == "LKuUpRotateSwitchServer" || strName
	            == "KuLDownRotateSwitchServer")
	          {
	            object = new LKuServer(strName, strTreeID, strClassID, strObjectID);
	          }
	}*/
	//else if (strName == "VoiceProgram")
	//{
	//	  printf("vcoice\n");
	//}
	/*else if (strClassID == SBDNPROGRAMID)
	{
		if (strName == "AccessProgram")
		{
			object = new NMCAccessProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "SMProgram")
		{
			object = new NMCMessageProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "GatewayProgram")
		{
			object = new NMCGatewayProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "DisplayProgram")
		{
			object = new NMCUIProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "DisplayProgramm")
		{
			object = new NMCDisplayProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "VoicemanaProgram")
		{
			object = new NMCUIProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "VoicemanaProgramm")
		{
			object = new NMCDisplayProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "SecurityProgram")
		{
			object = new NMCSecurityProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "FileProgram")
		{
			object = new NMCFileProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "RTStreamProgram")
		{
			object = new NMCRTStreamProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "StorageProgram")
		{
			object = new NMCStorageProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "DissemMngProgram")
		{
			object = new DissemMngProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
		else if (strName == "NetManagerProgram")
		{
			object = new NMCNetManager(strName, strTreeID, strClassID,
					strObjectID);
		}
		else
		{
			object = new NMCProgram(strName, strTreeID, strClassID,
					strObjectID);
		}
	}*/
	else if (strClassID == SBDNREFERENCEID)
	{
		object = new NMCSbdnReference(strName, strTreeID, strClassID,
				strObjectID);
	}
	if (object == NULL)
	{
		object = new NMCSbdnObject(strName, strTreeID, strClassID, strObjectID);
	}
	connectSignal(object);
	return object;
}

NMCSbdnObject* NMCSbdnObjectBuilder::newObject(const string &strName,
		const string &strTreeID, const string &strClassID,
		const string &strObjectID)
{
	string objectid = strObjectID;
	if (objectid == "")
	{
		objectid = this->generateObjectID(strClassID);
	}
	return buildNMCObject(strName, strTreeID, strClassID, objectid);
}

NMCSbdnObject* NMCSbdnObjectBuilder::newBaseObject(const string &strName,
		const string &strTreeID, const string &strClassID,
		const string &strObjectID)
{
	string objectid = strObjectID;
	if (objectid == "")
	{
		objectid = this->generateObjectID(strClassID);
	}
	return buildNMCObject(strName, strTreeID, SBDNBaseNodeID, objectid);
}

string NMCSbdnObjectBuilder::generateObjectID(const string &classID)
{
	PKU_SatLab_DBS_Common::ID id(classID);
	ostringstream ostr;
	/* first pos time */
	ostr << time(NULL) << ID::IDSeparator;
	/* second pos objectidnum */
	{
		MutexType::scoped_lock lock(m_threadMutex);
		ostr << currentObjectID++ << ID::IDSeparator;
	}
	/* add class id */
	ostr << classID;
	return ostr.str();
}

NMCSbdnObject* NMCSbdnObjectBuilder::newReference(NMCSbdnObject* object)
{
	NMCSbdnReference* reference = new NMCSbdnReference(object->getName(), "",
			SBDNREFERENCEID, generateObjectID(object->getClassID().GetID()));
	reference->setValue(object->getValue());
	reference->setObject(object);
	connectSignal(reference);
	return reference;
}

void NMCSbdnObjectBuilder::connectSignal(NMCSbdnObject *object)
{
	/*object->nodeAddSignal.connect(bind(&DatabaseService::addNode,
				DatabaseService::getInstance(), object));
	object->nodeAddSignal.connect(bind(&UIService::addNode,
				UIService::getInstance(), object));
	object->valueChangedSignal.connect(bind(&DatabaseService::updateNode,
			DatabaseService::getInstance(), object));
	object->valueChangedSignal.connect(bind(&UIService::updateNode,
			UIService::getInstance(), object));
	object->nodeRemovedSignal.connect(bind(&DatabaseService::removeNode,
			DatabaseService::getInstance(), object));
	object->nodeRemovedSignal.connect(bind(&UIService::removeNode,
			UIService::getInstance(), object));*/

}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
