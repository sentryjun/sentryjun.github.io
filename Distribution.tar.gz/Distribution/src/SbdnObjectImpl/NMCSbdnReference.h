/*
 * NMCSbdnReference.h
 *
 *  Created on: Feb 3, 2011
 *      Author: nile
 */

#ifndef NMCSBDNREFERENCE_H_
#define NMCSBDNREFERENCE_H_

#include "NMCSbdnObject.h"

namespace PKU_SatLab_DBS_NMC
{
	class NMCSbdnReference : public NMCSbdnObject
	{
	public:
		NMCSbdnReference(const string &, const string &, const string &, const string &);
		NMCSbdnObject *getObject() const;
		void setObject(NMCSbdnObject *);
		static NMCSbdnReference *downcast(NMCSbdnObject *);
		static const NMCSbdnReference *downcast(const NMCSbdnObject *);

	private:
		NMCSbdnReference();
		virtual NMCSbdnObject *clone() const;

		ObjectPtr m_realObject;
	};
}

#endif /* NMCSBDNREFERENCE_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
