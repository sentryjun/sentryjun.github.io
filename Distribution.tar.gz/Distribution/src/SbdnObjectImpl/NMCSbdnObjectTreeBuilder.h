#ifndef NMCSBDNOBJECT_TREEBUILDER_H
#define NMCSBDNOBJECT_TREEBUILDER_H

#include <string>
#include <list>
#include <stdexcept>
#include "../SbdnObject/Common/SbdnObjectTreeBuilder.h"
#include "../SbdnObject/XML/tinyxml.h"
using namespace std;
using namespace PKU_SatLab_DBS_Common;

namespace PKU_SatLab_DBS_NMC
{
	class NMCSbdnObject;
	class NMCSbdnObjectBuilder;
	struct NMCSbdnAttr;

	class NMCSbdnObjectTreeBuilder : protected SbdnObjectTreeBuilder
	{
		typedef list<NMCSbdnObject *> ObjectList;

	public:
		static NMCSbdnObjectTreeBuilder *getInstance();
		NMCSbdnObject *loadSbdnObjectFromContent(const char *, bool = true);
		NMCSbdnObject *loadBaseSbdnObjectFromContent(const char *);
		NMCSbdnObject *loadSbdnObjectFromXml(TiXmlElement *, bool);
		NMCSbdnObject *loadBaseSbdnObjectFromXml(const TiXmlElement *);
		void loadSbdnObjectFromXml(TiXmlElement *, NMCSbdnObject *&, bool);
		void loadBaseSbdnObjectFromXml(const TiXmlElement *, NMCSbdnObject *&);
		void saveSbdnObjectToXml(const NMCSbdnObject *, TiXmlElement *&);
		void saveVoiceSbdnObjectToXml(const NMCSbdnObject *, TiXmlElement *&);
		void saveSystreeToNMXml(const NMCSbdnObject *, TiXmlElement *&);
		//void saveSbdnObjectToXml(const NMCSbdnObject *, const string &);

	protected:
		NMCSbdnObjectTreeBuilder();
		void loadSbdnObjectFromXml(TiXmlElement *, NMCSbdnObject *&, ObjectList &);
		void loadBaseSbdnObjectFromXml(const TiXmlElement *, NMCSbdnObject *&, ObjectList &);
		void loadObjectAttr(const TiXmlElement *, NMCSbdnAttr &);
		void setObjectValue(NMCSbdnObject &, const NMCSbdnAttr &);
		void setObjectUpdate(NMCSbdnObject &, const NMCSbdnAttr &);
		void setObjectNode(NMCSbdnObject &, const NMCSbdnAttr &);

		static NMCSbdnObjectTreeBuilder *m_instance;

		NMCSbdnObjectBuilder *m_objectBuilder;
	};
}

#endif /* NMCSBDNOBJECT_TREEBUILDER_H */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
