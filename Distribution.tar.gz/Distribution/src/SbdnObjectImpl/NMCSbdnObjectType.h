/*
 * NMCSbdnObjectType.h
 *
 *  Created on: Feb 3, 2011
 *      Author: nile
 */

#ifndef NMCSBDNOBJECTTYPE_H_
#define NMCSBDNOBJECTTYPE_H_

#include <string>
using namespace std;

namespace PKU_SatLab_DBS_NMC
{
	enum SbdnValueType
	{
		Bool = 0,
		Int32,
		Int64,
		Double,
		Byte,
		String,
	};

	enum SbdnAttrType
	{
		TreeID = 0,
		ClassID,
		ObjectID,
		Type,
		Value,
		Update,
		Node,
	};

	enum BoolValue
	{
		True = 0,
		False,
	};

	struct NMCSbdnAttr
	{
		string m_name;
		string m_treeID;
		string m_classID;
		string m_objectID;
		string m_type;
		string m_value;
		string m_update;
		string m_node;
	};
}

#endif /* NMCSBDNOBJECTTYPE_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
