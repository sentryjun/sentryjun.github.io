/*
 * NMCSbdnObject.h
 *
 *  Created on: 2009-11-15
 *      Author: xzhang
 */

#ifndef NMCSBDNOBJECT_H_
#define NMCSBDNOBJECT_H_

#include <string>
#include <boost/thread.hpp>
#include <boost/signals2.hpp>
#include <boost/enable_shared_from_this.hpp>
#include "../SbdnObject/Common/SbdnObject.h"
using namespace std;
using namespace boost;
using namespace signals2;
using namespace PKU_SatLab_DBS_Common;

namespace PKU_SatLab_DBS_NMC
{
	class NMCSbdnObject: protected PKU_SatLab_DBS_Common::SbdnObject, public enable_shared_from_this<NMCSbdnObject>
	{
	public:
		typedef boost::shared_ptr<NMCSbdnObject> ObjectPtr;
		typedef list<ObjectPtr> ObjectList;

		NMCSbdnObject();
		NMCSbdnObject(const string &name, const string &treeID,
				const string &classID, const string &objectID);
		virtual ~NMCSbdnObject();

		/* initialize after all children and the node been constructed */
		virtual void initialize(void);
		virtual void afterInitialize();
		virtual bool isNode() const;
		virtual NMCSbdnObject *clone() const;
		virtual void cloneInit();

		/* modify child related */
		virtual void addChildSbdnObject(ObjectPtr);
		virtual void removeChildSbdnObject(NMCSbdnObject *);
		virtual void clearChild();
		void reconstructTreeID(const string &);

		/* get attribute */
		const PKU_SatLab_DBS_Common::Value &getValue() const;
		const PKU_SatLab_DBS_Common::ID &getObjectID() const;
		const PKU_SatLab_DBS_Common::ID &getClassID() const;
		const PKU_SatLab_DBS_Common::ID &getTreeID() const;
		const string &getName() const;
		const string &getPath() const;
		virtual bool hasChild(const string &) const;
		bool isUpdate() const;
		int childSize() const;

		/* set attribute */
		void setValue(const PKU_SatLab_DBS_Common::Value &);
		void setValue(const string &value);
		void setName(const string &);
		void setTreeID(const string &);
		void setNode(bool);
		void setUpdate(bool);
		void setEnableSignal(bool);

		/* get related object */
		virtual NMCSbdnObject *getFirstChildSbdnObject();
		virtual NMCSbdnObject *getChildSbdnObject(const string &);
		virtual int getChildSbdnObjects(const string &, list<
						NMCSbdnObject *> &) const;
		virtual NMCSbdnObject *getChildSbdnObjectByNameBySeperator(
				const string &, char = '.') const;
		virtual NMCSbdnObject *getChildSbdnObjectByValue(const string &,
				const string &);
		virtual NMCSbdnObject
		*getChildSbdnObjectByObjectID(const string &) const;
		virtual NMCSbdnObject
		*getFirstSbdnObjectByObjectID(const string &) const;
		virtual NMCSbdnObject *getFirstSbdnObjectItemByName(
				const string &keyword) const;
		virtual NMCSbdnObject *getFirstSbdnObjectByNameValue(const string &,
				const string &);
		virtual NMCSbdnObject *searchFirstSbdnObjectItemByName(const string &);
		virtual int getSbdnObjectItemsByName(const string &, list<
				NMCSbdnObject *> &);
		virtual int getSbdnObjectItemsByNameValue(const string &,
				const string &, list<NMCSbdnObject *> &);
		virtual int searchSbdnObjectItemsByName(const string &, list<
				NMCSbdnObject *> &);
		/* const method */
		NMCSbdnObject *getParent() const;
		virtual const NMCSbdnObject *getFirstChildSbdnObject() const;
		virtual NMCSbdnObject *getChildSbdnObject(const string &) const;
		virtual list<NMCSbdnObject *> getChildSbdnObjects() const;
		ObjectList getChildSbdnObjectPtrs() const;

		/* cast related */
		SbdnObject *upcast();
		const SbdnObject *upcast() const;
		static NMCSbdnObject *downcast(SbdnObject *);

		/* modified related signal */
		boost::signals2::signal<void()> nodeAddSignal;
		boost::signals2::signal<void()> nodeRemovedSignal;
		boost::signals2::signal<void()> valueChangedSignal;
		boost::signals2::signal<void()> valueWillBeChangedSignal;

		/* syn from a copy of the object */
		virtual void synFrom(NMCSbdnObject *, int);
		virtual void synValue(const PKU_SatLab_DBS_Common::Value &);
		typedef boost::function<void(bool)> SynHandlerType;
		typedef boost::function<void(bool,int)> queryHandlerType;
		virtual bool synByValue(NMCSbdnObject *);
		virtual void synByValue(NMCSbdnObject *, SynHandlerType);
		//FIXME change queryValue function to func const
		virtual void queryValue(NMCSbdnObject *, SynHandlerType);

		static boost::signals2::signal<string(const string &)> getNewObjectID;
		static boost::signals2::signal<void(NMCSbdnObject *)> initObject;

	protected:
		typedef boost::recursive_mutex MutexType;

		void updatePath();
		void copyTo(NMCSbdnObject *) const;

		static const char PATH_SEPERATOR = '/';
		unsigned int m_childTreeIDIndex;
		MutexType m_threadMutex;
		ObjectList m_childPtrs;
		string m_path;
		bool m_signalEnabled;
		bool m_isNode;
		bool m_update;
	};
}

#endif /* NMCSBDNOBJECT_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
