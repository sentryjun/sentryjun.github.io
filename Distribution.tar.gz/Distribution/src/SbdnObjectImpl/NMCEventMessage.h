//
// Created by nmc on 2021/4/27.
//

#ifndef DISTRIBUTION_NMCEVENTMESSAGE_H
#define DISTRIBUTION_NMCEVENTMESSAGE_H

#include <string>
#include <boost/asio.hpp>
#include <boost/signals2.hpp>
#include <boost/thread.hpp>
#include <boost/shared_ptr.hpp>
#include "../Parser/XmlParser.h"

#include "../Service/Connection/TcpConnection.h"


using namespace std;
using namespace boost;
using namespace signals2;
using namespace PKU_SatLab_DBS_NMC;
using namespace Parser;

namespace PKU_SatLab_DBS_NMC {
    typedef shared_ptr<TiXmlNode> XMLNodePtr;
    typedef shared_ptr<TiXmlElement> XMLElementPtr;
    class NMCEventMessage {
    public:

        NMCEventMessage(const string & message, bool fileFlag = false);
        ~NMCEventMessage();
        typedef shared_ptr<TiXmlDocument> XmlDocumentPtr;
        typedef map<int, bool> messageFlag;
        boost::signals2::signal<void(string&)>synToAccess;
        void initialize(const string & message, bool messageFlag);
        void parseAction(TiXmlElement *);
        void parseEvent(TiXmlElement *);
        void parseParameter(TiXmlElement *);
        void getEvent(TiXmlElement *);
        void getMessageNode(TiXmlElement *);

        XMLNodePtr getRootPtr();
        XMLNodePtr  getActionPtr();
        XMLNodePtr getEventPtr();
        XMLNodePtr getAccessPtr();
        XMLNodePtr getEventListPtr();

        uint32_t getChannel();
        uint32_t getReqSeq();
        uint32_t getID();
        int getAction();
        int getState();
    private:
        uint32_t _transactionID;
        uint32_t _requestSeq;
        uint32_t _channel;
        int _action;
        int _state;

        XmlDocumentPtr docXml;
    };
}


#endif //DISTRIBUTION_NMCEVENTMESSAGE_H
