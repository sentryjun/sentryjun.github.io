/*
 * ObjectManager.h
 *
 *  Created on: 2009-11-17
 *      Author: xzhang
 */

#ifndef OBJECTMANAGER_H_
#define OBJECTMANAGER_H_

#include <string>
#include <boost/thread.hpp>
using namespace std;
using namespace boost;

namespace PKU_SatLab_DBS_NMC
{
	class NMCSbdnObject;
	class NMCSbdnObjectBuilder
	{
	public:
		static NMCSbdnObjectBuilder *getInstance();

		NMCSbdnObject *newObject(const string &strName, const string &strTreeID,
				const string &strClassID, const string &strObjectID);
		NMCSbdnObject *newBaseObject(const string &strName, const string &strTreeID,
						const string &strClassID, const string &strObjectID);
		NMCSbdnObject *newReference(NMCSbdnObject *object);

	private:
		typedef boost::mutex MutexType;
		NMCSbdnObjectBuilder();
		string generateObjectID(const string &classID);
		NMCSbdnObject *buildNMCObject(const string &strName, const string &strTreeID,
				const string &strClassID, const string &strObjectID);
		void connectSignal(NMCSbdnObject *);

		static NMCSbdnObjectBuilder* m_instance;

		MutexType m_threadMutex;
		unsigned int currentObjectID;
	};
}

#endif /* OBJECTMANAGER_H_ */
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
