//
// Created by jun on 2021/4/6.
//

#include "NMCDistProgram.h"

#include "../Service/SynService.h"
#include "../Service/ForwardService.h"
#include "../Service/Logger/LogService.h"
#include "../Service/IO/StrandService.h"
#include "../Parser/NMCSbdnObjectParser.h"
#include "NMCEventMessage.h"

using namespace PKU_SatLab_DBS_NMC;
using namespace service;

boost::signals2::signal<void (const string &, const string &, int)>
        NMCDistProgram::synToAccessProgramRequest;

boost::signals2::signal<void (NMCDistProgram *)>
        NMCDistProgram::ProgramConstruct;
boost::signals2::signal<void(const string&, int32_t)>
        NMCDistProgram::changeChannelMsg;
boost::signals2::signal<void(NMCDistProgram*)>
        NMCDistProgram::ProgramConnect;
boost::signals2::signal<void(NMCDistProgram*)>
        NMCDistProgram::ProgramDisconnect;
NMCDistProgram::NMCDistProgram(const string &name, int32_t channel):
m_name(name),m_channel(channel){
    m_strand = StrandService::getInstance()->getStrand();
    m_connection.reset();
    m_endpoint.reset();
}
NMCDistProgram::NMCDistProgram(const string &name, int32_t channel, const string &ipAddr, int32_t progtamPort,
                               int32_t localPort) :m_name(name),m_channel(channel),m_ipAddr(ipAddr),
                               m_localPort(localPort), m_programPort(progtamPort){

    m_connection.reset();
    m_endpoint.reset();
    m_reset = false;
}
NMCDistProgram::~NMCDistProgram() {}
void NMCDistProgram::initialize() {
    m_endpoint.reset(new tcp::endpoint(address::from_string(m_ipAddr), m_programPort));
    ProgramConstruct(this);
}

void NMCDistProgram::attachConnection(ConnectionPtr &connection, EndpointPtr &endpoint) {
    setConnection(connection);
    //setEndpoint(endpoint);
}

int32_t NMCDistProgram::getChannel() {return m_channel;}

string NMCDistProgram::getName() {return m_name;};

bool NMCDistProgram::isActive() {
    if (m_connection)
        return m_connection->isConnected();
    return false;
}

void NMCDistProgram::setConnection(ConnectionPtr &connection) {
    m_connection = connection;
    m_connection->messageReadSignal.disconnect_all_slots();
    m_connection->messageReadSignal.connect(bind(
            &NMCDistProgram::messageComeHandler, this, _1));
    m_connection->connectionErrorSignal.disconnect_all_slots();
    m_connection->connectionErrorSignal.connect(bind(
            &NMCDistProgram::connectionErrorHandler, this, _1, m_connection));
}

void NMCDistProgram::setEndpoint(EndpointPtr &endpoint) {
    m_endpoint = endpoint;
}

void NMCDistProgram::connectionErrorHandler(const string &message, ConnectionPtr & connection) {
//    LOG(INFO, "0000", "Connection to " << m_name << " error:" <<
//                                      message)
    if (message == "Operation canceled"){
        return;
    }
    if (message == "Connection refused" || message == "End of file"|| "No route to host" || message == "Operation canceled"||m_reset==true) {
//        LOG(INFO, "0000", "Connection to " << m_name << " error:" <<
//                                      message)
    ProgramDisconnect(this);
    if (m_reset == false) {
        LOG(INFO, "0000", "Connection to " << m_name << " error:" <<
                                                              message << " try to connect")


        connection->connectionConnectedSignal.disconnect_all_slots();
        connection->connectionErrorSignal.disconnect_all_slots();
        connection->disconnect();
        connection->connectionErrorSignal.connect(bind(
                &NMCDistProgram::connectionErrorHandler, this, _1, connection));
        connection->connectionConnectedSignal.connect(bind(&NMCDistProgram::connectionConnectedHandler, this, connection, m_endpoint));

        connection->reconnectHandler(*m_endpoint);
    } else {
        connection->messageReadSignal.disconnect_all_slots();
        connection->connectionErrorSignal.disconnect_all_slots();
        connection.reset();
    }
    }
}

void NMCDistProgram::messageComeHandler(const string &message) {
#ifdef SYN_DEBUG
    LOG(NETIO, "0000", "From " << getName() << " " << message )
#endif
    int action = 0;
    NMCEventMessage msg(message);
    action = msg.getAction();
    //Parser::NMCSbdnObjectPtr actionPtr= Parser::NMCSbdnObjectParser::parseAction(message, action);
    LOG(INFO, "0000", "msg from " << getName() << "Action = " << action)
    if (action == 10021) {
        changeChannelMsg(message, m_channel);
    } else {
        synToAccessProgramRequest(message, m_name, m_channel);
    }
}

void NMCDistProgram::synToProgram(const string &message) {
    //m_strand->dispatch(bind(&NMCDistProgram::synToProgramHandler, this, message));
    synToProgramHandler(message);
}

void NMCDistProgram::synToProgramHandler(const string &message) {
    m_connection->write(message);
//     if (isActive()) {
//         m_connection->write(message);
// #ifdef SYN_DEBUG
//         LOG(NETIO, "0000", "SYN to Program " << getName() << " success")
// #endif
//     }
//     else {
//         m_connection->reconnectHandler(*m_endpoint);
//     }
}

void NMCDistProgram::connectionConnectedHandler(ConnectionPtr &connection, EndpointPtr &endpoint) {
//    connection->getSocket()->set_option(tcp::socket::linger(false, 0));
    m_reset = false;
    LOG(INFO, "0000", "Connection to " << getName() << " -> Active")
//    if(ForwardService::getInstance()->needAccessRegister()) {
        try{
            connection->write(ForwardService::getInstance()->getRegisterStr());
            LOG(NETIO, "0000", "Registered to " <<getName() << ForwardService::getInstance()->getRegisterStr())

        }
        catch (boost::system::error_code error) {
            LOG(ERROR, "0000", "Register to " << getName() << " error: "<<error.message())
        }
//    }
    ProgramConnect(this);
    attachConnection(connection, endpoint);

    connection->startReceive();
}

void NMCDistProgram::resetConnectionHandler() {
    //m_reset = true;
    if (m_connection->isConnected()) {
        stopProgram();
    }
    
}

string NMCDistProgram::getIpAddr() {return m_ipAddr;}

int32_t NMCDistProgram::getLocalPort() {return m_localPort;}

int32_t NMCDistProgram::getProgPort() {return m_programPort;}

void NMCDistProgram::registerHandler(const string &message) {
    if (isActive()) {
        m_connection->write(message);
        LOG(DEBUG, "0000", "register message to " << m_name << ": " << message)
    }
    // if (isActive()) {
    //     m_connection->write(message);
    //     LOG(NETIO, "0000", "register message to " << m_name << ": " << message)
    // } else {
    //     m_connection->reconnectHandler(*m_endpoint);
    // }
}

bool NMCDistProgram::isReset() {
    return m_reset;
}

void NMCDistProgram::stopProgram() {
    m_reset = true;
    if (isActive())
        m_connection->disconnect();
        m_connection.reset();
 }

void NMCDistProgram::reconfigProgram(int32_t channel, const string &ipAddr,
                                     int32_t programPort, int32_t localPort) {
    if (m_reset == false) {
        stopProgram();
    }
    if (channel != m_channel) {
        m_channel = channel;
    }
    if (ipAddr != "") {
        m_ipAddr = ipAddr;
    }
    if (programPort != m_programPort) {
        m_programPort = m_programPort;
    }
    if (localPort != m_localPort) {
        m_localPort = localPort;
    }
}