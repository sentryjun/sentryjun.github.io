/*
 * NMCSbdnReference.cpp
 *
 *  Created on: Feb 3, 2011
 *      Author: nile
 */

#include "NMCSbdnReference.h"
#include <boost/cast.hpp>
using namespace boost;

using namespace PKU_SatLab_DBS_NMC;

NMCSbdnReference::NMCSbdnReference(const string &name, const string &treeID,
		const string &classID, const string &objectID)
: NMCSbdnObject(name, treeID, classID, objectID)
{
}

NMCSbdnReference::NMCSbdnReference()
{
}

NMCSbdnObject *NMCSbdnReference::clone() const
{
	NMCSbdnReference *clone = new NMCSbdnReference();
	copyTo(clone);
	return clone;
}

NMCSbdnObject *NMCSbdnReference::getObject() const
{
	BOOST_ASSERT(m_realObject.get());
	return m_realObject.get();
}

void NMCSbdnReference::setObject(NMCSbdnObject *object)
{
	BOOST_ASSERT(object);
	m_realObject = object->shared_from_this();
}

NMCSbdnReference *NMCSbdnReference::downcast(NMCSbdnObject *object)
{
	return polymorphic_cast<NMCSbdnReference *> (object);
}

const NMCSbdnReference *NMCSbdnReference::downcast(const NMCSbdnObject *object)
{
	return polymorphic_cast<const NMCSbdnReference *> (object);
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
