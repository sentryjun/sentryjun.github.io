//
// Created by nmc on 2021/4/27.
//

#include "NMCEventMessage.h"
#include "../Service/Logger/LogService.h"
NMCEventMessage::NMCEventMessage(const string & message, bool fileFlag) {
    initialize(message, fileFlag);
}

NMCEventMessage::~NMCEventMessage() {}

void NMCEventMessage::initialize(const string &message, bool fileFlag) {
    docXml.reset(new TiXmlDocument());
    if (fileFlag) {
        docXml->LoadFile(message);
    }else{
    docXml->Parse(message.c_str());}
    TiXmlElement * root;
    TiXmlElement * actionNode;
    TiXmlElement * eventNode;
    TiXmlElement * nextHops;
    int reqSeq, id, channel, state;
    try {
        root = docXml->FirstChildElement("Control");
        if (root == NULL)
        {
            throw runtime_error("can't find Control node!");
        }
        actionNode = XmlParser::firstChildElement(root, "Action");
        int action;
        XmlParser::attribute(actionNode, "value", action);
        _action = action;
        if (action == 10002) {return ;}
        if (action == 10006 || action == 10004) {
            TiXmlElement* request = XmlParser::firstChildElementBySeperator(actionNode, "TransactionRequest.RequestSeq");
            TiXmlElement* ID = XmlParser::firstChildElementBySeperator(actionNode, "TransactionRequest.ID");
            XmlParser::attribute(request, "value", reqSeq);
            XmlParser::attribute(ID, "value", id);
            //_requestSeq = reqSeq;
            _transactionID = id;
            _requestSeq = id & (0x0fffffff);

        }

        eventNode = XmlParser::firstChildElementBySeperator(actionNode, "AccessProgram.EventList.Event");

        if (eventNode == NULL) {
            //directly  return
        } else {
            //a signal;
            TiXmlElement* para = XmlParser::firstChildElement(eventNode, "Parameter");
            TiXmlElement* RequestNode = XmlParser::firstChildElement(para, "RequestSeq");
            TiXmlElement* ID = XmlParser::firstChildElement(para, "ID");
            TiXmlElement* Channel = XmlParser::firstChildElement(para, "Channel");
            TiXmlElement* State = XmlParser::firstChildElement(eventNode, "State");

            XmlParser::attribute(RequestNode, "value", reqSeq);
            XmlParser::attribute(Channel, "value", channel);
            XmlParser::attribute(ID, "value", id);
            XmlParser::attribute(State, "value", state);
            _transactionID = id;
            _channel = channel;
            _requestSeq = reqSeq;
            if (reqSeq != (id & (0x0fffffff))) {
                _requestSeq = id & (0x0fffffff);
            }
            _state = state;
        }
    } catch (const std::exception & error) {
        //LOG(service::INFO, "0000", error.what())
    }
}

uint32_t NMCEventMessage::getChannel() {
    return _channel;
}
int NMCEventMessage::getState() {
    return _state;
}
uint32_t NMCEventMessage::getID() {
    return _transactionID;
}
uint32_t NMCEventMessage::getReqSeq() {
    return _requestSeq;
}

int NMCEventMessage::getAction() {
    return _action;
}

void NMCEventMessage::parseEvent(TiXmlElement * eventNode) {
    TiXmlElement* root = docXml->FirstChildElement("Control");
    eventNode = XmlParser::firstChildElementBySeperator(root, "Action.AccessProgram.EventList.Event");
}

void NMCEventMessage::parseAction(TiXmlElement *actionNode ) {
    TiXmlElement * root = docXml->FirstChildElement("Control");
    actionNode = XmlParser::firstChildElement(root, "Action");
}

void NMCEventMessage::parseParameter(TiXmlElement * paramNode) {
    TiXmlElement* root = docXml->FirstChildElement("Control");
    paramNode = XmlParser::firstChildElementBySeperator(root, "Action.AccessProgram.EventList.Event.Parameter");
}

void NMCEventMessage::getMessageNode(TiXmlElement *root) {
    root = docXml->FirstChildElement("Control");
    string ss;
    XmlParser::xmlToStr(root, ss);
    cout << ss;
}

XMLNodePtr NMCEventMessage::getActionPtr() {
    TiXmlElement * root = docXml->FirstChildElement("Control");
    TiXmlElement * actionNode = XmlParser::firstChildElement(root, "Action");
    return XMLNodePtr (actionNode->Clone());
}

XMLNodePtr NMCEventMessage::getEventPtr() {
    TiXmlElement* root = docXml->FirstChildElement("Control");
    TiXmlElement* eventNode = XmlParser::firstChildElementBySeperator(root, "Action.AccessProgram.EventList.Event");
    return XMLNodePtr (eventNode->Clone());
}

XMLNodePtr  NMCEventMessage::getRootPtr() {
    TiXmlElement* root = docXml->FirstChildElement("Control");
    return XMLNodePtr (root->Clone());
}