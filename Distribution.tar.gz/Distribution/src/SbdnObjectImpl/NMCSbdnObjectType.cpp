/*
 * NMCSbdnObjectType.cpp
 *
 *  Created on: Feb 3, 2011
 *      Author: nile
 */

#include "NMCSbdnObjectType.h"
#include "../Common/enum.h"

using namespace PKU_SatLab_DBS_NMC;

template <>
const EnumNameType EnumName<SbdnValueType>::list[] =
{
	"bool",
	"int",
	"long",
	"double",
	"byte",
	"string",
};
template <>
const int EnumName<SbdnValueType>::listNum = getListNum(EnumName<SbdnValueType>::list);

template <>
const EnumNameType EnumName<SbdnAttrType>::list[] =
{
	"treeid",
	"classid",
	"objectid",
	"type",
	"value",
	"update",
	"node",
};
template <>
const int EnumName<SbdnAttrType>::listNum = getListNum(EnumName<SbdnAttrType>::list);

template <>
const EnumNameType EnumName<BoolValue>::list[] =
{
	"true",
	"false",
};
template <>
const int EnumName<BoolValue>::listNum = getListNum(EnumName<BoolValue>::list);
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
