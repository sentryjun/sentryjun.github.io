/*
 *EventImpl.cpp
 *
 * Created on: 2009-11-15
 *     Author: xzhang
 */

#include "NMCSbdnObject.h"
#include <list>
#include <boost/cast.hpp>
#include <boost/foreach.hpp>

using namespace boost;
using namespace PKU_SatLab_DBS_NMC;

boost::signals2::signal<string(const string &)> NMCSbdnObject::getNewObjectID;
boost::signals2::signal<void(NMCSbdnObject *)> NMCSbdnObject::initObject;

//boost::mutex amutex;
//int acount;

NMCSbdnObject::NMCSbdnObject()
{
//	{
//		MutexType::scoped_lock lock(amutex);
//		acount++;
//		cout << "object destruct! now count " << acount << endl;
//	}
	m_childTreeIDIndex = 1;
	m_parentSbdnObject = NULL;
	m_path = PATH_SEPERATOR + m_name;
	m_signalEnabled = false;
	m_isNode = false;
}

NMCSbdnObject::NMCSbdnObject(const string &name, const string &treeID,
		const string &classID, const string &objectID) :
	SbdnObject(name, treeID, classID, objectID)
{
//	{
//		MutexType::scoped_lock lock(amutex);
//		acount++;
//		cout << "object destruct! now count " << acount << endl;
//	}
	m_childTreeIDIndex = 1;
	m_parentSbdnObject = NULL;
	m_path = PATH_SEPERATOR + m_name;
	m_signalEnabled = false;
	m_isNode = false;
}

NMCSbdnObject::~NMCSbdnObject()
{
	{
		MutexType::scoped_lock lock(m_threadMutex);
		m_childSbdnObjects.clear();
		m_childPtrs.clear();
	}
//	{
//		MutexType::scoped_lock lock(amutex);
//		acount--;
//		cout << "object destruct! now count " << acount << endl;
//	}
}

void NMCSbdnObject::initialize(void)
{
}

void NMCSbdnObject::afterInitialize()
{
	BOOST_FOREACH(NMCSbdnObject *child, getChildSbdnObjects())
		{
			child->afterInitialize();
		}
}

bool NMCSbdnObject::isNode() const
{
	return m_isNode;
}

void NMCSbdnObject::setNode(bool isNode)
{
	m_isNode = isNode;
}

SbdnObject *NMCSbdnObject::upcast()
{
	return this;
}

const SbdnObject *NMCSbdnObject::upcast() const
{
	return this;
}

NMCSbdnObject *NMCSbdnObject::downcast(SbdnObject *base)
{
	if (base == NULL)
	{
		return NULL;
	}
	NMCSbdnObject *derive = static_cast<NMCSbdnObject *> (base);
	BOOST_ASSERT(dynamic_cast<NMCSbdnObject *>(derive));
	return derive;
}

void NMCSbdnObject::reconstructTreeID(const string &treeID)
{
	ID rootID(treeID);
	this->SetTreeID(rootID);

	const list<SbdnObject *> lstChild = this->GetChildSbdnObjects();
	list<SbdnObject *>::const_iterator itor = lstChild.begin();
	SbdnObject *child;
	for (; itor != lstChild.end(); ++itor)
	{
		child = *itor;
		ID childID = child->GetTreeID();
		const string &idStr = childID.GetID();
		string::size_type seperatorIndex = idStr.rfind(ID::IDSeparator);
		if (seperatorIndex == string::npos)
		{
			throw runtime_error("invalid child tree id: " + childID.GetID());
			continue;
		}
		string childIndex = idStr.substr(seperatorIndex + 1);
		downcast(child)->reconstructTreeID(treeID + ID::IDSeparator
				+ childIndex);
	}
}

void NMCSbdnObject::setValue(const PKU_SatLab_DBS_Common::Value &value)
{
	if (m_value.GetValueString() == value.GetValueString())
	{
		return;
	}
	if (m_signalEnabled)
	{
	valueWillBeChangedSignal();
	}
	SetValue(value);
	if (m_signalEnabled)
	{
		//DatabaseService::getInstance()->updateNode(this);//lamin add for update DB
		valueChangedSignal();
	}
}

void NMCSbdnObject::setValue(const string &valueStr)
{
	switch (m_value.GetType())
	{
		case E_Bool:
		{
			if (valueStr == "true")
			{
				setValue(Value(true));
			}
			else
			{
				setValue(Value(false));
			}
		}
		break;
		case E_Byte:
		{
			setValue(Value(valueStr.at(0)));
		}
		break;
		case E_Int:
		{
			setValue(Value(atoi(valueStr.c_str())));
		}
		break;
		case E_Long:
		{
			setValue(Value(((int64_t)atoll(valueStr.c_str()))));
		}
		break;
		case E_Double:
		{
			setValue(Value(atof(valueStr.c_str())));
		}
		break;
		case E_String:
		{
			setValue(Value(valueStr));
		}
		break;
		default:
		{
//			throw runtime_error(string("invalid data type") + __FILE__);
			return;
		}
		break;
	}
}

void NMCSbdnObject::setEnableSignal(bool enabled)
{
	m_signalEnabled = enabled;
	BOOST_FOREACH(SbdnObject *child ,m_childSbdnObjects)
				{
					NMCSbdnObject::downcast(child)->setEnableSignal(enabled);
				}
}

NMCSbdnObject *NMCSbdnObject::getParent() const
{
	return downcast(const_cast<SbdnObject *> (m_parentSbdnObject));
}

NMCSbdnObject *NMCSbdnObject::getFirstChildSbdnObject()
{
	if (m_childSbdnObjects.empty())
		return NULL;
	return NMCSbdnObject::downcast(m_childSbdnObjects.front());
}

const NMCSbdnObject *NMCSbdnObject::getFirstChildSbdnObject() const
{
	if (m_childSbdnObjects.empty())
	{
		return NULL;
	}
	return NMCSbdnObject::downcast(m_childSbdnObjects.front());
}

const string &NMCSbdnObject::getName() const
{
	return GetName();
}

const string &NMCSbdnObject::getPath() const
{
	return m_path;
}

bool NMCSbdnObject::hasChild(const string &name) const
{
	const SbdnObject *result = NULL;
	const list<SbdnObject *> childs = GetChildSbdnObjects();
	BOOST_FOREACH(const SbdnObject *child, childs)
				{
					if (child->GetName() == name)
					{
						result = child;
						break;
					}
				}
	return (result);
}

bool NMCSbdnObject::isUpdate() const
{
	return m_update;
}

int NMCSbdnObject::childSize() const
{
	return m_childSbdnObjects.size();
}

void NMCSbdnObject::updatePath()
{
	m_path = getParent()->getPath() + PATH_SEPERATOR + GetName();
	BOOST_FOREACH(SbdnObject *child, m_childSbdnObjects)
				{
					downcast(child)->updatePath();
				}
}

NMCSbdnObject *NMCSbdnObject::clone() const
{
	NMCSbdnObject *object = new NMCSbdnObject();
	copyTo(object);
	return object;
}

void NMCSbdnObject::cloneInit()
{
	BOOST_FOREACH(NMCSbdnObject *child, getChildSbdnObjects())
				{
					child->cloneInit();
				}
	initialize();
}

void NMCSbdnObject::copyTo(NMCSbdnObject *object) const
{
	object->m_childTreeIDIndex = m_childTreeIDIndex;
	object->m_path = m_path;
	object->m_update = m_update;
	object->m_signalEnabled = false;
	object->m_name = m_name;
//	object->m_treeID keep default
	object->m_classID = m_classID;
	object->m_objectID = *getNewObjectID(m_classID.GetID());
	object->m_value = m_value;
	object->m_parentSbdnObject = NULL;
	object->m_isNode = m_isNode;
	initObject(object);
	BOOST_FOREACH(NMCSbdnObject *child, getChildSbdnObjects())
				{
					object->addChildSbdnObject(ObjectPtr(child->clone()));
				}
}

void NMCSbdnObject::setName(const string &name)
{
	SetName(name);
}

void NMCSbdnObject::setTreeID(const string &id)
{
	SetTreeID(id);
}

void NMCSbdnObject::setUpdate(bool update)
{
	m_update = update;
}

const PKU_SatLab_DBS_Common::Value &NMCSbdnObject::getValue() const
{
	return m_value;
}

const PKU_SatLab_DBS_Common::ID &NMCSbdnObject::getObjectID() const
{
	return m_objectID;
}

const PKU_SatLab_DBS_Common::ID &NMCSbdnObject::getClassID() const
{
	return m_classID;
}

const PKU_SatLab_DBS_Common::ID &NMCSbdnObject::getTreeID() const
{
	return m_treeID;
}

void NMCSbdnObject::addChildSbdnObject(ObjectPtr child)
{
	const string &parentTreeID = m_treeID.GetID();
	string childParentTreeID = child->m_treeID.GetParentID();
	unsigned int newChildTreeIDIndex = 0;
	bool reconstructTreeID = !((parentTreeID == childParentTreeID)
			&& childParentTreeID != "");
	char idStr[19];
	child->SetParentSbdnObject(this);
	if (!reconstructTreeID)
	{
		const string &childTreeID = child->m_treeID.GetID();
		string childIndex = childTreeID.substr(parentTreeID.length() + 1);
		newChildTreeIDIndex = atoi(childIndex.c_str()) + 1;
	}
	{
		MutexType::scoped_lock lock(m_threadMutex);
		m_childSbdnObjects.push_back(child.get());
		m_childPtrs.push_back(child);
		if (reconstructTreeID)
		{
			snprintf(idStr, 19, "%d", m_childTreeIDIndex);
			m_childTreeIDIndex++;
		}
		else if (newChildTreeIDIndex > m_childTreeIDIndex)
		{
			m_childTreeIDIndex = newChildTreeIDIndex;
		}
	}
	if (reconstructTreeID)
	{
		child->reconstructTreeID(parentTreeID + '.' + idStr);
	}
	child->updatePath();
	if (child->m_signalEnabled)
	{
//		NMCSbdnObject::nodeAddSignal(child.get());
		child->nodeAddSignal();
	}
//	child->nodeAddSignal();
}

void NMCSbdnObject::removeChildSbdnObject(NMCSbdnObject *child)
{
	if (child->m_signalEnabled)
	{
		child->nodeRemovedSignal();
	}
	MutexType::scoped_lock lock(m_threadMutex);
	list<SbdnObject *>::iterator itor = m_childSbdnObjects.begin();
	list<SbdnObject *>::iterator end = m_childSbdnObjects.end();
	for (; itor != end; itor++)
	{
		if (*itor == child)
		{
			m_childSbdnObjects.erase(itor);
			m_childPtrs.remove(child->shared_from_this());
			return;
		}
	}
	throw runtime_error("name: " + m_name + "value: "
			+ m_value.GetValueString() + " has no child:" + " name: "
			+ child->m_name + "value: " + child->m_value.GetValueString());
}

void NMCSbdnObject::clearChild()
{
	MutexType::scoped_lock lock(m_threadMutex);
	m_childSbdnObjects.clear();
	m_childPtrs.clear();
}

NMCSbdnObject *NMCSbdnObject::getChildSbdnObject(const string &name)
{
	SbdnObject *result = GetChildSbdnObject(name);
	if (result == NULL)
	{
		throw runtime_error("can't find child: " + name + " from parent: "
				+ getPath());
	}
	return downcast(result);
}

int NMCSbdnObject::getChildSbdnObjects(const string &name,
		list<NMCSbdnObject *> &result) const
{
	int num = 0;
	BOOST_FOREACH(NMCSbdnObject *child, getChildSbdnObjects())
				{
					if (child->getName() == name)
					{
						num++;
						result.push_back(child);
					}
				}
	return num;
}

NMCSbdnObject *NMCSbdnObject::getChildSbdnObjectByNameBySeperator(
		const string &path, char seperator) const
{
	string firstPart;
	string leftPart = path;
	SbdnObject *result = const_cast<NMCSbdnObject *> (this);
	while (!leftPart.empty())
	{
		string::size_type index = leftPart.find(seperator);
		firstPart = leftPart.substr(0, index);
		if (index == string::npos)
		{
			leftPart.clear();
		}
		else
		{
			leftPart = leftPart.substr(index + 1);
		}
		result = result->GetChildSbdnObject(firstPart);
		if (result == NULL)
		{
			throw runtime_error("can't find given path: " + path + " from: "
					+ getPath());
		}
	}
	return NMCSbdnObject::downcast(result);
}

NMCSbdnObject *NMCSbdnObject::getChildSbdnObject(const string &name) const
{
	NMCSbdnObject *result =
			const_cast<NMCSbdnObject *> (this)->getChildSbdnObject(name);
	return result;
}

list<NMCSbdnObject *> NMCSbdnObject::getChildSbdnObjects() const
{
	MutexType::scoped_lock lock(const_cast<NMCSbdnObject *>(this)->m_threadMutex);
	list<SbdnObject *> childs = GetChildSbdnObjects();
	list<NMCSbdnObject *> nmcChilds;
	BOOST_FOREACH(SbdnObject *&child, childs)
				{
					nmcChilds.push_back(downcast(child));
				}
	return nmcChilds;
}

NMCSbdnObject::ObjectList NMCSbdnObject::getChildSbdnObjectPtrs() const
{
	MutexType::scoped_lock lock(const_cast<NMCSbdnObject *>(this)->m_threadMutex);
	return m_childPtrs;
}

NMCSbdnObject *NMCSbdnObject::getChildSbdnObjectByValue(const string &name,
		const string &value)
{
	SbdnObject *result = NULL;
	list<SbdnObject *> childs = GetChildSbdnObjects();
	BOOST_FOREACH(SbdnObject *&child, childs)
				{
					if(child==NULL)
					{
						continue;
					}
					if (child->GetName() == name
							&& child->GetValue().GetValueString() == value)
					{
						result = child;
						break;
					}
				}
	if (result != NULL)
	{
		return downcast(result);
	}
	return NULL;
}

NMCSbdnObject *NMCSbdnObject::getChildSbdnObjectByObjectID(
		const string &objectID) const
{
	SbdnObject *result = NULL;
	SbdnObject::GetFirstSbdnObjectItemByObjectID(this, objectID, result);
	if (result == NULL)
	{
		return NULL;
	}
	return downcast(result);
}

int NMCSbdnObject::getSbdnObjectItemsByName(const string &keyword, list<
		NMCSbdnObject *> &nmcResult)
{
	int num = 0;
	ObjectList childs = getChildSbdnObjectPtrs();
	BOOST_FOREACH(ObjectPtr child, childs)
				{
					const std::string &strName = child->GetName();
					if (strName == keyword)
					{
						nmcResult.push_back(child.get());
						num++;
					}
					num += child->getSbdnObjectItemsByName(keyword, nmcResult);
				}
	return num;
}

NMCSbdnObject *NMCSbdnObject::getFirstSbdnObjectByObjectID(
		const string &objectid) const
{
	if (m_objectID.GetID() == objectid)
	{
		return const_cast<NMCSbdnObject *> (this);
	}
	ObjectList childs = getChildSbdnObjectPtrs();
	NMCSbdnObject *result = NULL;
	BOOST_FOREACH(ObjectPtr child, childs)
				{
					result = child->getFirstSbdnObjectByObjectID(objectid);
					if (result != NULL)
					{
						return result;
					}
				}
	return NULL;
}

NMCSbdnObject *NMCSbdnObject::getFirstSbdnObjectItemByName(
		const string &keyword) const
{
	NMCSbdnObject *result = NULL;
	ObjectList childs = getChildSbdnObjectPtrs();
	BOOST_FOREACH(ObjectPtr child, childs)
				{
					const std::string &strName = child->GetName();
					if (strName == keyword)
					{
						return child.get();
					}
					result = child->getFirstSbdnObjectItemByName(keyword);
					if (result != NULL)
					{
						return result;
					}
				}
	return NULL;
}

NMCSbdnObject *NMCSbdnObject::getFirstSbdnObjectByNameValue(
		const string &keyword, const string &value)
{
	NMCSbdnObject *result = NULL;
	ObjectList childs = getChildSbdnObjectPtrs();
	BOOST_FOREACH(ObjectPtr child, childs)
				{
					const std::string &strName = child->GetName();
					const std::string &strValue =
							child->GetValue().GetValueString();
					if (strName == keyword && strValue == value)
					{
						return child.get();
					}
					result = child->getFirstSbdnObjectByNameValue(keyword,
							value);
					if (result != NULL)
					{
						return result;
					}
				}
	return NULL;
}

int NMCSbdnObject::getSbdnObjectItemsByNameValue(const string &keyword,
		const string &value, list<NMCSbdnObject *> &nmcResult)
{
	int num = 0;
	const list<NMCSbdnObject *> childs = getChildSbdnObjects();
	BOOST_FOREACH(NMCSbdnObject *child, childs)
				{
					const std::string &strName = child->GetName();
					const std::string &strValue =
							child->GetValue().GetValueString();
					if (strName == keyword && strValue == value)
					{
						nmcResult.push_back(child);
						num++;
					}
					num += child->getSbdnObjectItemsByNameValue(keyword, value,
							nmcResult);
				}
	return num;
}

NMCSbdnObject *NMCSbdnObject::searchFirstSbdnObjectItemByName(
		const string &keyword)
{
	const list<NMCSbdnObject *> childs = getChildSbdnObjects();
	NMCSbdnObject *result = NULL;
	BOOST_FOREACH(NMCSbdnObject *child, childs)
				{
					const std::string &strName = child->GetName();
					if (strName.find(keyword) != string::npos)
					{
						return child;
					}
					result = child->searchFirstSbdnObjectItemByName(keyword);
					if (result != NULL)
					{
						return result;
					}
				}
	return NULL;
}

int NMCSbdnObject::searchSbdnObjectItemsByName(const string &keyword, list<
		NMCSbdnObject *> &nmcResult)
{
	int num = 0;
	ObjectList childs = getChildSbdnObjectPtrs();
	BOOST_FOREACH(ObjectPtr child, childs)
				{
					const std::string &strName = child->GetName();
					if (strName.find(keyword) != string::npos)
					{
						nmcResult.push_back(child.get());
						num++;
					}
					num += child->searchSbdnObjectItemsByName(keyword,
							nmcResult);
				}
	return num;
}

void NMCSbdnObject::synFrom(NMCSbdnObject *, int)
{

}

bool NMCSbdnObject::synByValue(NMCSbdnObject *src)
{
	synValue(src->getValue());
	BOOST_FOREACH(NMCSbdnObject *child, src->getChildSbdnObjects())
				{
					//					NMCSbdnObject *target =
					//							getChildSbdnObjectByValue(child->getName(), child->getValue().GetValueString());
					NMCSbdnObject *target =
							getChildSbdnObject(child->getName());
					if (!target || !target->synByValue(child))
					{
						return false;
					}
				}
	return true;
}

void NMCSbdnObject::synByValue(NMCSbdnObject *src, SynHandlerType handler)
{
	bool result = synByValue(src);
	handler(result);
}

void NMCSbdnObject::queryValue(NMCSbdnObject *, SynHandlerType handler)
{
	handler(true);
}

void NMCSbdnObject::synValue(const PKU_SatLab_DBS_Common::Value &value)
{
	if (m_value.GetValueString() == value.GetValueString())
	{
		return;
	}
	if (value.GetType() != E_String)
	{
		setValue(value);
		return;
	}
	string strValue = value.GetValueString();
	switch (m_value.GetType())
	{
		case E_Bool:
		{
			bool value = false;
			if (strValue == "true")
			{
				value = true;
			}
			setValue(PKU_SatLab_DBS_Common::Value(value));
			break;
		}
		case E_Byte:
		{
			byte value = (byte) atoi(strValue.c_str());
			setValue(PKU_SatLab_DBS_Common::Value(value));
		}
		break;
		case E_Int:
		{
			int value = atoi(strValue.c_str());
			setValue(PKU_SatLab_DBS_Common::Value(value));
		}
		break;
		case E_Long:
		{
			int64_t value = atoll(strValue.c_str());
			setValue(PKU_SatLab_DBS_Common::Value(value));
		}
		break;
		case E_Double:
		{
			double value = atof(strValue.c_str());
			setValue(PKU_SatLab_DBS_Common::Value(value));
		}
		break;
		case E_String:
		{
			setValue(PKU_SatLab_DBS_Common::Value(strValue));
			break;
		}
		default:
			throw runtime_error("unexpected value type!");
		break;
	}
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
