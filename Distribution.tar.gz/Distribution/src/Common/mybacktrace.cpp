/*
 * regristsignal.cpp
 *
 *  Created on: 2018-11-21
 *      Author: nmc
 */

#include "mybacktrace.h"

#include <signal.h>
#include <execinfo.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

char my_runprogram[20]="\0";


void sigroutine(int sinno) {
	void *array[100];
	size_t size;
	char **sstrings;
	size_t ii;
	size = backtrace(array, 100);
	sstrings = backtrace_symbols(array, size);
	struct tm *tmm;
	time_t tv_now;
	time(&tv_now);
	tmm = localtime(&tv_now);
	char filename[100];
	sprintf(filename,"%s_RunError%d%02d%02d%02d%02d%02d.txt", my_runprogram, 1900+tmm->tm_year,tmm->tm_mon+1,tmm->tm_mday,tmm->tm_hour,tmm->tm_min,tmm->tm_sec);

	FILE *fp;
	if ((fp=fopen(filename,"a")) == NULL) {
		printf("cannt open a error file: %s\n", filename);
	}else {
		if (sinno == SIGABRT)
			fprintf(fp,"==============>> CATCH SIGNAL SIGABRT(%d)  <<=============\n",SIGABRT);
		else
			fprintf(fp,"==============>> CATCH SIGNAL SIGSEGV(%d)  <<=============\n",sinno);

		fprintf(fp,"backtrace returned %d  addresses\n",size);
		for (ii=0;ii<size;ii++) {
			fprintf(fp,"[%d]  %s\n",ii, sstrings[ii]);
		}
		fclose(fp);
	}
	free(sstrings);
	exit(-1);
}

void regristsingnal()
{
	signal(SIGSEGV, sigroutine);
	signal(SIGABRT, sigroutine);
}
