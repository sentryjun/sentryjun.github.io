#ifndef ENUM_H
#define ENUM_H

#include <string>
#include <stdexcept>
using namespace std;

typedef string EnumNameType;

template <typename EnumType>
struct EnumName
{
	static const EnumNameType list[];
	static const int listNum;
};

template <size_t N>
int getListNum(const EnumNameType (&list)[N])
{
	return N;
}

template <typename EnumType>
EnumType strToEnum(const EnumNameType &name)
{
	int num = EnumName<EnumType>::listNum;
	for (int i = 0; i < num; i ++)
	{
		if (EnumName<EnumType>::list[i] == name)
		{
			return static_cast<EnumType>(i);
		}
	}
	throw std::runtime_error("unknown enum name: " + name);
	return EnumType();
}

template <typename EnumType>
const string enumToStr(const int index)
{
	if (index < 0 || index >= EnumName<EnumType>::listNum)
	{
		throw out_of_range("invalid enum index");
	}
	return EnumName<EnumType>::list[index];
}

#endif // ENUM_H
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
