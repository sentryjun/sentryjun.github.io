/*
 * regristsignal.h
 *
 *  Created on: 2018-11-21
 *      Author: nmc
 */

#ifndef REGRISTSIGNAL_H_
#define REGRISTSIGNAL_H_

void regristsingnal();

#endif /* REGRISTSIGNAL_H_ */
