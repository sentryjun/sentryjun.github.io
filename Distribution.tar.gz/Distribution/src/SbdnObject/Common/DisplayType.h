#pragma once

namespace PKU_SatLab_DBS_Common
{
	enum DisplayType
	{
		E_InvalidDisplayType,
		E_Display_Text,
		E_Display_Icon,
		E_Display_Map,
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
