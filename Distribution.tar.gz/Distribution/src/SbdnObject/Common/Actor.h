// Actor.h: Class of the actors in Sbdn
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACTOR_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_ACTOR_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#include "SbdnObject.h"

namespace PKU_SatLab_DBS_Common
{
	class Actor : public SbdnObject  
	{
	public:
		Actor(void);
		Actor(string name, string treeID, string objectID);
		Actor(const SbdnObject &source);
		virtual ~Actor(void);

		bool Initialize(void);
	protected:
		Actor(string name, string treeID, string classID, string objectID);
	private:
		string m_ActorDescription;

	};
}

#endif // !defined(AFX_ACTOR_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
