// Administrator.h: Class of the administrator in Sbdn
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADMINISTRATOR_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_ADMINISTRATOR_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Actor.h"

namespace PKU_SatLab_DBS_Common
{
	class Administrator : public Actor  
	{
	public:
		Administrator(void);
		Administrator(string name, string treeID, string objectID);
		Administrator(const SbdnObject &source);
		virtual ~Administrator(void);

		bool Initialize(void);
	protected:
		Administrator(string name, string treeID, string classID, string objectID);
	private:
		string m_AdministratorDescription;

	};
}

#endif // !defined(AFX_ADMINISTRATOR_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
