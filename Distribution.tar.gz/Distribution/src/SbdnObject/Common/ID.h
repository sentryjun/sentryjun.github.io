#pragma once
#include "CommonSettings.h"

#include <sstream>

using namespace std;

namespace PKU_SatLab_DBS_Common
{
	class ID
	{
	public:
//		enum
//		{
//			MAX_ID_LEVEL = 64
//		};

		ID(void);
		ID(const string &id);
//		ID(const uint id[MAX_ID_LEVEL]);
		virtual ~ID(void);

		const string &GetID() const;
		void GetID(string &) const;
		string GetParentID() const;
		bool operator == (const ID &lhs) const;
		template <typename AppendType>
		ID operator << (const AppendType &ap) const
		{
			ostringstream ostr(m_id);
			ostr << ID::IDSeparator << ap;
			return ID(ostr.str());
		}

//		string GetID() const;
//		void GetID(string &id) const;
//		void GetID(uint id[MAX_ID_LEVEL]) const;
//
//		void SetID (const string &id);
//		void SetID (const uint id[MAX_ID_LEVEL]);
//
//		string GetParentID() const;
//		void GetParentID(string &pid) const;
//		void GetParentID(uint pid[MAX_ID_LEVEL]) const;
//
//		uint GetLevel(void) const;
//
//		bool IsSubID(const ID &id) const;
//		bool IsSubID(const uint id[MAX_ID_LEVEL]) const;
//		bool IsSubID(const string &strID) const;

//		bool operator == (const ID &source) const;

		static const char IDSeparator;

	protected:
//		uint m_data[MAX_ID_LEVEL];
//		uint m_level;

//		uint ComputeLevel(const uint id[MAX_ID_LEVEL]) const;
		string m_id;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
