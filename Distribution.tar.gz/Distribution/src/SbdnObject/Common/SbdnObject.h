// SbdnObject.h: Base class of SbdnObject tree.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "ID.h"
#include "Value.h"
#include "DisplayType.h"
#include "ISecurityInterface.h"
#include "ISerializeInterface.h"
#include "IDBInterface.h"
#include "IDisplayInterface.h"
#include "ILogInterface.h"
#include "IMonitorInterface.h"

namespace PKU_SatLab_DBS_Common
{
	class SbdnObject // : public ISecurityInterface, public ISerializeInterface, public IDbInterface, public IDisplayInterface, public ILogInterface, public IMonitorInterface
	{
	public:
		SbdnObject(void);
		SbdnObject(string name, string treeID, string objectID);
		SbdnObject(string name, string treeID, string classID, string objectID);
		SbdnObject(const SbdnObject &source);
		virtual ~SbdnObject(void);

		virtual bool Initialize(void);

		static int GetSbdnObjectItemsByName(const SbdnObject* pSbdnObject, const string keyword, list<SbdnObject *>& result);
		static int SearchSbdnObjectItemsByName(const SbdnObject* pSbdnObject, const string keyword, list<SbdnObject *>& result);
		static int GetFirstSbdnObjectItemByName(const SbdnObject* pSbdnObject, const string keyword, SbdnObject* &result);
		static int SearchFirstSbdnObjectItemByName(const SbdnObject* pSbdnObject, const string keyword, SbdnObject* &result);

		static int GetSbdnObjectItemsByObjectID(const SbdnObject* pSbdnObject, const ID objectid, list<SbdnObject *>& result);
		static int GetSbdnObjectReferencesByObjectID(const SbdnObject* pSbdnObject, const ID objectid, list<SbdnObject *>& result);
		static int GetFirstSbdnObjectItemByObjectID(const SbdnObject* pSbdnObject, const ID objectid, SbdnObject* &result);
		static int GetFirstSbdnObjectReferenceByObjectID(const SbdnObject* pSbdnObject, const ID objectid, SbdnObject* &result);

//		static int GetFirstSbdnObjectItemByTreeID(const SbdnObject* pSbdnObject, const ID treeid, SbdnObject* &result);

		static void ReconstructTreeID(SbdnObject* pSbdnObject, const ID rootID);
		static void ReconstructTreeID(SbdnObject* pSbdnObject, const string strRootID);

		virtual const string& GetName () const;
		virtual void SetName(const string &name);

		virtual ID GetTreeID () const;
		virtual void SetTreeID (const ID &id);

		virtual ID GetClassID () const;
		virtual void SetClassID (const ID &id);

		virtual ID GetObjectID () const;
		virtual void SetObjectID (const ID &id);

//		virtual SbdnObject* GetParentByTreeID(SbdnObject* pRootSbdnObject);

		virtual void SetParentSbdnObject(SbdnObject* pSbdnObject);
		virtual SbdnObject* GetParentSbdnObject();

		virtual list<SbdnObject *>& GetChildSbdnObjects ();
		virtual const list<SbdnObject *>& GetChildSbdnObjects () const;
		virtual bool SetChildSbdnObjects (list<SbdnObject *> &childSbdnObjects);
		virtual bool AddChildSbdnObject (SbdnObject *pSbdnObject);
		virtual bool RemoveChildSbdnObject (SbdnObject *pSbdnObject);
		virtual bool DeleteChildSbdnObject (SbdnObject *&pSbdnObject);
		virtual void ClearChildSbdnObjects();

		virtual Value& GetValue();
		virtual const Value& GetValue() const;
		virtual void SetValue(const Value &value);

		virtual SbdnObject& operator = (const SbdnObject &source);

		virtual void ClearContent();

		virtual void Dump(uint indent = 2) const;
		virtual void Dump(const SbdnObject *pSbdnObject, uint level, uint indent = 2) const;


		virtual SbdnObject* GetFirstObjectByNameFromThis(const string name);
		virtual SbdnObject* GetFirstObjectByNameValueFromThis(const string name, const string value);
		virtual SbdnObject* GetFirstObjectByObjectIDFromThis(const string objectid);
		virtual SbdnObject* GetChildSbdnObject(const string name, bool nullable = false);
	protected:

		string m_name;
		ID m_treeID;
		ID m_classID;
		ID m_objectID;

		Value m_value;
		string m_iconResource;
		list <SbdnObject *> m_childSbdnObjects;
		SbdnObject * m_parentSbdnObject;

		enum
		{
			MAX_INDENT = 16,
		};
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
