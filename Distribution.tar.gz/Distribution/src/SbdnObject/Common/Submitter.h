// Submitter.h: Class of the actors in Sbdn
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SUBMITTER_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_SUBMITTER_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Actor.h"

namespace PKU_SatLab_DBS_Common
{
	class Submitter : public Actor  
	{
	public:
		Submitter(void);
		Submitter(string name, string treeID, string objectID);
		Submitter(const SbdnObject &source);
		virtual ~Submitter(void);
		bool Initialize(void);

	protected:
		Submitter(string name, string treeID, string classID, string objectID);
	private:
		string m_SubmitterDescription;

	};
}

#endif // !defined(AFX_SUBMITTER_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
