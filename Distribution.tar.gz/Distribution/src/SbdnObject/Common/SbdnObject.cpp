#include "CommonSettings.h"
#include "SbdnObject.h"

using namespace PKU_SatLab_DBS_Common;

#ifdef _DEBUG
int g_nSbdnObjectCount=0;
#endif

SbdnObject::SbdnObject(void)
{
#ifdef _DEBUG
    ++g_nSbdnObjectCount;
#endif
}

SbdnObject::~SbdnObject(void)
{
	ClearContent();
#ifdef _DEBUG
    --g_nSbdnObjectCount;
#endif
}

SbdnObject::SbdnObject(string name, string treeID, string classID, string objectID)
: m_name (name)
, m_treeID (treeID)
, m_classID (classID)
, m_objectID (objectID)
{
#ifdef _DEBUG
    ++g_nSbdnObjectCount;
#endif

}

SbdnObject::SbdnObject(string name, string treeID, string objectID)
: m_name (name)
, m_treeID (treeID)
, m_classID (SBDNOBJECTID)
, m_objectID (objectID)
{
#ifdef _DEBUG
	++g_nSbdnObjectCount;
#endif

}

SbdnObject::SbdnObject(const SbdnObject &source)
{
#ifdef _DEBUG
    ++g_nSbdnObjectCount;
#endif

	ClearContent();

	m_name = source.m_name;
	m_classID = source.m_classID;
	m_treeID = source.m_treeID;
	m_objectID = source.m_objectID;
	m_value = source.m_value;
	m_iconResource = source.m_iconResource;

	SetParentSbdnObject(source.m_parentSbdnObject);

	list<SbdnObject*>::const_iterator itor = source.GetChildSbdnObjects().begin();
	while(itor != source.m_childSbdnObjects.end())
	{
		m_childSbdnObjects.push_back(new SbdnObject(*(*itor)));
		itor ++;
	}
}

bool SbdnObject::Initialize(void)
{
	return false;
}

void SbdnObject::ClearContent()
{
	ClearChildSbdnObjects();
}

void SbdnObject::ClearChildSbdnObjects()
{
	list<SbdnObject*>::iterator itor = m_childSbdnObjects.begin();
	while(itor != m_childSbdnObjects.end())
	{
		SbdnObject *pSbdnObject = *itor;
		delete pSbdnObject;
		itor ++;
	}
	m_childSbdnObjects.clear();
}

SbdnObject& SbdnObject::operator = (const SbdnObject &source)
{
	if(&source == this)
	{
		return *this;
	}

	ClearContent();

	m_name = source.m_name;
	m_treeID = source.m_treeID;
	m_classID = source.m_classID;
	m_objectID = source.m_objectID;
	m_value = source.m_value;
	m_iconResource = source.m_iconResource;

	SetParentSbdnObject(source.m_parentSbdnObject);

	list<SbdnObject*>::const_iterator itor = source.GetChildSbdnObjects().begin();
	while(itor != source.m_childSbdnObjects.end())
	{
		m_childSbdnObjects.push_back(new SbdnObject(*(*itor)));
		itor ++;
	}
	return *this;
}

const string& SbdnObject::GetName () const
{
	return m_name;
}

void SbdnObject::SetName(const string &name)
{
	m_name = name;
}

ID SbdnObject::GetTreeID () const
{
	return m_treeID;
}

void SbdnObject::SetTreeID(const ID &treeID)
{
	m_treeID = treeID;
}

ID SbdnObject::GetClassID () const
{
	return m_classID;
}

void SbdnObject::SetClassID(const ID &classID)
{
	m_classID = classID;
}

ID SbdnObject::GetObjectID () const
{
	return m_objectID;
}


void SbdnObject::SetObjectID(const ID &objectID)
{
	m_objectID = objectID;
}

list<SbdnObject *>& SbdnObject::GetChildSbdnObjects ()
{
	return m_childSbdnObjects;
}

SbdnObject* SbdnObject::GetChildSbdnObject(const string name, bool nullable /*= false*/) {
	list<SbdnObject*>::const_iterator itor;
	for(itor = m_childSbdnObjects.begin(); itor != m_childSbdnObjects.end(); itor++){
		if((*itor)->GetName() == name)
			return (*itor);
	}
	return NULL;
}

const list<SbdnObject *>& SbdnObject::GetChildSbdnObjects () const
{
	return m_childSbdnObjects;
}

bool SbdnObject::SetChildSbdnObjects (list<SbdnObject *> &childSbdnObjects)
{
	// remove old child SbdnObjects
	ClearChildSbdnObjects();

	// copy new child SbdnObjects
	list<SbdnObject*>::const_iterator itor = childSbdnObjects.begin();
	while(itor != childSbdnObjects.end())
	{
		SbdnObject *pObj = *itor;
		pObj->SetParentSbdnObject(this);
		m_childSbdnObjects.push_back(new SbdnObject(*(pObj)));
		itor ++;
	}
	return true;
}

bool SbdnObject::AddChildSbdnObject (SbdnObject *pSbdnObject)
{
	if(pSbdnObject == NULL)
		return false;

	pSbdnObject->SetParentSbdnObject(this);
	m_childSbdnObjects.push_back((SbdnObject *)pSbdnObject);
	return true;
}

bool SbdnObject::RemoveChildSbdnObject (SbdnObject *pSbdnObject)
{
	if(pSbdnObject == NULL)
		return false;

	bool result = false;
	list<SbdnObject*>::iterator itor = m_childSbdnObjects.begin();
	while(itor != m_childSbdnObjects.end())
	{
		if(*itor == pSbdnObject)
		{
			pSbdnObject->SetParentSbdnObject(NULL);
			m_childSbdnObjects.erase(itor);
			result = true;
			break;
		}
		itor ++;
	}
	return result;
}

bool SbdnObject::DeleteChildSbdnObject(SbdnObject *&pSbdnObject)
{
	if(pSbdnObject == NULL)
		return false;

	bool result = false;
	list<SbdnObject*>::iterator itor = m_childSbdnObjects.begin();
	while(itor != m_childSbdnObjects.end())
	{
		if(*itor == pSbdnObject)
		{
			m_childSbdnObjects.erase(itor);
			delete pSbdnObject;
			result = true;
			break;
		}
		itor ++;
	}
	return result;
}

void SbdnObject::SetParentSbdnObject(SbdnObject* pSbdnObject)
{
	m_parentSbdnObject = pSbdnObject;
	return;
}

SbdnObject* SbdnObject::GetParentSbdnObject()
{
	return m_parentSbdnObject;
}

void SbdnObject::Dump(uint indent/* = 2 */) const
{
	if(indent < 0)
	{
		indent = 0;
	}
	if(indent > MAX_INDENT)
	{
		indent = MAX_INDENT;
	}
	Dump(this, 0, indent);
}

void SbdnObject::Dump(const SbdnObject *pObject, uint level, uint indent/* = 2 */) const
{
	// Dump indent
	for(uint i=0; i<(level * indent); i ++)
	{
		cout<<" ";
	}

	// Dump content
	string treeID;
	string classID;
	string objectID;

	pObject->GetTreeID().GetID(treeID);
	pObject->GetClassID().GetID(classID);
	pObject->GetObjectID().GetID(objectID);
	cout<<"name:\""<<pObject->m_name.c_str()<<"\" treeid:\""<<treeID.c_str()<<"\" classid:\""<<classID.c_str()<<"\" objectid:\""<<objectID.c_str()<<"\""<<endl;

	// Dump children
	list<SbdnObject *>::const_iterator itor = pObject->m_childSbdnObjects.begin();
	while(itor != pObject->m_childSbdnObjects.end())
	{
		Dump(*itor, level+1, indent);
		itor ++;
	}
}


Value& SbdnObject::GetValue()
{
	return m_value;
}

const Value& SbdnObject::GetValue() const
{
	return m_value;
}

void SbdnObject::SetValue(const Value &value)
{
	m_value = value;
}

int SbdnObject::GetSbdnObjectItemsByName(const SbdnObject* pSbdnObject, const string keyword, list<SbdnObject *>& result)
{
	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();
	int nRet = 0;

	std::string strVal;
	for	( ; li != lstChild.end() ; ++li )
	{
		SbdnObject* pPara = *li;
		const std::string &strName = pPara->GetName();

		if( strName ==  keyword )
		{
			result.push_back((SbdnObject *) pPara);
			nRet++;
		}
		else
		{
			nRet += GetSbdnObjectItemsByName(pPara, keyword, result);
		}
	}
	return nRet;
}

int SbdnObject::SearchSbdnObjectItemsByName(const SbdnObject* pSbdnObject, const string keyword, list<SbdnObject *>& result)
{
	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();
	int nRet = 0;

	std::string strVal;
	for	( ; li != lstChild.end() ; ++li )
	{
		SbdnObject* pPara = *li;
		const std::string &strName = pPara->GetName();

		if( strName.find(keyword) != string::npos )
		{
			result.push_back((SbdnObject *) pPara);
			nRet++;
		}
		else
		{
			nRet += SearchSbdnObjectItemsByName(pPara, keyword, result);
		}
	}
	return nRet;
}

int SbdnObject::GetFirstSbdnObjectItemByName(const SbdnObject* pSbdnObject, const string keyword, SbdnObject* &result)
{
	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();
	int nRet = 0;

	std::string strVal;
	for	( ; li != lstChild.end() ; ++li )
	{
		SbdnObject* pPara = *li;
		const std::string &strName = pPara->GetName();

		if( strName ==  keyword )
		{
			result = pPara;
			nRet++;
			return nRet;
		}
		else
		{
			nRet += GetFirstSbdnObjectItemByName(pPara, keyword, result);
		}
	}
	return nRet;
}

int SbdnObject::SearchFirstSbdnObjectItemByName(const SbdnObject* pSbdnObject, const string keyword, SbdnObject* &result)
{
	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();
	int nRet = 0;

	std::string strVal;
	for	( ; li != lstChild.end() ; ++li )
	{
		SbdnObject* pPara = *li;
		const std::string &strName = pPara->GetName();

		if( strName.find(keyword) != string::npos )
		{
			result = pPara;
			nRet++;
			return nRet;
		}
		else
		{
			nRet += SearchFirstSbdnObjectItemByName(pPara, keyword, result);
		}
	}
	return nRet;
}

int SbdnObject::GetSbdnObjectItemsByObjectID(const SbdnObject* pSbdnObject, const ID objectid, list<SbdnObject *>& result)
{
	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();
	int nRet = 0;

	std::string strVal;
	for	( ; li != lstChild.end() ; ++li )
	{
		SbdnObject* pPara = *li;
		const ID oid = pPara->GetObjectID();
		const ID cid = pPara->GetClassID();
		string strClassID = "";
		cid.GetID(strClassID);

		if(( oid == objectid ) && (strClassID != SBDNREFERENCEID))
		{
			result.push_back((SbdnObject *) pPara);
			nRet++;
		}
		else
		{
			nRet += GetSbdnObjectItemsByObjectID(pPara, objectid, result);
		}
	}
	return nRet;
}

int SbdnObject::GetSbdnObjectReferencesByObjectID(const SbdnObject* pSbdnObject, const ID objectid, list<SbdnObject *>& result)
{
	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();
	int nRet = 0;

	std::string strVal;
	for	( ; li != lstChild.end() ; ++li )
	{
		SbdnObject* pPara = *li;
		const ID oid = pPara->GetObjectID();
		const ID cid = pPara->GetClassID();
		string strClassID = "";
		cid.GetID(strClassID);

		if(( oid == objectid ) && (strClassID == SBDNREFERENCEID))
		{
			result.push_back((SbdnObject *) pPara);
			nRet++;
		}
		else
		{
			nRet += GetSbdnObjectReferencesByObjectID(pPara, objectid, result);
		}
	}
	return nRet;
}

int SbdnObject::GetFirstSbdnObjectItemByObjectID(const SbdnObject* pSbdnObject, const ID objectid, SbdnObject* &result)
{
	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();
	int nRet = 0;

	std::string strVal;
	for	( ; li != lstChild.end() ; ++li )
	{
		SbdnObject* pPara = *li;
		const ID oid = pPara->GetObjectID();
		const ID cid = pPara->GetClassID();
		string strClassID = "";
		cid.GetID(strClassID);

		if(( oid == objectid ) && (strClassID != SBDNREFERENCEID))
		{
			result = pPara;
			nRet++;
			return nRet;
		}
		else
		{
			nRet += GetFirstSbdnObjectItemByObjectID(pPara, objectid, result);
		}
	}
	return nRet;
}

int SbdnObject::GetFirstSbdnObjectReferenceByObjectID(const SbdnObject* pSbdnObject, const ID objectid, SbdnObject* &result)
{
	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();
	int nRet = 0;

	std::string strVal;
	for	( ; li != lstChild.end() ; ++li )
	{
		SbdnObject* pPara = *li;
		const ID oid = pPara->GetObjectID();
		const ID cid = pPara->GetClassID();
		string strClassID = "";
		cid.GetID(strClassID);

		if(( oid == objectid ) && (strClassID == SBDNREFERENCEID))
		{
			result = pPara;
			nRet++;
			return nRet;
		}
		else
		{
			nRet += GetFirstSbdnObjectReferenceByObjectID(pPara, objectid, result);
		}
	}
	return nRet;
}

void SbdnObject::ReconstructTreeID(SbdnObject* pSbdnObject, const ID rootID)
{
	int nSeq = 0;

	pSbdnObject->SetTreeID(rootID);

	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();

	for	( ; li != lstChild.end() ; ++li )
	{
		nSeq++;
		SbdnObject* pPara = *li;
		ReconstructTreeID(pPara, rootID << nSeq);
	}
	return;
}


void SbdnObject::ReconstructTreeID(SbdnObject* pSbdnObject, const string strRootID)
{
	int nSeq = 0;
	ID rootID = ID(strRootID);

	pSbdnObject->SetTreeID(rootID);

	const list<SbdnObject* > lstChild = pSbdnObject->GetChildSbdnObjects();
	list<SbdnObject* >::const_iterator li = lstChild.begin();

	for	( ; li != lstChild.end() ; ++li )
	{
		nSeq++;

		SbdnObject* pPara = *li;

		ReconstructTreeID(pPara, rootID << nSeq);
	}
	return;
}

SbdnObject* SbdnObject::GetFirstObjectByNameFromThis(const string name) {
	SbdnObject *res;
	if(GetFirstSbdnObjectItemByName(this, name, res) < 1)
		return NULL;
	return res;
}

SbdnObject* SbdnObject::GetFirstObjectByObjectIDFromThis(const string objectid) {
	SbdnObject *res;
	if(GetFirstSbdnObjectItemByObjectID(this, objectid, res) < 1)
		return NULL;
	return res;
}

SbdnObject* SbdnObject::GetFirstObjectByNameValueFromThis(const string name, const string value) {
	list<SbdnObject*> res;
	if(GetSbdnObjectItemsByName(this, name, res) < 1)
		return NULL;
	list<SbdnObject*>::const_iterator itor;
	for(itor = res.begin(); itor != res.end(); itor++) {
		if((*itor)->GetValue().GetValueString() == value)
			return *itor;
	}
	return NULL;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
