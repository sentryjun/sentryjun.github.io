#include "CommonSettings.h"
#include "Administrator.h"

using namespace PKU_SatLab_DBS_Common;

Administrator::Administrator(void) {
}

Administrator::~Administrator(void)
{
//	Actor::~Actor();
}

Administrator::Administrator(string name, string treeID, string objectID)
:Actor(name, treeID, SBDNADMINISTRATORID, objectID){
}

Administrator::Administrator(string name, string treeID, string classID, string objectID)
:Actor(name, treeID, classID, objectID){
}

Administrator::Administrator(const SbdnObject &source) : Actor(source)
{
//	Actor::Actor(source);
}

bool Administrator::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
