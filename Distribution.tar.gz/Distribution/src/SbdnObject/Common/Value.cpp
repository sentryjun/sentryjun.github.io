#include "CommonSettings.h"
#include "Value.h"
#include "string.h"
#include <sstream>

using namespace std;
using namespace PKU_SatLab_DBS_Common;

Value::Value(void)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
}

Value::Value(const string strtype, const string value)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	ValueType type = PKU_SatLab_DBS_Common::E_InvalidValueType;
	if (strtype == "class")
	{
		type = PKU_SatLab_DBS_Common::E_Class;
	}
	if (strtype == "bool")
	{
		type = PKU_SatLab_DBS_Common::E_Bool;
	}
	if (strtype == "byte")
	{
		type = PKU_SatLab_DBS_Common::E_Byte;
	}
	if (strtype == "int")
	{
		type = PKU_SatLab_DBS_Common::E_Int;
	}
	if (strtype == "long")
	{
		type = PKU_SatLab_DBS_Common::E_Long;
	}
	if (strtype == "double")
	{
		type = PKU_SatLab_DBS_Common::E_Double;
	}
	if (strtype == "string")
	{
		type = PKU_SatLab_DBS_Common::E_String;
	}
	SetValue(type, value);
}

Value::Value(const ValueType type, const string value)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(type, value);
}

Value::Value(const int& valueData)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(static_cast<int> (valueData));
}

Value::Value(const bool &valueData)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(static_cast<bool> (valueData));
}

Value::Value(const byte &valueData)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(static_cast<byte> (valueData));
}

Value::Value(const int64_t &valueData)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(static_cast<int64_t> (valueData));
}

Value::Value(const double &valueData)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(static_cast<double> (valueData));
}

Value::Value(const char *&pValueData)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(const_cast<char*> (pValueData));
}

Value::Value(const char pValueData[])
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(const_cast<char*> (pValueData));
}

Value::Value(const string &valueData)
{
	m_type = E_InvalidValueType;
	memset((void*) &m_data, 0, sizeof(ValueData));
	SetValue(valueData);
}

Value::Value(const Value &value)
{
	m_type = value.m_type;
	m_range = value.m_range;
	m_data = value.m_data;
	if (m_type == E_String)
	{
		size_t length = strlen(value.m_data.m_pStringData);
		m_data.m_pStringData = new char[length + 1];
		memset(m_data.m_pStringData, 0, sizeof(char) * (length + 1));
		strncpy(m_data.m_pStringData, value.m_data.m_pStringData, length);
	}
}

//bool Value::SetValue(const string type, const string value) {
//	if (type == "class") {
//		m_type = PKU_SatLab_DBS_Common::E_Class;
//		return true;
//	}
//
//	if (type == "bool") {
//		m_type = PKU_SatLab_DBS_Common::E_Bool;
//		if (value == "true") {
//			SetValue(true);
//		}
//		if (value == "false") {
//			SetValue(false);
//		}
//		return true;
//	}
//
//	if (type == "byte") {
//		m_type = PKU_SatLab_DBS_Common::E_Byte;
//		if (value != "") {
//			SetValue((byte)atoi(value.c_str()));
//		}
//		return true;
//	}
//
//	if (type == "int") {
//		m_type = PKU_SatLab_DBS_Common::E_Int;
//		if (value != "") {
//			SetValue((int)atoi(value.c_str()));
//		}
//		return true;
//	}
//
//	if (type == "long") {
//		m_type = PKU_SatLab_DBS_Common::E_Long;
//		if (value != "") {
//			SetValue((int64_t)(atoll(value.c_str())));
//		}
//		return true;
//	}
//
//	if (type == "double") {
//		m_type = PKU_SatLab_DBS_Common::E_Double;
//		if (value != "") {
//			SetValue((double)atof(value.c_str()));
//		}
//		return true;
//	}
//
//	if (type == "string") {
//		m_type = PKU_SatLab_DBS_Common::E_String;
//		if (value != "") {
//			SetValue(value);
//		}
//		return true;
//	}
//	return false;
//}

bool Value::SetValue(const ValueType type, const string value)
{
	switch (type)
	{
		case E_Class:
			m_type = PKU_SatLab_DBS_Common::E_Class;
			return true;
		case E_Bool:
			m_type = PKU_SatLab_DBS_Common::E_Bool;
			if (value == "true")
			{
				SetValue(true);
				return true;
			}
			if (value == "false")
			{
				SetValue(false);
				return true;
			}
			return false;
		case E_Byte:
			m_type = PKU_SatLab_DBS_Common::E_Byte;
			if (value != "")
			{
				SetValue(static_cast<byte> (atoi(value.c_str())));
			}
			return true;
		case E_Int:
			m_type = PKU_SatLab_DBS_Common::E_Int;
			if (value != "")
			{
				SetValue(static_cast<int> (atoi(value.c_str())));
			}
			return true;
		case E_Long:
			m_type = PKU_SatLab_DBS_Common::E_Long;
			if (value != "")
			{
				SetValue(static_cast<int64_t> ((atoll(value.c_str()))));
			}
			return true;
		case E_Double:
			m_type = PKU_SatLab_DBS_Common::E_Double;
			if (value != "")
			{
				SetValue(static_cast<double> (atof(value.c_str())));
			}
			return true;
		case E_String:
			m_type = PKU_SatLab_DBS_Common::E_String;
			if (value != "")
			{
				SetValue(value);
			}
			return true;
		default:
		break;
	}
	return false;
}

bool Value::SetValue(const Value &value)
{
	if (&value == this)
		return true;
	return SetValue(value.GetType(), value.GetValueString());
}

Value::~Value(void)
{
	// delete string value
	if (m_type == E_String)
	{
		delete[] m_data.m_pStringData;
		m_data.m_pStringData = NULL;
	}
}

ValueType Value::GetType() const
{
	return m_type;
}

string Value::GetTypeName() const
{
	string typeName;

	if (m_type >= 0 && m_type <= 6)
	{
		typeName = ValueTypeNames[m_type];
	}

	return typeName;
}

void Value::SetType(ValueType type)
{
	m_type = type;
}

ValueRange Value::GetRange(void) const
{
	return m_range;
}

void Value::SetRange(const ValueRange &range)
{
	m_range = range;
}

bool Value::GetValue(bool &value) const
{
	if (m_type == E_Bool)
	{
		value = m_data.m_boolData;
		return true;
	}

	return false;
}

bool Value::SetValue(const bool &value)
{
	m_data.m_boolData = value;
	m_type = E_Bool;

	return true;
}

bool Value::GetValue(byte &value) const
{
	if (m_type == E_Byte)
	{
		value = m_data.m_byteData;
		return true;
	}

	return false;
}

string Value::GetValueString() const
{
	string strResult;
	char buf[256] =
	{ 0 };
//	char buf2[256] =
//	{ 0 };
//	char buf3[256] =
//	{ 0 };

	switch (m_type)
	{
		case E_InvalidValueType:
			strResult = string("E_InvalidValueType");
		break;

		case E_Bool:
			if (m_data.m_boolData == true)
			{
				strResult = "true";
			}
			else
			{
				strResult = "false";
			}
		break;

		case E_Byte:
			snprintf(buf, sizeof(buf), "%d", m_data.m_byteData);
			strResult = string(buf);
		break;

		case E_Int:
		{
			ostringstream ostr;
			ostr << m_data.m_intData;
			strResult = ostr.str();
		}
		break;

		case E_Long:
			snprintf(buf, sizeof(buf), "%lld", m_data.m_longData);
			strResult = string(buf);
		break;

		case E_Double:
		{
			ostringstream ostr;
			ostr << std::noshowpoint << m_data.m_doubleData;
			//		sprintf(buf, sizeof(buf), "%.8lf", m_data.m_doubleData);
			strResult = ostr.str();
		}
		break;

		case E_String:
			if (m_data.m_pStringData)
			{
				strResult = string(m_data.m_pStringData);
			}
			else
			{
				strResult = "";
			}

		break;
		default:
		break;
	}

	return strResult;
}

bool Value::SetValue(const byte &value)
{
	m_data.m_byteData = value;
	m_type = E_Byte;

	return true;
}

bool Value::GetValue(int &value) const
{
	if (m_type == E_Int)
	{
		value = m_data.m_intData;
		return true;
	}

	return false;
}

bool Value::GetValue(int64_t &value) const
{
	if (m_type == E_Long)
	{
		value = m_data.m_longData;
		return true;
	}

	return false;
}

bool Value::SetValue(const int &value)
{
	m_data.m_intData = value;
	m_type = E_Int;

	return true;
}

bool Value::SetValue(const int64_t &value)
{
	m_data.m_longData = value;
	m_type = E_Long;

	return true;
}

bool Value::GetValue(double &value) const
{
	if (m_type == E_Double)
	{
		value = m_data.m_doubleData;
		return true;
	}

	return false;
}

bool Value::SetValue(const double &value)
{
	m_data.m_doubleData = value;
	m_type = E_Double;

	return true;
}

bool Value::GetValue(string &value) const
{
	if (m_type == E_String)
	{
		if (m_data.m_pStringData)
		{
			value = m_data.m_pStringData;
		}
		else
		{
			value = "";
		}

		return true;
	}

	return false;
}

bool Value::SetValue(const string &value)
{
	// delete old data
	if (m_type == E_String)
	{
		delete[] m_data.m_pStringData;
		m_data.m_pStringData = NULL;
	}

	// Create new string
	size_t length = value.length();
	if (length > 0)
	{
		m_data.m_pStringData = new char[length + 1];
		memset(m_data.m_pStringData, 0, sizeof(char) * (length + 1));
//		strncpy(m_data.m_pStringData, value.c_str(), length);
		memcpy(m_data.m_pStringData, value.c_str(), length);
	}

	m_type = E_String;

	return true;
}

bool Value::SetValue(const char *&pValue)
{
	// delete old data
	if (m_type == E_String)
	{
		delete[] m_data.m_pStringData;
		m_data.m_pStringData = NULL;
	}

	// Create new string
	size_t length = strlen(pValue);
	if (length > 0)
	{
		m_data.m_pStringData = new char[length + 1];
		memset(m_data.m_pStringData, 0, sizeof(char) * (length + 1));
		strncpy(m_data.m_pStringData, pValue, length);
	}

	m_type = E_String;

	return true;
}

bool Value::SetValue(const char pValue[])
{
	// delete old data
	if (m_type == E_String)
	{
		delete[] m_data.m_pStringData;
		m_data.m_pStringData = NULL;
	}

	// Create new string
	size_t length = strlen(pValue);
	if (length > 0)
	{
		m_data.m_pStringData = new char[length + 1];
		memset(m_data.m_pStringData, 0, sizeof(char) * (length + 1));
		strncpy(m_data.m_pStringData, pValue, length);
	}

	m_type = E_String;

	return true;
}

Value& Value::operator=(const Value& o)
{
	if (&o == this)
	{
		return *this;
	}
	if (m_type == E_String)
	{
		delete[] m_data.m_pStringData;
		m_data.m_pStringData = NULL;
	}
	m_type = o.m_type;
	m_range = o.m_range;
	if (o.m_type == E_String)
	{
		const char* pValue = o.m_data.m_pStringData;
		// Create new string
		size_t length = 0;
		if (pValue != NULL)
		{
			length = strlen(pValue);
		}
		if (length > 0)
		{
			m_data.m_pStringData = new char[length + 1];
			memset(m_data.m_pStringData, 0, sizeof(char) * (length + 1));
			strncpy(m_data.m_pStringData, pValue, length);
		}
	}
	else
	{
		m_data = o.m_data;
	}
	return *this;
}

//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
