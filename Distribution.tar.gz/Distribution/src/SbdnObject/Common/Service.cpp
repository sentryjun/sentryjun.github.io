#include "CommonSettings.h"
#include "Service.h"

using namespace PKU_SatLab_DBS_Common;

Service::Service(void) : SbdnObject()
{
}

Service::~Service(void)
{
}


Service::Service(string name, string treeID, string objectID)
: SbdnObject(name, treeID, SBDNSERVICEID, objectID)
{
}

Service::Service(const SbdnObject &source) : SbdnObject(source)
{
}

bool Service::Initialize(void)
{
	return false;
}

Service::Service(string name, string treeID, string classID, string objectID)
: SbdnObject(name, treeID, classID, objectID)
{
}


//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
