#include "CommonSettings.h"
#include "Event.h"

using namespace PKU_SatLab_DBS_Common;

Event::Event(void)
{
}

Event::~Event(void)
{
//	Info::~Info();
}

Event::Event(string name, string treeID, string objectID)
:Info(name, treeID, SBDNEVENTID, objectID) {
}

Event::Event(string name, string treeID, string classID, string objectID)
:Info(name, treeID, classID, objectID) {
}

Event::Event(const SbdnObject &source) : Info(source)
{
//	Info::Info(source);
}

bool Event::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
