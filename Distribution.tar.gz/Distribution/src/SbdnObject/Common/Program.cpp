#include "CommonSettings.h"
#include "Program.h"

using namespace PKU_SatLab_DBS_Common;

Program::Program(void)
{
}

Program::~Program(void)
{
}


Program::Program(string name, string treeID, string classID, string objectID)
: Service::Service(name, treeID, classID, objectID){
}

Program::Program(string name, string treeID, string objectID)
: Service::Service(name, treeID, SBDNPROGRAMID, objectID){
}

Program::Program(const SbdnObject &source) : Service(source)
{
}

bool Program::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
