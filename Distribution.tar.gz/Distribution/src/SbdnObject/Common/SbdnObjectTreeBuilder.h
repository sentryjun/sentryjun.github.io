#pragma once
#include "SbdnObject.h"
#include "../XML/tinyxml.h"

namespace PKU_SatLab_DBS_Common
{
	class SbdnObjectTreeBuilder
	{
	public:
		SbdnObjectTreeBuilder(void);
		virtual ~SbdnObjectTreeBuilder(void);

		virtual SbdnObject* LoadSbdnObjectFromXml(const string &xmlFileName);
		virtual SbdnObject* LoadSbdnObjectFromContent(const char *pContent);
		virtual bool SaveSbdnObjectToXml(const SbdnObject *pRootObject, const string &xmlFileName);
		virtual bool SaveSbdnObjectToContent(const SbdnObject *pRootObject, char *&pContent);

		virtual SbdnObject* CreateSbdnObject(string strName, string strTreeID, string strClassID, string objectID);
		virtual void DeleteSbdnObjectTree(SbdnObject *pRootObject);

	protected:
		bool IsFileExist(const string &xmlFileName);

		bool LoadSbdnObjectFromXml(SbdnObject *&pRootObject, const TiXmlElement *pRootNode);
		bool SaveSbdnObjectToXml(const SbdnObject *pRootObject, TiXmlElement *&pRootNode);

		string m_scStrClassID;
		string m_scStrObjectID;
		string m_scStrTreeID;
		string m_scStrType;
		string m_scStrValue;

		string m_scStrBool;
		string m_scStrByte;
		string m_scStrInt;
		string m_scStrLong;
		string m_scStrDouble;
		string m_scStrString;
		string m_scStrClass;
		string m_scStrTrue;
		string m_scStrFalse;
	};
}

//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
