#include "CommonSettings.h"
#include "Submitter.h"

using namespace PKU_SatLab_DBS_Common;

Submitter::Submitter(void)
{
}

Submitter::~Submitter(void)
{
}

Submitter::Submitter(string name, string treeID, string classID, string objectID)
:Actor(name, treeID, classID, objectID){
}

Submitter::Submitter(string name, string treeID, string objectID)
:Actor(name, treeID, SBDNSUBMITTERID, objectID){
}

Submitter::Submitter(const SbdnObject &source) : Actor(source)
{
}

bool Submitter::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
