#pragma once

namespace PKU_SatLab_DBS_Common
{
	interface IDbInterface
	{
		bool virtual IsIDBInterfaceEnabled () const = 0;
		bool virtual AddRecord (void) = 0;
		virtual ~IDbInterface() = 0;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
