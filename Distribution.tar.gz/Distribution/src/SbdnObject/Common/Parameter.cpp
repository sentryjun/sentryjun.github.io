#include "CommonSettings.h"
#include "Parameter.h"

using namespace PKU_SatLab_DBS_Common;

Parameter::Parameter(void)
{
}

Parameter::~Parameter(void)
{
}

Parameter::Parameter(string name, string treeID, string classID, string objectID)
:SbdnObject(name, treeID, classID, objectID){
}

Parameter::Parameter(string name, string treeID, string objectID)
:SbdnObject(name, treeID, SBDNPARAMETERID, objectID){
}

Parameter::Parameter(const SbdnObject &source) : SbdnObject(source)
{

}

bool Parameter::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
