#pragma once

namespace PKU_SatLab_DBS_Common
{
	struct ValueRange
	{
	public:
		ValueRange(void);
		~ValueRange(void);
		static const unsigned int m_sInvalidBoundValue;

		uint m_upperBound;
		uint m_lowerBound;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
