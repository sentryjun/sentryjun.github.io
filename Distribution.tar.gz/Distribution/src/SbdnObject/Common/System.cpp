#include "CommonSettings.h"
#include "System.h"

using namespace PKU_SatLab_DBS_Common;

System::System(void)
{
}

System::~System(void)
{
}

System::System(string name, string treeID, string objectID)
:Service(name, treeID, SBDNSYSTEMID, objectID){
}

System::System(string name, string treeID, string classID, string objectID)
:Service(name, treeID, classID, objectID){
}

System::System(const SbdnObject &source) : Service(source)
{
}

bool System::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
