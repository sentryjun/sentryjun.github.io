#pragma once

#include "CommonSettings.h"

namespace PKU_SatLab_DBS_Common
{
	union ValueData
	{
		bool m_boolData;
		byte m_byteData;
		int m_intData;
		long long int m_longData;
		double m_doubleData;
		char* m_pStringData;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
