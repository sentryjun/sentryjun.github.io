#include "CommonSettings.h"
#include "Info.h"

using namespace PKU_SatLab_DBS_Common;

Info::Info(void)
{
}

Info::~Info(void)
{
}

Info::Info(string name, string treeID, string objectID)
:SbdnObject(name, treeID, SBDNINFOID, objectID) {
}

Info::Info(string name, string treeID, string classID, string objectID)
:SbdnObject(name, treeID, classID, objectID) {
}

Info::Info(const SbdnObject &source) : SbdnObject(source)
{
}

bool Info::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
