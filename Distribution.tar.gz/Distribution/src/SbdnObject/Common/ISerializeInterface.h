#pragma once
#include "../XML/tinyxml.h"
//using namespace Sourceforge_TinyXml;
namespace PKU_SatLab_DBS_Common
{
	// This class should be implemented by the .net framework
	interface ISerializeInterface
	{
		bool virtual IsISerializeInterfaceEnabled () const = 0;
		bool virtual Serialize (const TiXmlNode &xmlNode) = 0;
		bool virtual DeSerialize (TiXmlNode &xmlNode) const = 0;
		virtual ~ISerializeInterface() = 0;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
