// Program.h: Class of the programs in Sbdn
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROGRAM_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_PROGRAM_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Service.h"

namespace PKU_SatLab_DBS_Common
{
	class Program : public Service  
	{
	public:
		Program(void);
		Program(string name, string treeID, string objectID);
		Program(const SbdnObject &source);
		virtual ~Program(void);

		bool Initialize(void);
	protected:
		Program(string name, string treeID, string classID, string objectID);
	private:
		string m_ProgramDescription;

	};
}

#endif // !defined(AFX_PROGRAM_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
