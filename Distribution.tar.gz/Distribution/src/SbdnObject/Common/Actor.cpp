#include "CommonSettings.h"
#include "Actor.h"

using namespace PKU_SatLab_DBS_Common;

Actor::Actor(void) {
}

Actor::~Actor(void)
{
}

Actor::Actor(string name, string treeID, string classID, string objectID)
:SbdnObject(name, treeID, classID, objectID){
}

Actor::Actor(string name, string treeID, string objectID)
:SbdnObject(name, treeID, SBDNACTORID, objectID){
}

Actor::Actor(const SbdnObject &source) : SbdnObject(source)
{

}

bool Actor::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
