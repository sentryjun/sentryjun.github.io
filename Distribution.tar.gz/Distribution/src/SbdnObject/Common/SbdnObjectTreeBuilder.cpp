#include "CommonSettings.h"
#include "SbdnObjectTreeBuilder.h"
#include "Service.h"
#include "Node.h"
#include "Program.h"
#include "Thread.h"
#include "System.h"
#include "Actor.h"
#include "User.h"
#include "Administrator.h"
#include "Submitter.h"
#include "Parameter.h"
#include "Program.h"
#include "Info.h"
#include "Event.h"
#include "Reference.h"
#include "../XML/tinyxml.h"

using namespace PKU_SatLab_DBS_Common;

SbdnObjectTreeBuilder::SbdnObjectTreeBuilder(void)
{
	m_scStrTreeID = "treeid";
	m_scStrClassID = "classid";
	m_scStrObjectID = "objectid";
	m_scStrType = "type";
	m_scStrValue = "value";

	m_scStrBool = "bool";
	m_scStrByte = "byte";
	m_scStrInt = "int";
	m_scStrLong = "long";
	m_scStrDouble = "double";
	m_scStrString = "string";
	m_scStrClass = "class";
	m_scStrTrue = "true";
	m_scStrFalse = "false";
}

SbdnObjectTreeBuilder::~SbdnObjectTreeBuilder(void)
{
}

SbdnObject* SbdnObjectTreeBuilder::LoadSbdnObjectFromXml(const string &xmlFileName)
{
	// Validate file
	if(IsFileExist(xmlFileName) == false)
	{
		return NULL;
	}

	// Load the XML file
	TiXmlDocument doc(xmlFileName.c_str());
	if (doc.LoadFile() == false)
	{
		return NULL;
	}

	TiXmlElement *pRootElement = doc.RootElement();

	SbdnObject *pRootSbdnObject = NULL;
	LoadSbdnObjectFromXml(pRootSbdnObject, pRootElement);

	return pRootSbdnObject;
}

SbdnObject* SbdnObjectTreeBuilder::LoadSbdnObjectFromContent(const char *pContent)
{
	// Validate content
	if(pContent == NULL)
	{
		return NULL;
	}

	// Load the XML file
	TiXmlDocument doc;
	doc.Parse(pContent);

	TiXmlElement *pRootElement = doc.RootElement();

	SbdnObject *pRootSbdnObject = NULL;
	LoadSbdnObjectFromXml(pRootSbdnObject, pRootElement);

// 	TiXmlOutStream stream;
// 	doc.StreamOut(&stream);
// 	cout<<stream.c_str()<<endl;

	return pRootSbdnObject;
}

bool SbdnObjectTreeBuilder::IsFileExist(const string &xmlFileName)
{
	bool result = false;
	ifstream fin;
	fin.open(xmlFileName.c_str());
	if(fin)
	{
		result = true;
	}
	fin.close();
	return result;
}

bool SbdnObjectTreeBuilder::LoadSbdnObjectFromXml(SbdnObject *&pRootObject, const TiXmlElement *pRootNode)
{
	if(pRootNode == NULL)
	{
		return true;
	}

	// validate node type
	if(pRootNode->Type() != TiXmlNode::ELEMENT)
		return false;

	string strName = pRootNode->Value();
	string strTreeID = "";
	string strClassID = "";
	string strObjectID = "";
	string strType = "";
	string strValue = "";

	const TiXmlAttribute *pAttr = pRootNode->FirstAttribute();
	while(pAttr != NULL)
	{
		if(pAttr->Name() != NULL)
		{
			if(strcmp(pAttr->Name(), m_scStrTreeID.c_str()) == 0)
			{
				strTreeID = pAttr->Value();
			}
			if(strcmp(pAttr->Name(), m_scStrClassID.c_str()) == 0)
			{
				strClassID = pAttr->Value();
			}
			if(strcmp(pAttr->Name(), m_scStrObjectID.c_str()) == 0)
			{
				strObjectID = pAttr->Value();
			}
			if(strcmp(pAttr->Name(), m_scStrType.c_str()) == 0)
			{
				strType = pAttr->Value();
			}
			if(strcmp(pAttr->Name(), m_scStrValue.c_str()) == 0)
			{
				strValue = pAttr->Value();
			}
		}
		pAttr = pAttr->Next();
	}

	// Create Root SbdnObject
	SbdnObject *pNewObject = CreateSbdnObject(strName, strTreeID, strClassID, strObjectID);
	if(pNewObject != NULL)
	{
		if (strType != "")
		{
			if(strcmp(strType.c_str(), m_scStrClass.c_str()) == 0)
				pNewObject->GetValue().SetType(PKU_SatLab_DBS_Common::E_Class);

			if(strcmp(strType.c_str(), m_scStrBool.c_str()) == 0)
			{
				pNewObject->GetValue().SetType(PKU_SatLab_DBS_Common::E_Bool);
				if (strValue != "")
				{
					bool value;
					if(strcmp(strValue.c_str(), m_scStrTrue.c_str()) == 0)
					{
						value = true;
						pNewObject->GetValue().SetValue(value);
					}
					if(strcmp(strValue.c_str(), m_scStrFalse.c_str()) == 0)
					{
						value = false;
						pNewObject->GetValue().SetValue(value);
					}
				}
			}

			if(strcmp(strType.c_str(), m_scStrByte.c_str()) == 0)
			{
				pNewObject->GetValue().SetType(PKU_SatLab_DBS_Common::E_Byte);
				if (strValue != "")
				{
					byte value = (byte)atoi(strValue.c_str());
					pNewObject->GetValue().SetValue(value);
				}
			}

			if(strcmp(strType.c_str(), m_scStrInt.c_str()) == 0)
			{
				pNewObject->GetValue().SetType(PKU_SatLab_DBS_Common::E_Int);
				if (strValue != "")
				{
					int value = atoi(strValue.c_str());
					pNewObject->GetValue().SetValue(value);
				}
			}

			if(strcmp(strType.c_str(), m_scStrLong.c_str()) == 0)
			{
				pNewObject->GetValue().SetType(PKU_SatLab_DBS_Common::E_Long);
				if (strValue != "")
				{
					int64_t value = atoll(strValue.c_str());
					pNewObject->GetValue().SetValue((int64_t)value);
				}
			}

			if(strcmp(strType.c_str(), m_scStrDouble.c_str()) == 0)
			{
				pNewObject->GetValue().SetType(PKU_SatLab_DBS_Common::E_Double);
				if (strValue != "")
				{
					double value = atof(strValue.c_str());
					pNewObject->GetValue().SetValue(value);
				}
			}

			if(strcmp(strType.c_str(), m_scStrString.c_str()) == 0)
			{
				pNewObject->GetValue().SetType(PKU_SatLab_DBS_Common::E_String);
				if (strValue != "")
				{
					pNewObject->GetValue().SetValue(strValue);
				}
			}
		}
	}

	bool bLoadSubnode = true;
	if(pNewObject != NULL)
	{
		if(pRootObject == NULL)
		{
			pRootObject = pNewObject;
		}
		else
		{
			pRootObject->AddChildSbdnObject(pNewObject);
		}

		// If the root node is a reference node, delete the child node which was created just now
		string strRootObjectClassID = "";
		pRootObject->GetClassID().GetID(strRootObjectClassID);
		if (strRootObjectClassID == SBDNREFERENCEID)
		{
			bLoadSubnode = false;
			delete pNewObject;
			pNewObject = NULL;
		}
	}

	// Load sub node
	if (bLoadSubnode)
	{
		const TiXmlElement *pChildElement = pRootNode->FirstChildElement();
		while(pChildElement != NULL)
		{
			LoadSbdnObjectFromXml(pNewObject, pChildElement);
			pChildElement = pChildElement->NextSiblingElement();
		}
	}
	return true;
}

SbdnObject* SbdnObjectTreeBuilder::CreateSbdnObject(string strName, string strTreeID, string strClassID, string strObjectID)
{
	// TODO: There should be a creation depends on the type ID
	if(strClassID == SBDNOBJECTID)
		return new SbdnObject(strName, strTreeID, strObjectID);
	if(strClassID == SBDNSERVICEID)
		return new Service(strName, strTreeID, strObjectID);
	if(strClassID == SBDNNODEID)
		return new Node(strName, strTreeID, strObjectID);
	if(strClassID == SBDNPROGRAMID)
		return new Program(strName, strTreeID, strObjectID);
	if(strClassID == SBDNTHREADID)
		return new Thread(strName, strTreeID, strObjectID);
	if(strClassID == SBDNSYSTEMID)
		return new System(strName, strTreeID, strObjectID);
	if(strClassID == SBDNACTORID)
		return new Actor(strName, strTreeID, strObjectID);
	if(strClassID == SBDNUSERID)
		return new User(strName, strTreeID, strObjectID);
	if(strClassID == SBDNADMINISTRATORID)
		return new Administrator(strName, strTreeID, strObjectID);
	if(strClassID == SBDNSUBMITTERID)
		return new Submitter(strName, strTreeID, strObjectID);
	if(strClassID == SBDNPARAMETERID)
		return new Parameter(strName, strTreeID, strObjectID);
	if(strClassID == SBDNINFOID)
		return new Info(strName, strTreeID, strObjectID);
	if(strClassID == SBDNEVENTID)
		return new Event(strName, strTreeID, strObjectID);
	if(strClassID == SBDNREFERENCEID)
		return new Reference(strName, strTreeID, strObjectID);

	return new SbdnObject(strName, strTreeID, strClassID, strObjectID);
}

void SbdnObjectTreeBuilder::DeleteSbdnObjectTree(SbdnObject *pRootObject)
{
	pRootObject->ClearContent();
	delete pRootObject;
	pRootObject = NULL;
}


bool SbdnObjectTreeBuilder::SaveSbdnObjectToXml(const SbdnObject *pRootObject, const string &xmlFileName)
{
	if(pRootObject == NULL)
	{
		return false;
	}

	// Create a TiXmlDocument to save
	TiXmlDocument doc;

	TiXmlElement *pRootElement = NULL;
	if(SaveSbdnObjectToXml(pRootObject, pRootElement) == false || pRootElement == NULL)
	{
		return false;
	}

	doc.InsertEndChild(*pRootElement);
	delete pRootElement;

	bool ret = doc.SaveFile(xmlFileName.c_str());

	return ret;
}

bool SbdnObjectTreeBuilder::SaveSbdnObjectToContent(const SbdnObject *pRootObject, char *&pContent)
{
	if(pRootObject == NULL)
	{
		return false;
	}

	// Create a TiXmlDocument to save
	TiXmlDocument doc;

	TiXmlElement *pRootElement = NULL;
	if(SaveSbdnObjectToXml(pRootObject, pRootElement) == false || pRootElement == NULL)
	{
		return false;
	}

	doc.InsertEndChild(*pRootElement);
	delete pRootElement;

	const char *pTempFileName = "SaveSbdnObjectTempFile.xml";
	bool ret = doc.SaveFile(pTempFileName);
	if(ret == false)
	{
		return false;
	}

	ifstream fin(pTempFileName);
	fin.seekg(0, ios::end);
	int length = fin.tellg();
	pContent = new char [length+1];
	memset(pContent, 0, length+1);
	fin.seekg(0, ios::beg);
	fin.get(pContent, length, 0);
	fin.close();
	delete[] pContent;
	return ret;
}

bool SbdnObjectTreeBuilder::SaveSbdnObjectToXml(const SbdnObject *pRootObject, TiXmlElement *&pRootNode)
{
	if(pRootObject == NULL)
	{
		return true;
	}

	// Create the current element
	pRootNode = new TiXmlElement(pRootObject->GetName().c_str());

	// Set attributes
	pRootNode->SetAttribute(m_scStrTreeID.c_str(), pRootObject->GetTreeID().GetID().c_str());
	pRootNode->SetAttribute(m_scStrClassID.c_str(), pRootObject->GetClassID().GetID().c_str());
	pRootNode->SetAttribute(m_scStrObjectID.c_str(), pRootObject->GetObjectID().GetID().c_str());
	if(pRootObject->GetValue().GetType() != E_InvalidValueType)
	{
		pRootNode->SetAttribute(m_scStrType.c_str(), pRootObject->GetValue().GetTypeName().c_str());
		pRootNode->SetAttribute(m_scStrValue.c_str(), pRootObject->GetValue().GetValueString().c_str());
	}

	// Add sub SbdnObjects
	const list<SbdnObject*> childObjects = pRootObject->GetChildSbdnObjects();
	list<SbdnObject*>::const_iterator itor = childObjects.begin();

	while(itor != childObjects.end())
	{
		// save data to child node
		TiXmlElement *pChildNode = NULL;
		SaveSbdnObjectToXml(*itor, pChildNode);

		// add to child element
		pRootNode->InsertEndChild(*pChildNode);

		// InsertEndChild has already made a deep copy
		delete pChildNode;

		itor ++;
	}

	return true;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
