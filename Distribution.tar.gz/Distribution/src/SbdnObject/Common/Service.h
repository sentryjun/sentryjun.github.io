// Service.h: Class of the services in Sbdn
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERVICE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_SERVICE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#include "SbdnObject.h"

namespace PKU_SatLab_DBS_Common
{
	class Service : public SbdnObject
	{
	public:
		Service(void);
		Service(string name, string treeID, string objectID);
		Service(const SbdnObject &source);
		virtual ~Service(void);

		bool Initialize(void);

	protected:
		Service(string name, string treeID, string classID, string objectID);
	private:
		string m_ServiceDescription;

	};
}

#endif // !defined(AFX_SERVICE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
