#pragma once

#include "Value.h"
namespace PKU_SatLab_DBS_Common
{
	interface IMonitorInterface
	{
		bool virtual IsIMonitorInterfaceEnabled () const = 0;
		ValueData virtual GetValueData() const = 0;
		ValueType virtual GetValueType() const = 0;
		ValueRange virtual GetValueRange() const = 0;
		bool virtual SetValueData(const ValueData &data) = 0;
		virtual ~IMonitorInterface() = 0;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
