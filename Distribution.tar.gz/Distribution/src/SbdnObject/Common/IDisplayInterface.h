#pragma once
#include "DisplayType.h"

namespace PKU_SatLab_DBS_Common
{
	interface IDisplayInterface
	{
		bool virtual IsIDisplayInterfaceEnabled () const = 0;
		DisplayType virtual GetDisplayType () = 0;
		string virtual GetText() const = 0;
		string virtual GetIconResourceName() const = 0;
		virtual ~IDisplayInterface() = 0;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
