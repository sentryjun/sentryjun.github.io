#ifndef _COMMON_SETTINGS_H_INCLUDED_
#define _COMMON_SETTINGS_H_INCLUDED_

#include <string>
#include <iostream>
#include <list>
#include <fstream>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <list>
#include <algorithm>
#include <assert.h>

#ifndef  implements
#define  implements public
#endif //implements

#ifndef interface
#define interface struct
#endif

#ifndef uint
typedef unsigned int uint;
#endif

#ifndef byte
typedef unsigned char byte;
#endif

#ifndef NULL
#define NULL 0
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef INFINITE
#define INFINITE 0xFFFFFFFF
#endif

#ifdef   _WINDOWS_PLATFORM_
#include <winsock2.h>
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>  
#include <crtdbg.h>
#include <process.h>
#include <assert.h>
#include <time.h>
#include <sys/timeb.h>
#define BYTE unsigned char
#define LPBYTE unsigned char *
#define FALSE 0
#define TRUE 1
#define SOCKET_ERROR (-1)
#define closesocket close
#define SD_RECEIVE SHUT_RD
#define SD_SEND SHUT_WR
#define SD_BOTH SHUT_RDWR
#define GetLastError ReturnZero
#endif // _WINDOWS_PLATFORM_

#define SBDNOBJECTID "1"

#define SBDNSERVICEID "1.1"
#define SBDNNODEID "1.1.1"
#define SBDNSYSTEMID "1.1.2"
#define SBDNPROGRAMID "1.1.3"
#define SBDNTHREADID "1.1.4"

#define SBDNACTORID "1.2"
#define SBDNUSERID "1.2.1"
#define SBDNADMINISTRATORID "1.2.2"
#define SBDNSUBMITTERID "1.2.3"

#define SBDNINFOID "1.3"
#define SBDNEVENTID "1.3.1"

#define SBDNPARAMETERID "1.4"

#define SBDNREFERENCEID "2"

char *itoa(int value,char *string,int radix);

using namespace std;

#ifdef _DEBUG
int g_nSbdnObjectCount=0;
#endif

#endif //_COMMON_SETTINGS_H_INCLUDED
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
