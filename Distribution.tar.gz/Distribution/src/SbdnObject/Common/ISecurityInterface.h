#pragma once

#include "Value.h"
namespace PKU_SatLab_DBS_Common
{	
	// This interface should be provided by Security Server
	interface ISecurityServerInterface; 
	interface ISecurityInterface
	{
		bool virtual IsISecurityInterfaceEnabled () const = 0;
		bool virtual Authenticate (const ISecurityServerInterface *pSecServer) = 0;
		bool virtual Validate (const ISecurityServerInterface *pSecServer) = 0;
		virtual ~ISecurityInterface() = 0;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
