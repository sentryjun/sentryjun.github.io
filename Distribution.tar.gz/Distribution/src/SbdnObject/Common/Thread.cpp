#include "CommonSettings.h"
#include "Thread.h"

using namespace PKU_SatLab_DBS_Common;

Thread::Thread(void)
{
}

Thread::~Thread(void)
{
}

Thread::Thread(string name, string treeID, string objectID)
:Service(name, treeID, SBDNTHREADID, objectID){
}

Thread::Thread(string name, string treeID, string classID, string objectID)
:Service(name, treeID, classID, objectID){
}

Thread::Thread(const SbdnObject &source) : Service(source)
{
}

bool Thread::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
