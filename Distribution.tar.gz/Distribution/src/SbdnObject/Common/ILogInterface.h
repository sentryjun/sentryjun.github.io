#pragma once

namespace PKU_SatLab_DBS_Common
{
	// This interface should be provided by Log Lib
	interface ILogLibInterface; 

	interface ILogInterface
	{
		bool virtual IsILogInterfaceEnabled () const = 0;
		bool virtual AddLogger (const ILogLibInterface *pLogger) = 0;
		bool virtual RemoveLogger (const ILogLibInterface *pLogger) = 0;
		virtual ~ILogInterface() = 0;
	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
