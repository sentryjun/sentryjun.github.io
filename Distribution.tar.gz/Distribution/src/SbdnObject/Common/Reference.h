// Reference.h: Class of the reference in Sbdn, which is a virtual pointer to a entity Sbdn object
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REFERENCE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_REFERENCE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#include "SbdnObject.h"

namespace PKU_SatLab_DBS_Common
{
	class Reference : public SbdnObject  
	{
	public:
		Reference(void);
		Reference(string name, string treeID, string objectID);
		Reference(const SbdnObject &source);
		virtual ~Reference(void);

		bool Initialize(void);

		list<SbdnObject *>& GetChildSbdnObjects ();
		const list<SbdnObject *>& GetChildSbdnObjects () const;
		bool SetChildSbdnObjects (const list<SbdnObject *> &childSbdnObjects);
		bool AddChildSbdnObject (const SbdnObject *pSbdnObject);
		bool RemoveChildSbdnObject (const SbdnObject *pSbdnObject);
		bool DeleteChildSbdnObject (SbdnObject *&pSbdnObject);
		void ClearChildSbdnObjects();

		Reference& operator = (const Reference &source);

		void ClearContent();

	protected:
		Reference(string name, string treeID, string classID, string objectID);
	private:
		string m_ReferenceDescription;

	};
}

#endif // !defined(AFX_REFERENCE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
