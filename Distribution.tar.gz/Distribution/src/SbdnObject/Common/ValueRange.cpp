#include "CommonSettings.h"
#include "ValueRange.h"

using namespace PKU_SatLab_DBS_Common;

const uint ValueRange::m_sInvalidBoundValue = (uint)-1;

ValueRange::ValueRange(void)
: m_lowerBound(m_sInvalidBoundValue)
, m_upperBound(m_sInvalidBoundValue)
{
}

ValueRange::~ValueRange(void)
{
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
