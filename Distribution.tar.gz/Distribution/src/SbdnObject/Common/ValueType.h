#pragma once

namespace PKU_SatLab_DBS_Common
{
	enum ValueType
	{
		E_InvalidValueType = 0,
		E_Bool,
		E_Byte,
		E_Int,
		E_Long,
		E_Double,
		E_String,
		E_Class,
	};

	const string ValueTypeNames[8] =
	{
		"Invalid Value Type",
		"bool",
		"byte",
		"int",
		"long",
		"double",
		"string",
		"class"
	};
};
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
