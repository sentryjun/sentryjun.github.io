// User.h: Class of the users in Sbdn
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_USER_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_USER_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#include "Actor.h"

namespace PKU_SatLab_DBS_Common
{
	class User : public Actor  
	{
	public:
		User(void);
		User(string name, string treeID, string objectID);
		User(const SbdnObject &source);
		virtual ~User(void);

		bool Initialize(void);
	protected:
		User(string name, string treeID, string classID, string objectID);
	private:
		string m_UserDescription;

	};
}

#endif // !defined(AFX_USER_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
