#include "CommonSettings.h"
#include "Reference.h"

using namespace PKU_SatLab_DBS_Common;

Reference::Reference(void)
{
}

Reference::~Reference(void)
{
}

Reference::Reference(string name, string treeID, string classID, string objectID)
:SbdnObject(name, treeID, classID, objectID){
}

Reference::Reference(string name, string treeID, string objectID)
:SbdnObject(name, treeID, SBDNREFERENCEID, objectID){
}

Reference::Reference(const SbdnObject &source) : SbdnObject(source)
{

}

bool Reference::Initialize(void)
{
	return false;
}

list<SbdnObject *>& Reference::GetChildSbdnObjects ()
{
	m_childSbdnObjects.clear();
	return m_childSbdnObjects;
}

const list<SbdnObject *>& Reference::GetChildSbdnObjects () const
{
	return m_childSbdnObjects;
}

void Reference::ClearContent()
{
	ClearChildSbdnObjects();
}

void Reference::ClearChildSbdnObjects()
{
	m_childSbdnObjects.clear();
}

bool Reference::SetChildSbdnObjects (const list<SbdnObject *> &childSbdnObjects)
{
	return false;
}

bool Reference::AddChildSbdnObject (const SbdnObject *pSbdnObject)
{
	return false;
}

bool Reference::RemoveChildSbdnObject (const SbdnObject *pSbdnObject)
{
	if(pSbdnObject == NULL)
		return false;

	bool result = false;
	list<SbdnObject*>::iterator itor = m_childSbdnObjects.begin();
	while(itor != m_childSbdnObjects.end())
	{
		if(*itor == pSbdnObject)
		{
			m_childSbdnObjects.erase(itor);
			result = true;
			break;
		}
		itor ++;
	}
	return result;
}

bool Reference::DeleteChildSbdnObject(SbdnObject *&pSbdnObject)
{
	return RemoveChildSbdnObject(pSbdnObject);
}

Reference& Reference::operator = (const Reference &source)
{
	if(&source == this)
	{
		return *this;
	}

	ClearContent();

	m_name = source.m_name;
	m_treeID = source.m_treeID;
	m_classID = source.m_classID;
	m_objectID = source.m_objectID;
	m_value = source.m_value;
	m_iconResource = source.m_iconResource;

	return *this;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
