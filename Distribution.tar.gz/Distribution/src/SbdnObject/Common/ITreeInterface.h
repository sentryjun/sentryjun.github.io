#pragma once
#include "SbdnObject.h"
#include "../XML/tinyxml.h"

namespace PKU_SatLab_DBS_Common
{
//	using namespace Sourceforge_TinyXml;
//	class SbdnObjectTreeBuilder
//	{
//	protected:
//		SbdnObjectTreeBuilder(void);
//		~SbdnObjectTreeBuilder(void);
//
//	public:
//		static SbdnObject* LoadSbdnObjectFromXml(const string &xmlFileName);
//		static SbdnObject* LoadSbdnObjectFromContent(const char *pContent);
//		static bool SaveSbdnObjectToXml(const SbdnObject *pRootObject, const string &xmlFileName);
//		static bool SaveSbdnObjectToContent(const SbdnObject *pRootObject, char *&pContent);
//
//		static SbdnObject* CreateSbdnObject(string strName, string strTreeID, string strClassID, string objectID);
//		static void DeleteSbdnObjectTree(SbdnObject *pRootObject);
//
//	protected:
//		static bool IsFileExist(const string &xmlFileName);
//
//		static bool LoadSbdnObjectFromXml(SbdnObject *&pRootObject, const TiXmlElement *pRootNode);
//		static bool SaveSbdnObjectToXml(const SbdnObject *pRootObject, TiXmlElement *&pRootNode);
//
//		static const string m_scStrClassID;
//		static const string m_scStrObjectID;
//		static const string m_scStrTreeID;
//		static const string m_scStrType;
//		static const string m_scStrValue;
//
//		static const string m_scStrBool;
//		static const string m_scStrByte;
//		static const string m_scStrInt;
//		static const string m_scStrDouble;
//		static const string m_scStrString;
//		static const string m_scStrClass;
//		static const string m_scStrTrue;
//		static const string m_scStrFalse;
//	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
