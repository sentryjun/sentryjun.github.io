#include "CommonSettings.h"
#include "Node.h"

using namespace PKU_SatLab_DBS_Common;

Node::Node(void)
{
}

Node::~Node(void)
{
}

Node::Node(string name, string treeID, string objectID)
: Service(name, treeID, SBDNNODEID, objectID)
{
}

Node::Node(string name, string treeID, string classID, string objectID)
: Service(name, treeID, classID, objectID)
{
}

Node::Node(const SbdnObject &source) : Service(source)
{
}

bool Node::Initialize(void)
{
	return false;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
