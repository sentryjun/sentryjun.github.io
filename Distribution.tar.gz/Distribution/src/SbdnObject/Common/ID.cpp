#include "CommonSettings.h"
#include "ID.h"
#include "string.h"

using namespace PKU_SatLab_DBS_Common;

const char ID::IDSeparator = '.';

ID::ID()
{
}

ID::ID(const string &id) :
	m_id(id)
{
}

ID::~ID(void)
{
}

const string &ID::GetID(void) const
{
	return m_id;
}

void ID::GetID(string &id) const
{
	id = m_id;
}

string ID::GetParentID() const
{
	string::size_type index = m_id.rfind(ID::IDSeparator);
	if (index == string::npos)
	{
		return "";
	}
	return m_id.substr(0, index);
}

bool ID::operator ==(const ID &lhs) const
{
	return m_id == lhs.m_id;
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
