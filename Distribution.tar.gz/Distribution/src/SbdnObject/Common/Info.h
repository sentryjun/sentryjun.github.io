// Info.h: Class of the info in Sbdn
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INFO_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_INFO_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SbdnObject.h"

namespace PKU_SatLab_DBS_Common
{
	class Info : public SbdnObject  
	{
	public:
		Info(void);
		Info(string name, string treeID, string objectID);
		Info(const SbdnObject &source);
		virtual ~Info(void);

		bool Initialize(void);

	protected:
		Info(string name, string treeID, string classID, string objectID);
	private:
		string m_InfoDescription;

	};
}

#endif // !defined(AFX_INFO_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
