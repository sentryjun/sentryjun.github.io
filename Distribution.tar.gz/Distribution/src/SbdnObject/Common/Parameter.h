// Parameter.h: Class of the Parameters in Sbdn
//
//////////////////////////////////////////////////////////////////////

#ifndef SBDN_OBJECT_COMMON_PARAMETER_H_
#define SBDN_OBJECT_COMMON_PARAMETER_H_

#include "SbdnObject.h"

namespace PKU_SatLab_DBS_Common
{
	class Parameter : public SbdnObject
	{
	public:
		Parameter(void);
		Parameter(string name, string treeID, string objectID);
		Parameter(const SbdnObject &source);
		virtual ~Parameter(void);

		bool Initialize(void);
	protected:
		Parameter(string name, string treeID, string classID, string objectID);
	private:
		string m_ActorDescription;

	};
}

#endif // SBDN_OBJECT_COMMON_PARAMETER_H_
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
