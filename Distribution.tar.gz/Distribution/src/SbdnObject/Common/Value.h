#pragma once
#include "ValueData.h"
#include "ValueRange.h"
#include "ValueType.h"

namespace PKU_SatLab_DBS_Common
{
	class Value
	{
	public:
		Value(void);
		~Value(void);
		Value(const string strtype, const string valueData);
		Value(const ValueType type, const string valueData);
		Value(const int &valueData);
		Value(const bool &valueData);
		Value(const byte &valueData);
		Value(const int64_t &valueData);
		Value(const double &valueData);
		Value(const char *&pValueData);
		Value(const char pValueData[]);
		Value(const string &valueData);
		Value(const Value &);

		// SetType() is omitted because it would course collision to SetValue() function
		ValueType GetType() const;
		string GetTypeName() const;
		void SetType(ValueType type);

		bool GetValue(bool &valueData) const;
		bool GetValue(byte &valueData) const;
		bool GetValue(int &valueData) const;
		bool GetValue(int64_t &valueData) const;
		bool GetValue(double &valueData) const;
		bool GetValue(string &valueData) const;
		string GetValueString() const;

		bool SetValue(const Value &value);
//		bool SetValue(const string type, const string value);
		bool SetValue(const ValueType type, const string value);
		bool SetValue(const bool &valueData);
		bool SetValue(const byte &valueData);
		bool SetValue(const int &valueData);
		bool SetValue(const int64_t &valueData);
		bool SetValue(const double &valueData);
		bool SetValue(const char *&pValueData);
		bool SetValue(const char pValueData[]);
		bool SetValue(const string &valueData);

		ValueRange GetRange() const;
		void SetRange(const ValueRange &range);

		Value& operator=(const Value& o);
		int GetInterValue() const { return m_data.m_intData ; }

	protected:
		ValueType m_type;
		ValueRange m_range;
		ValueData m_data;

	};
}
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
