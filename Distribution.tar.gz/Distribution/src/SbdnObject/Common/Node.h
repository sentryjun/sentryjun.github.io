// Node.h: Class of the users in Sbdn
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NODE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
#define AFX_NODE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Service.h"
#include "SbdnObjectTreeBuilder.h"

namespace PKU_SatLab_DBS_Common
{
	class Node : public Service, public SbdnObjectTreeBuilder
	{
	public:
		Node(void);
		Node(string name, string treeID, string objectID);
		Node(const SbdnObject &source);
		virtual ~Node(void);

		bool Initialize(void);

	protected:
		Node(string name, string treeID, string classID, string objectID);
	private:
		string m_NodeDescription;

	};
}

#endif // !defined(AFX_NODE_H__7A80AF16_AA41_4ABC_BC73_28AD73FE6727__INCLUDED_)
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
//int a = 1 + 100; a++; a /= 100; a* 100
